# Databricks notebook source
import urllib
import json

TEMP_DIR = "/bus4118d/"
DBFS_DIR = "/yelp/"
CAT_FILENAME = "categories.json"
CAT_URL = "https://www.yelp.com/developers/documentation/v3/all_category_list/categories.json"

# create the temp directory for downloading and the DBFS directory if they don't exist
dbutils.fs.mkdirs("file:"+TEMP_DIR)
dbutils.fs.mkdirs("dbfs:"+DBFS_DIR)
# If the file already exists, we will remove it
local_name = "file:"+TEMP_DIR+CAT_FILENAME
dbutils.fs.rm(local_name)
dbfs_name = "dbfs:"+DBFS_DIR+CAT_FILENAME
dbutils.fs.rm(dbfs_name)

# get the file and store it in the temp directory
# Note that with the request, the destination 
# directory is inherently on the local driver
urllib.request.urlretrieve(CAT_URL, TEMP_DIR+CAT_FILENAME)
# move the file to DBFS
dbutils.fs.mv(local_name, dbfs_name)
dbutils.fs.ls(DBFS_DIR)