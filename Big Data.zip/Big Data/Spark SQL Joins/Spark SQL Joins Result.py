# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md
# MAGIC # Spark SQL Joins
# MAGIC
# MAGIC Our question we are trying to answer requires us to bring together multiple data files:
# MAGIC * business
# MAGIC * review
# MAGIC * user
# MAGIC * categories (Yelp data, but not from the Yelp dataset)
# MAGIC * gender (the data from the Social Security Administration)
# MAGIC
# MAGIC To bring the data together, we need to match records in one temporary view or table with another temporary view or table.  Telling Spark how to match theise records is known as joining the tables.
# MAGIC
# MAGIC In This notebook we will start with the default join which is an INNER JOIN, but we will discuss all of the following:
# MAGIC * INNER JOIN
# MAGIC * LEFT OUTER JOIN
# MAGIC * FULL OUTER JOIN
# MAGIC * LEFT SEMI JOIN
# MAGIC * LEFT ANTI JOIN
# MAGIC
# MAGIC If you are right-handed, you may be wondering what the deal is with all this lefty stuff.  When we join two data sources, the JOIN expression is between the two temporary views or tables, and the data source before the JOIN is on the left of the join expression, and the data source after the JOIN is on the right-hand side of the join expression.  In the following example, the `categories` view  is on the left, and the `business` view is on the right, with the join expression between them being an `INNER JOIN`:
# MAGIC
# MAGIC `categories INNER JOIN business`
# MAGIC
# MAGIC At the end of this notebook we will join the categories view with the business view and then the reviews view
# MAGIC
# MAGIC However, we want to do any processing of our separate data sources before joining them. 
# MAGIC
# MAGIC # Loading the Categories Data
# MAGIC Since the categories data is our smallest data source, we are going to load and process that first.
# MAGIC
# MAGIC This is the category definitions JSON file we downloaded from the webpage for Yelp's fusion API at <a href="https://www.yelp.com/developers/documentation/v3/all_category_list" target="_blank">this URL</a>.
# MAGIC
# MAGIC We are going to load this data from a JSON file, so similar to loading the business data, but with one difference.  The Yelp data is JSON Lines, where each line of the file is a JSON object.  The categories data is a single JSON array of JSON objects, but each object is not on a single line, but is instead "pretty printed" like our human readable sample data.  When we are loading JSON where each object spans multiple lines in the file, we need to set an option to tell Spark our file is `multiline`.
# MAGIC
# MAGIC #### What if I get a "Path does not exist" error?
# MAGIC If that occurs, you did not successfully run Part 2 of the "Working with Files" notebook.  You will need to upload the categories file.
# MAGIC
# MAGIC Since you don't have time to complete Working with Files now, do the following (**ONLY IF YOU GOT THIS ERROR MESSAGE!)**:
# MAGIC * Insert a new cell before the cell that creates the `df_categories` DataFrame
# MAGIC * In that cell, post the code in the next line (including the quotation marks):<br/>`%run "./Load_Categories"`
# MAGIC * Run that cell, and when it finishes, continue with running the cell to build the `df_categories` DataFrame
# MAGIC
# MAGIC #### The following cell is Step 1

# COMMAND ----------

df_categories = spark.read.option("multiLine",True).json("/yelp/categories.json")
print( "number of categories:", df_categories.count() )
df_categories.show()
df_categories.printSchema()
df_categories.createOrReplaceTempView("categories")

# COMMAND ----------

# MAGIC %md
# MAGIC ### What the Category Data Contains
# MAGIC
# MAGIC Following is a description of the fields in the categories data:
# MAGIC * <p>**alias**:  This is similar to the `title` field, but it's all lower case and there are no spaces in the name.  This is also the value used in the `parents` field to identify the parent-child relationships in the category hierarchy.  For most categories the `alias` and `title` are similar, but check out the category where the `title` is "Fast Food".</p>
# MAGIC * <p>**country_blacklist**:  A category may have a white list or black list, but not both.  This field is either a list of 2-digit country codes or null. if this field contains a list of country codes, then the category can be used in any country except those in the list.  For example, the cuisine "Afghan" has the blacklist \[MX, TR\], which means this category is not used in Mexico or Turkey.<p>
# MAGIC * <p>**country_whitelist**:  If there is a list in this field, the category only is used in those countries.  For example, the category "Absinthe Bars", which is a sub-category under "Bars" has a whitelist with one country \[CZ\] which is the Czech Republic.  This category will only be used to describe businesses in that country.<p>
# MAGIC * <p>**parents**: **The categories form a hierarchy**, so the broader parent category above each category is a list in this field.  although most categories have one parent category, there are a few with multiple parent categories in the list.  **If the list is empty \[ \] for a category (such as "Active Life"), then the category is a top-level category and there is no parent category**.<p>
# MAGIC * <p>**title**:  This is the human-readable label for the category and is also **the label included in the list of categories for a business in the `categories` field in the Yelp business data**.<p>

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 2: How many top-level categories are there?
# MAGIC
# MAGIC
# MAGIC Take a look at your earlier code for showing the first 20 rows of the category data.  "Active Life" is one of the top-level categories (and the first category listed on <a href="https://www.yelp.com/developers/documentation/v3/category_list" target="_blank">this</a> page.  What's different about the list in the `parents` column for that category?
# MAGIC
# MAGIC In Spark there's a <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.functions.size.html#pyspark-sql-functions-size" target="_blank">SIZE </a> function that will return the number of elements in an array.  The function takes one parameter, the name of the column containing the array.
# MAGIC
# MAGIC In the following query, use the `SIZE` function in the `WHERE` clause to get only those categories that have no parents.  We will use this DataFrame to find out what top-level category(s) each business is in.
# MAGIC
# MAGIC #### The following cell is Step 2a

# COMMAND ----------

# Finish the WHERE clause



# COMMAND ----------

# MAGIC %md ### The metadata is out-of-date?
# MAGIC You should have found that there are 22 top-level categories.  The total count agrees with <a href="https://blog.yelp.com/businesses/yelp_category_list" target="_blank">this Yelp blog post</a> that lists all of the top level categories and allows you to drill down to lower levels (it was updated in Spring 2020). However, take a look at the *names* of the top 22 categories on that blog post and compare it to your DataFrame above.  "Bicycles" is listed as a top-level category in your DataFrame, but not in the blog listing.  The blog lists "Real Estate" as a top-level category, but not yor DataFrame.  If you take a look at the metadata where we downloaded the catagory definitions (click <a href=""target="_blank">here</a>), You will find that ***both*** "Bicycles" and "Real Estate" are shown as top-level categories.
# MAGIC
# MAGIC In the following cell, **<span style="color:red;">Work with your team - add a query to find out what category is the parent of Real Estate in your data</span>**.
# MAGIC
# MAGIC #### <span style="color:#0055A2;">The following cell is Step 2b</span>

# COMMAND ----------

# Add a query to find the row for Real Estate




# COMMAND ----------

# MAGIC %md 
# MAGIC # Step 3: Loading the Business Data
# MAGIC We will start with joining the business and review data, but first we need to load our data.  We'll load the business data first, and later the review data.
# MAGIC
# MAGIC As a good practice, we are going to:
# MAGIC * Print a count of the number or records (businesses)
# MAGIC * Show 20 rows (the default)
# MAGIC * Print the schema
# MAGIC
# MAGIC This is the same code we used to load the data in the Intro to Spark SQL Joins notebook
# MAGIC
# MAGIC #### The following cell is Step 3a

# COMMAND ----------

df_business_data = spark.read.json('/yelp/business.bz2')
print ("record count:", df_business_data.count() )
df_business_data.show()
df_business_data.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deciding What Business Data We Need
# MAGIC
# MAGIC This process is iterative, so we could come back later and decide we need additional columns, but for now we are going to include the following:
# MAGIC * business_id (so we can join with our review data)
# MAGIC * name (something human readable)
# MAGIC * categories (so we can identify the type of business and join with the category data)
# MAGIC * state (as a proxy for the metro area)
# MAGIC * review_count (so we can decide how much data we have or need for each business)
# MAGIC * attributes 
# MAGIC * longitude
# MAGIC * latitude
# MAGIC
# MAGIC First we need a temporary view to run a SQL query
# MAGIC
# MAGIC **NOTE:** This is the same code we used to to create the `df_business` DataFrame and `business` temporary view in the Intro to Spark SQL Joins notebook
# MAGIC
# MAGIC #### The following cell is Step 3b

# COMMAND ----------

df_business_data.createOrReplaceTempView("business_data")

df_business = spark.sql("""
SELECT business_id, name, categories, state, review_count, attributes, longitude, latitude
FROM business_data
""")
print ("record count:", df_business.count() )
df_business.show()
df_business.createOrReplaceTempView("business")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Wrangling Our Business Data
# MAGIC
# MAGIC We are going to come back to this step, but any processing we need to do with the business data should be done ***before*** we join it with the review data.
# MAGIC
# MAGIC There are only 1565 categories in Yelp, compared to 160,000+ businesses, so we should prepare our category data before joining t with the business data
# MAGIC
# MAGIC Some questions we need to look at with the 
# MAGIC
# MAGIC
# MAGIC We have ~160K businesses, but ~8000K reviews.  We don't want to be dragging around 8 million reviews until we are done with or business data. There are only about 
# MAGIC
# MAGIC
# MAGIC Some of the wrangling we would want to do first:
# MAGIC * Identify what categories a business is in
# MAGIC * Figure out how many businesses are not in *any* categories (completed in the Intro to SQL Joins notebook)
# MAGIC * Identify the number of businesses in each top-level category
# MAGIC * How many businesses are in multiple top-level categories?
# MAGIC * Identify the states that are the metro area proxies (we did this before)
# MAGIC   * Identify how many businesses are in each of these proxy states (we did this before)
# MAGIC   * Identify how much "bad data" we have for businesses in other states
# MAGIC   * Filter out data for bad states
# MAGIC * Look at the distribution for review count
# MAGIC * Questions About Specific Categories
# MAGIC   * How many businesses are in `Restaurants` (where most of the reviews are)?  How many are in `Home Services` and `Local Services` (where Yelp makes money)?
# MAGIC   * What's the review distribution per business look like for these categories?
# MAGIC   

# COMMAND ----------

# MAGIC %md ### Step 4: Business Categories
# MAGIC
# MAGIC In the business data, the `categories` column contains a comma-seperated string of the categories a business is classified as being in.  However,  some businesses may not be in any categories.
# MAGIC
# MAGIC Since the category string can be long, and is truncated in the output above, we first show 20 rows for just the business_id, name, and categories.
# MAGIC
# MAGIC Example:<br/>
# MAGIC Oskar Blues Taproom: Gastropubs, Food, Beer Gardens, Restaurants, Bars, American (Traditional), Beer Bar, Nightlife, Breweries
# MAGIC
# MAGIC Using the `IN` operator to check if some value is in a list, we get the category data for these categories.  Based on the results, we see that the categories used at this business have the following hierarchy:
# MAGIC
# MAGIC <div>Food<br/>
# MAGIC   <span style="padding-left:20px">├─ Breweries</span><br/>
# MAGIC Nightlife<br/>
# MAGIC <span style="padding-left:20px">├─  Bars<br/>
# MAGIC <span style="padding-left:20px">├─  Beer Gardens<br/>
# MAGIC Restaurants<br/>
# MAGIC <span style="padding-left:20px">├─  American (Traditional)<br/>
# MAGIC <span style="padding-left:20px">├─  Gastropubs<br/>
# MAGIC
# MAGIC If we explored more, we would find that the `categories` column in the business data always walks the tree up to the top-level categories, possibly through multiple levels.
# MAGIC
# MAGIC #### The following cell is Step 4a

# COMMAND ----------

spark.sql("""
SELECT business_id, name, categories
FROM business
""").show(truncate=False)

# COMMAND ----------

spark.sql("""
SELECT * 
FROM categories
WHERE title IN ("Gastropubs","Food","Beer Gardens","Restaurants","Bars","American (Traditional)","Beer Bar","Nightlife","Breweries")
ORDER BY title
""").show(truncate=False)

# COMMAND ----------

# MAGIC %md ### Step 4b: Identifying the categories a business is in
# MAGIC
# MAGIC If we want to join the business data with the `df_top_categories` temporary view we created earlier, there is a Spark function named `array_contains` that allows us to see if a value is in our array (list), but the business categories field is not an array, it's a comma-separated list (scroll up to where you showed this earlier).
# MAGIC
# MAGIC #### Splitting a string to generate an array
# MAGIC Spark has another function we can use to first transform our data; the <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.functions.split.html#pyspark-sql-functions-split" target="_blank">SPLIT function</a>.  This is a string function that will take the value in a string column and split it on some delimiter
# MAGIC (in our case, a comma) and return a list of the values.  The delimiter is a string pattern, so it should be enclosed in single qoute marks. We have another issue however, since the string in business categories has spaces after 
# MAGIC the commas, we need to trim off the spaces.
# MAGIC
# MAGIC #### Regular expressions
# MAGIC The `SPLIT` function's pattern can be what is known as a regular expression, and these are often used when matching text.  What we want is to split on a comma surrounded by any amount of leading or trailing blank space (so the blanks don't end up in the values we get back).  To do this, the pattern `\s` means a blank space, and we can use the wildcard `*` to mean "zero or more", so the pattern `\s*,\s*` means a comma surrounded by any amount of blank space.
# MAGIC
# MAGIC The `\s*` is really important - this means that when we "throw away" the commas, we are also throwing away any blank spaces that would also cause us problems.
# MAGIC
# MAGIC Since we are using SQL, we have one other issue.  The `\` is known as an "escape" character, and in SQL, to match a whitespace character, instead of `\s` we need to use `\\\s` (three backslashes instead of one). 
# MAGIC
# MAGIC In the following cell we have selected all of the columns from the business data except for the categories column.  <span style="color:red">Add a formula to the `SELECT` clause that uses the `SPLIT` function to split on the commas and possible whitespaces</span>. **Alias the column's formula as categories**.
# MAGIC
# MAGIC #### The following cell is Step 4b

# COMMAND ----------

# Add the formula for the categories column






# COMMAND ----------

df_business_categories.select("categories").show(truncate=False)


# COMMAND ----------

# MAGIC %md ### <span style="color:#0055A2;">Step 5: Work with your team to clean up the business data - removing businesses not in the 8 metro areas</span>
# MAGIC
# MAGIC Previously we identified the state codes we are using as a proxy for the 8 metro areas
# MAGIC
# MAGIC In the following cells we:
# MAGIC * Step 5a: First create a DataFrame and corresponding temporary view with the 9 state codes being used as proxies for our 8 metro areas. 
# MAGIC   * <span style="color:red;">Use the code from Step 6 of the `Intro to SQL` notebook</span>. 
# MAGIC   * If you add an `ORDER BY` clause it will make it easier to compare in Step 5c.
# MAGIC   * Did you Know? The `HAVING` clause can use a formula based on the grouping - we can count without a `COUNT(*)` in the `SELECT` clause
# MAGIC   * Name the DataFrame `df_proxy_states` and the temporary view `proxy_states`.
# MAGIC * Step 5b: Then, add a LEFT SEMI JOIN query to filter out those rows in the `business_categories` temporary view from Step 4b that are not in the 9 states
# MAGIC   * Keep the DataFrame name `df_valid_business` in Step 5b, but <span style="color:red;">replace the code that's there</span>
# MAGIC
# MAGIC #### <span style="color:#0055A2;">The following cell is Step 5a</span>

# COMMAND ----------

# Use the query from Step 6 of the Intro to SQL notebook




# COMMAND ----------

# MAGIC %md #### Cleaning up the data with a SEMI JOIN to filter the `state` column
# MAGIC Use a LEFT SEMI JOIN to filter `business_categories` to include only the 9 states we are using as proxies for the metro area.  Include all of the columns from the business data.
# MAGIC
# MAGIC #### <span style="color:#0055A2;">The following cell is Step 5b</span>

# COMMAND ----------

# Add the query





# COMMAND ----------

# MAGIC %md #### Checking our count by state
# MAGIC
# MAGIC We just transformed the data and did a check of the record count, but we might also want to check the total by state and compare with our result in `df_proxy_states`.  There is no `HAVING` clause this time since we filtered out the bad data.
# MAGIC
# MAGIC #### The following cell is Step 5c

# COMMAND ----------

spark.sql("""
SELECT state, COUNT(*) AS businesses
FROM valid_business
GROUP BY state
ORDER BY businesses
""").show()

# COMMAND ----------

# MAGIC %md # Step 6 Identifying businesses in top-level categories using an INNER JOIN<br/><span style="font-size:0.8em;">Based on a formula returning a Boolean value (not using equal)</span>
# MAGIC
# MAGIC The `valid_business` temporary view has all of the businesses in the 9 states we are using as proxies for the 8 metro areas.  The categories column (unless null) has all of the categories a business is in, using the same labels and format as the `title` field in the `top_categories` to the extent those categories are top-level categories.
# MAGIC
# MAGIC **What We Want to Do:** We want each top-level category a business is in to match with the corresponding title in `top_categories`
# MAGIC
# MAGIC **What We CANNOT Do:** We can't say, `valid_business.categories = top_categories.title`, because we can't compare a string (`title`) to an array of strings (`categories`)
# MAGIC
# MAGIC **What We *CAN* Do:*** Spark has an <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.functions.array_contains.html#pyspark-sql-functions-array-contains" target="_blank">array_contains() function</a> that takes two parameters:
# MAGIC * the name of the column with the array
# MAGIC * the value we want to check for
# MAGIC
# MAGIC The function returns a Boolean value True / False 
# MAGIC
# MAGIC Instead of an `=` in the `ON` condition for our `INNER JOIN`, we can use a formula based on the `ARRAY_CONTAINS`function that returns a Boolean, because that's what our `ON` condition needs.
# MAGIC
# MAGIC #### The following cell is Step 6a

# COMMAND ----------

# Complete the ON condition







# COMMAND ----------

# MAGIC %md ### Check if the number of businesses is the same
# MAGIC When we did our join in Step 6a, if a business had 3 top categories, it now has 3 rows. If `categories` was null, then the INNER JOIN would not include those businesses.  However, we can query the `df_valid_business` DataFrame to see how many businesses had NULL for the categories.  The total should tie to the total for `df_valid_business`.
# MAGIC
# MAGIC #### The following cell is Step 6b

# COMMAND ----------

print(f"Businesses with attributes:{df_business_top_categories.select('business_id').distinct().count()}")
  
print(f"businesses without attributes:{df_valid_business.filter('categories IS NULL').count()}")

# COMMAND ----------

# MAGIC %md # <span style="color:#0055A2;">Step 7: Some Additional Queries for Your Team</span>
# MAGIC
# MAGIC Now that we have a row for each business for each top-level category it's in, add queries that calculate the following answers:
# MAGIC
# MAGIC * Step 7a: How many businesses are in each top-level category?  Show the category and a count for all categories  (this should be one query)
# MAGIC * Step 7b: Some businesses are in multiple top-level categories.  Show the number of businesses in 1 - 22 top-level categories (none will actually be in all 22 - see step 6a).  This will require two queryis (based on what we have covered so far).  If you are looking for a little more of a challenge, do it as one query using a Common Table Expression (CTE). See *Learning SQL* - Chapter 9, or *SQL Pocket Guide* - Chapter 9. 
# MAGIC
# MAGIC NOTE: If you want a total, add `WITH ROLLUP` at the end of the `GROUP BY` clause
# MAGIC
# MAGIC #### <span style="color:#0055A2;">Add the query for 7a in the following cell</span>

# COMMAND ----------

# Step 7a: Add your query here to answer 7a






# COMMAND ----------

# MAGIC %md
# MAGIC #### <span style="color:#0055A2;">Add the query for 7b in the following cell</span>

# COMMAND ----------

# Step 7b: Add your query here to answer 7b





# COMMAND ----------





# COMMAND ----------

# MAGIC %md # Step 8 Loading the Review Data
# MAGIC We have done this before, but we are going to load the review data from parquet files we have created previously.  The files are in our DBFS (from when we created a table in Working with Files), but we need to recreate the table definition that was deleted when our cluster shut down.  To do this, we are embedding and running a notebook we have used previously named `Building Review Table` that was loaded along with this notebook when we imported the Databricks archive file.
# MAGIC
# MAGIC After this cell runs, the output will be a bit larger, so we can hide the output for the following cell after it runs.
# MAGIC
# MAGIC #### The following cell is Step 3a

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Checking for our table
# MAGIC The following cell uses a SQL command that shows what tables or temporary views exist.  Our table for our review data should be listed and the output should show that it's not temporary.  Any temporary views we have created will also be listed, but shown as being temporary.
# MAGIC
# MAGIC #### The following cell is Step 3b

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # <span style="color:#0055A2;">Step 9: Bringing Categories, Businesses, AND and Reviews Together</span>
# MAGIC
# MAGIC We will start with the query from Step 6a, but you can eliminate the `ORDER BY` clause.
# MAGIC
# MAGIC From the `valid_business` data, only include the following fields:
# MAGIC * business_id
# MAGIC * name
# MAGIC * state
# MAGIC * review_count
# MAGIC
# MAGIC From the `top_categories` include:
# MAGIC * title (as category)
# MAGIC
# MAGIC From the `reviews_without_text_table` include:
# MAGIC * review_id
# MAGIC * stars
# MAGIC * useful
# MAGIC * funny
# MAGIC * cool
# MAGIC
# MAGIC The first join (business and category data) becomes the LEFT side for the second join and the review data will be the RIGHT side of the second join.
# MAGIC
# MAGIC Assume you had three tables you were joining: Table_A, Table_B, and Table_C
# MAGIC
# MAGIC **Format:**<br/>
# MAGIC FROM Table_A   AS  A INNER JOIN Table_B   AS  B<br/>
# MAGIC ON A.some_field = B.some_field<br/>
# MAGIC INNER JOIN Table_C   AS  C<br/>
# MAGIC ON B.another_field = C.another_field
# MAGIC
# MAGIC #### <span style="color:#0055A2;">The next cell is Step 9</span>

# COMMAND ----------

# Finish the query





