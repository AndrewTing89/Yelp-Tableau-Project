# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md
# MAGIC # Spark SQL Joins 
# MAGIC
# MAGIC Our question we are trying to answer requires us to bring together multiple data files:
# MAGIC * business
# MAGIC * review
# MAGIC * user
# MAGIC * categories (Yelp data, but not from the Yelp dataset)
# MAGIC * gender (the data from the Social Security Administration)
# MAGIC
# MAGIC To bring the data together, we need to match records in one temporary view or table with another temporary view or table.  Telling Spark how to match theise records is known as joining the tables.
# MAGIC
# MAGIC In This notebook we will start with the default join which is an INNER JOIN, but we will discuss all of the following:
# MAGIC * INNER JOIN
# MAGIC * LEFT OUTER JOIN
# MAGIC * FULL OUTER JOIN
# MAGIC * LEFT SEMI JOIN
# MAGIC * LEFT ANTI JOIN
# MAGIC
# MAGIC If you are right-handed, you may be wondering what the deal is with all this lefty stuff.  This will all make sense in a little bit, but any right join can be done with a left join, you just need to change which table or view is on the "left".
# MAGIC
# MAGIC # Loading the Business Data
# MAGIC We will start with joining the business and review data, but first we need to load our data.  We'll load the business data first, and later the review data.
# MAGIC
# MAGIC As a good practice, we are going to:
# MAGIC * Print a count of the number or records (businesses)
# MAGIC * Show 20 rows (the default)
# MAGIC * Print the schema
# MAGIC
# MAGIC #### The following cell is Step 1

# COMMAND ----------

df_business_data = spark.read.json('/yelp/business.bz2')
print ("record count:", df_business_data.count() )
df_business_data.show()
df_business_data.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deciding What Business Data We Need
# MAGIC
# MAGIC This process is iterative, so we could come back later and decide we need additional columns, but for now we are going to include the following:
# MAGIC * business_id (so we can join with our review data)
# MAGIC * name (something human readable)
# MAGIC * categories (so we can identify the type of business and join with the category data)
# MAGIC * state (as a proxy for the metro area)
# MAGIC * review_count (so we can decide how much data we have or need for each business)
# MAGIC * attributes 
# MAGIC * longitude
# MAGIC * latitude
# MAGIC
# MAGIC First we need a temporary view to run a SQL query
# MAGIC
# MAGIC #### The following cell is Step 2

# COMMAND ----------

df_business_data.createOrReplaceTempView("business_data")

df_business = spark.sql("""
SELECT business_id, name, categories, state, review_count, attributes, longitude, latitude
FROM business_data
""")
print ("record count:", df_business.count() )
df_business.show()
df_business.createOrReplaceTempView("business")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Wrangling Our Business Data
# MAGIC
# MAGIC We are going to come back to this step, but any processing we need to do with the business data should be done ***before*** we join it with the review data.
# MAGIC
# MAGIC We have ~160K businesses, but ~8000K reviews.  We don't want to be dragging around 8 million reviews until we are done with or business data.
# MAGIC
# MAGIC Some of the wrangling we would want to do first:
# MAGIC * Identify what categories a business is in
# MAGIC * Figure out how many businesses are not in *any* categories
# MAGIC * Identify the states that are the metro area proxies
# MAGIC   * Identify how many businesses are in each of these proxy states (we did this before)
# MAGIC   * Identify how much "bad data" we have for businesses in other states
# MAGIC   * Filter out data for bad states
# MAGIC * Look at the distribution for review count
# MAGIC * JOIN with our category data (it's smaller than reviews)
# MAGIC   * Identify the top-level categories or data is in
# MAGIC   * How many businesses are in multiple top-level categories?
# MAGIC   * How many businesses are in `Restaurants` (where most of the reviews are)?  How many are in `Home Services` and `Local Services` (where Yelp makes money)?
# MAGIC   * What's the review distribution per business look like for these categories?
# MAGIC   
# MAGIC   <span style="font-size:1.2em; color:blue;">We'll come back to this step later</span> 
# MAGIC   

# COMMAND ----------

# MAGIC %md # Step 3 Loading the Review Data
# MAGIC We have done this before, but we are going to load the review data from parquet files we have created previously.  The files are in our DBFS (from when we created a table in Working with Files), but we need to recreate the table definition that was deleted when our cluster shut down.  To do this, we are embedding and running a notebook we have used previously named `Building Review Table` that was loaded along with this notebook when we imported the Databricks archive file.
# MAGIC
# MAGIC After this cell runs, the output will be a bit larger, so we can hide the output for the following cell after it runs.
# MAGIC
# MAGIC #### The following cell is Step 3a

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Checking for our table
# MAGIC The following cell uses a SQL command that shows what tables or temporary views exist.  Our table for our review data should be listed and the output should show that it's not temporary.  Any temporary views we have created will also be listed, but shown as being temporary.
# MAGIC
# MAGIC #### The following cell is Step 3b

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 4: Bringing Businesses and Reviews Together - An INNER JOIN
# MAGIC
# MAGIC First We will look at an INNER JOIN This will match records in the business data with records in the review data, and there
# MAGIC will be a record in the result for every combination where the fields match.
# MAGIC
# MAGIC We will be matching on the `business_id` file which uniquely identifies each business (each business has a unique `business_id`).
# MAGIC If a business has multiple reviews, the result will include each review as a row, so if a business has 3 reviews in the review data,
# MAGIC there are three rows in the result for that business - and they all of the same values for the business data.
# MAGIC
# MAGIC If the business_id was not unique (similar to joining on `name` instead of business_id), and 2 businesses had the same business_id
# MAGIC and there were three rows in the review data for that business_id, there woould be *six* rows in the result - three for each business.
# MAGIC
# MAGIC If a business has no reviews, it's excluded from the result.
# MAGIC
# MAGIC I a review had no matching busines, it would be excluded from the result.
# MAGIC
# MAGIC When we join, we are going to get a record count and show 20 rows by default.  
# MAGIC
# MAGIC #### The next cell is Step 4

# COMMAND ----------

# Add the ON part of the join
df_inner_join = spark.sql("""
SELECT B.business_id, name, state, review_count, categories, review_id, R.stars, useful, funny, cool
FROM business AS B INNER JOIN reviews_without_text_table  AS R
ON B.business_id = R.business_id
ORDER BY review_count, business_id
""")
print(f"record count: {df_inner_join.count()}")
df_inner_join.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 5: LEFT OUTER JOIN - Did the INNER JOIN Lose Businesses?
# MAGIC If there was a business without any reviews in the data, they were not in the result for the INNER JOIN.
# MAGIC
# MAGIC Here we will do a LEFT OUTER JOIN - this includes every record on the LEFT side of the join, even if there is no matching record on the right-hand side
# MAGIC
# MAGIC **What value will the columns in the result from the right-hand side contain if there was no match?**
# MAGIC
# MAGIC ### Build the LEFT OUTER JOIN Query
# MAGIC * Add a WHERE clause to check for businesses without reviews
# MAGIC
# MAGIC #### The next cell is Step 5

# COMMAND ----------

# Add the WHERE clause
df_left_outer_join = spark.sql("""
SELECT B.business_id, name, state, review_count, categories, review_id, R.stars, useful, funny, cool
FROM business AS B LEFT OUTER JOIN reviews_without_text_table  AS R
ON B.business_id = R.business_id
WHERE review_count = 0
ORDER BY review_count, business_id
""")
print(f"record count: {df_left_outer_join.count()}")
df_left_outer_join.show()


# COMMAND ----------

# MAGIC %md
# MAGIC # Step 6: LEFT ANTI JOIN - Did the INNER JOIN Lose Reviews?
# MAGIC **NOTE:** <span style="color:#0055A2">The review data in now on the LEFT!</span>
# MAGIC
# MAGIC Here the business and review data have switched sides in the join and the reviews are on the left and the business data is on the right
# MAGIC
# MAGIC The LEFT ANTI JOIN can be thought of as a filter query since it only includes columns from the view or table on the LEFT.  
# MAGIC
# MAGIC The rows on the
# MAGIC right-hand side of the join are being used as a filter - any that match records on the left-hand side cause those records to be excluded from the result.
# MAGIC
# MAGIC If there are any reviews with a `business_id` where there is not a corresponding business in the business data, they will be in our result.
# MAGIC
# MAGIC #### Complete the Query
# MAGIC * Add the `SELECT` clause
# MAGIC
# MAGIC #### The next cell is Step 6

# COMMAND ----------

# Add the SELECT clause
df_left_anti_join = spark.sql("""
SELECT *
FROM reviews_without_text_table AS R LEFT ANTI JOIN business AS B
ON R.business_id = B.business_id
ORDER BY business_id
""")
print(f"record count: {df_left_anti_join.count()}")
df_left_anti_join.show()

# COMMAND ----------

# MAGIC %md # Step 7: FULL OUTER JOIN 
# MAGIC With a FULL OUTER JOIN:
# MAGIC * Any businesses (on the left) without a review would have NULL for the `review_id`
# MAGIC * Any review (on the right) without a business would have a NULL for the `business_id`
# MAGIC * This allows us to check for BOTH businesses without reviews and reviews without businesses in a single query
# MAGIC
# MAGIC #### Complete the Query
# MAGIC * Add the `WHERE` clause
# MAGIC
# MAGIC #### The next cell is Step 7

# COMMAND ----------

# Add the WHERE clause
df_full_outer_join = spark.sql("""
SELECT B.business_id, name, state, review_count, categories, review_id, R.stars, useful, funny, cool
FROM business AS B FULL OUTER JOIN reviews_without_text_table  AS R
ON B.business_id = R.business_id
WHERE R.business_id IS NULL OR B.business_id IS NULL
""")
print(f"record count: {df_full_outer_join.count()}")
df_full_outer_join.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 8: Filtering with a LEFT SEMI JOIN
# MAGIC
# MAGIC This is also a query that filters records - including only records from the table or view on the left that are also in the table or view on the right.
# MAGIC
# MAGIC This is similar to an INNER JOIN, but with one difference - which columns can be included in the result! 
# MAGIC
# MAGIC If you are filtering, it's more efficient than an INNER JOIN.
# MAGIC
# MAGIC #### First we will build some data to join with - useful reviews with 1 star
# MAGIC
# MAGIC First, we are going to create a temporary view that includes only those reviews where the rating was 1-star, but it received at least one useful vote.

# COMMAND ----------

df_useful_negative_reviews = spark.sql("""
SELECT * 
FROM reviews_without_text_table
WHERE stars = 1 AND useful > 0
""")
print(f"record count: {df_useful_negative_reviews.count()}")
print(f"business count: {df_useful_negative_reviews.select('business_id').distinct().count()}")
df_useful_negative_reviews.show(truncate=False)
df_useful_negative_reviews.createOrReplaceTempView("useful_negative_reviews")

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md #### LEFT SEMI JOIN
# MAGIC In this query, the business is on the left, so we are filtering for businesses where the business_id matches the usiness_id of one of the reviews on the right-hand side.
# MAGIC
# MAGIC **QUESTION: <span style="color:#0055A2">What is in the result for a business if <i>multiple</i> reviews have the same business id?</span>**
# MAGIC
# MAGIC #### The following cell is Step 8: Build the the LEFT SEMI JOIN query
# MAGIC * Remember what you can SELECT with SEMI and ANTI joins
# MAGIC * Remember to join with the `useful_negative_reviews` as the review data
# MAGIC * Does the record count match the business count above?
# MAGIC * Try changing the query above to 5-stars, or funny, or cool

# COMMAND ----------

df_semi_join = spark.sql("""
SELECT *
FROM business AS B LEFT SEMI JOIN useful_negative_reviews AS R
ON B.business_id = R.business_id
ORDER BY review_count, business_id


""")
print(f"record count: {df_semi_join.count()}")
df_semi_join.show(truncate=30)

# COMMAND ----------

