# Databricks notebook source
# MAGIC %md # Loading Gender Data From the Social Security Administration
# MAGIC
# MAGIC We don't have information about the user's gender. But we can use the gender of a user's first name as a proxy for their gender. The Social Security Administration (SSA) page titled <a href="https://www.ssa.gov/oact/babynames/limits.html" target="_blank">Beyond the Top 1000 Names</a> has a zipfile we can download with every first name used to apply for a social security account and a count
# MAGIC of the number of men and women applying with that name, based on their date of birth.  The zip file contains a file for each year-of-birth, so 
# MAGIC for those little girls and boys born in 2017 who applied for a social security card, the file is named `yob2017.txt` and it contains data in the following
# MAGIC format:
# MAGIC
# MAGIC Emma,F,19738 <br/>
# MAGIC Isabella,F,15100 <br/>
# MAGIC Sophia,F,14831 <br/>
# MAGIC Mia,F,13437 <br/>
# MAGIC Liam,M,18728 <br/>
# MAGIC Logan,M,13974 <br/>
# MAGIC Benjamin,M,13733
# MAGIC
# MAGIC As you can see, the file has 3 columns, the name, the gender (M or F), and the number of people with that name who were born in a specific year and applied for a social security card.  You should also note there are no headers.
# MAGIC
# MAGIC It does not say what year the data is from, but the year is in the name of each file.
# MAGIC
# MAGIC Using `dbutils.fs`, we will create a new directory named `ssa` where we are going to download the zip file from the SSA: `names.zip`.  However, we use the `file:` prefix for the path to say we want to create the directory local to the driver node for our cluster.  We need to do this because we cannot treat DBFS as a local file system.  Later we will move the zipped and unzipped data to DBFS.

# COMMAND ----------

import requests
import urllib

SSA_URL = "https://www.ssa.gov/oact/babynames/names.zip"
SSA_DIR ="/ssa/"
SSA_FILENAME = "names.zip"

# If the ssa directory exists, remove it
dbutils.fs.rm("file:"+SSA_DIR, recurse=True)
dbutils.fs.mkdirs("file:"+SSA_DIR)

urllib.request.urlretrieve(SSA_URL, SSA_DIR+SSA_FILENAME)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unzipping the data
# MAGIC
# MAGIC **Keep in mind that when we are running the zip commands, we are just using Python and not Spark**.  Why does that matter?  The paths we provide
# MAGIC are not pointing to paths on DBFS (since the plain old Python does not "know" about DBFS).  When we use the path "/ssa", the zip command assumes
# MAGIC we are talking about the `ssa` directory off the root of the driver node.  If we use the path "/ssa" in a dbutils command, it assumes we are
# MAGIC referring to a DBFS path since we did not prefix the path with `file:`.
# MAGIC
# MAGIC Once we unzip the data, we must move the directory to DBFS.  While data on DBFS will remain when our cluster shuts down, the files 
# MAGIC local to the driver will not exist once the cluster is shutdown.

# COMMAND ----------

import zipfile

SSA_SUBDIR = "data"
ssaDataDir = "file:" + SSA_DIR + SSA_SUBDIR
dbutils.fs.mkdirs(ssaDataDir) 

ssaNamesZip = SSA_DIR + SSA_FILENAME

with zipfile.ZipFile(ssaNamesZip,"r") as zip_ref:
    zip_ref.extractall(SSA_DIR + SSA_SUBDIR)
    
# Move the files to DBFS
dbutils.fs.rm("dbfs:"+SSA_DIR, recurse=True)
dbutils.fs.mv("file:"+SSA_DIR, "dbfs:"+SSA_DIR, recurse=True)

print(f"Number of files downloaded: {len(dbutils.fs.ls('/ssa/data/') ) }")