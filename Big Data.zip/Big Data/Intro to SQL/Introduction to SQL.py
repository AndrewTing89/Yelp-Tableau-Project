# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This ds4all notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md
# MAGIC # Introduction to SQL
# MAGIC
# MAGIC In this notebook we will start exploring the use of Spark SQL which allows you to run SQL commands against temporary views created from DataFrames, or tables created from files.  The queries we will be doing in this notebook introduce you to the main clauses of a SQL query.
# MAGIC
# MAGIC In the Working with Files exercise, you loaded the Yelp dataset as well as some additional data on Yelp's business categories and some data from the Social Security Administration (SSA).  As part of that exercise, 
# MAGIC you created tables for the review and user data.  When you created the tables, the code first created DataFrames, and then wrote those DataFrames out as tables using a file format known as Parquet. This is a very common data format in Big Data, but it also allows us to access the data more efficiently since Parquet uses an approach known as a column store. When doing a query, this format allows Spark to only load the data for the columns actually used in the query.  Although the table definitions were deleted when your cluster shut down, the Parquet files still remain in the hive data warehouse directory on DBFS for your account, so we can recreate the tables quickly from those files (e.g., the review data requires approximately 20 minutes to load into a DataFrame from JSON files, but less than a minute to load into a table from the Parquet files).
# MAGIC
# MAGIC In this notebook we will be doing some profiling of your data to do what Max Shron describes in the CoNVO framework as "Rapid Investigations".  Some of the exercise we will do in class, and the remaining profiling will be left for you to complete as part of the assignment, but it will be described in the markdown and build on what we have done in class.

# COMMAND ----------

# MAGIC %md
# MAGIC # Querying the Business Data
# MAGIC In this exercise we are going to look at two of the data files loaded in the `Working with Files` notebook - The business and review data.
# MAGIC
# MAGIC First, we are going to load the business data from the JSON file as we have done before.  As a good practice, we are going to:
# MAGIC * Print a count of the number or records (businesses)
# MAGIC * Show 20 rows (the default)
# MAGIC * Print the schema
# MAGIC
# MAGIC #### The following cell is step 1

# COMMAND ----------

df_business = spark.read.json('/yelp/business.bz2')
print ("record count:", df_business.count() )
df_business.show()
df_business.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Create Temporary Views
# MAGIC   We cannot query a DataFrame directly using the `spark.sql()` method of our spark session.  Instead, we first need to create a temporary view
# MAGIC   from the DataFrame.  Similar to a DataFrame, a temporary view exists in memory, and similar to DataFrames, Spark keeps track of the "recipe" for 
# MAGIC   creating the temporary view if it needs to remove it from memory (if it runs out of space).
# MAGIC   In the following cell, we create a temporary view for the `df_business` DataFrame.
# MAGIC   
# MAGIC   ![Temporary View](http://www.sjsu.edu/people/scott.jensen/AoMBigDataWorkshop/TemporaryView.png)
# MAGIC   
# MAGIC   **Remember:** The DataFrame method for creating a view is long (`createOrReplaceTempView`), but if your DataFrame already exists, after you type the 
# MAGIC   DataFrame's name and the "dot", just type "cr" for the start of the method name and press the tab key.  Spark will display a list of methods
# MAGIC   for the DataFrame that start with "cr", just be careful that you pick the correct method.  If you don't select the "OrReplace" version of the method,
# MAGIC   if you run the cell again in the same session,  without first dropping the view, you will get an error because the view already exists.

# COMMAND ----------

df_business.createOrReplaceTempView("business")

# COMMAND ----------

# MAGIC %md ###Step 3: The Most Basic Query: SELECT and FROM
# MAGIC
# MAGIC In the following cell, our first Spark SQL query is the most basic in that it just uses the two clauses that must be included in each query: SELECT and FROM. The FROM clause tells Spark which temporary view or table we want to use.  This is the only place you can use a temporary view, and we cannot directly use a DataFrame in a query. Instead, as we did above, we must first create a temporary view.  The SELECT clause tells Spark which columns from our temporary view we want to include in our query result.  The SELECT clause is a comma-separated list of fields, although it can also include functions, formulas, or even literal values (strings or numbers which would have the same value for every row).
# MAGIC
# MAGIC To run our query, we use the `sql` method which is NOT a DataFrame method, but instead a method of the Spark session that was created for us when we started a cluster and is always named `spark`.  The <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.SparkSession.sql.html#pyspark-sql-sparksession-sql" target="_blank">sql</a> method takes one parameter - our query as a string, so the query must be enclosed in quotation marks.
# MAGIC
# MAGIC **Why is the query surrounded by triple quotation marks?** You may have noticed that we have put each of the two clauses on a separate line and that the query itself is a string enclosed in triple quotation marks.  Keep in mind that we are using Python, and `spark.sql()` is a python method of the Spark session class, and in Python, if you want a string to span multiple lines, you use triple quote marks to surround it.  If we need to use quotation marks inside our queries, we will use single quote marks to avoid confusion.  Python will allow you to use a single pair of double quotes also (a single pair of double quotes is not seen in Python as the same as a triple pair, so we could use a single pair inside a query, but it could be confusing to someone reading our query later).
# MAGIC
# MAGIC The SELECT and FROM clauses do not have to be on separate lines, but it makes our queries more readable if each clause starts on a new line - particularly as our queries become more complex. You may have also noticed that the `SELECT` and `FROM` are in capital letters.  Unlike social media, this does not mean we are shouting, but is a common convention in that it's easier to tell the SQL terms from our variable names which are lower case.  When we start using SQL functions in our queries, we will also capitalize those terms.  While SQL is not case sensitive regarding keywords, Python is, so `spark.sql` must all be lower case.
# MAGIC
# MAGIC #### The following cell is Step 3

# COMMAND ----------

df_working_business = spark.sql("""
SELECT business_id, name, state, city, review_count, stars, is_open, attributes, categories
FROM business
""").cache()
df_working_business.show()

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 4: Adding a WHERE Clause
# MAGIC The `SELECT` clause tells Spark which columns we want in our result (and also the order of those columns).  If we want only some of the rows from our temporary view, we can use the `WHERE` clause.
# MAGIC
# MAGIC In another exercise we were looking at the states in our dataset and generated a DataFrame containing only the businesses in Massachusetts (MA).  to do that in a SQL query we can use the WHERE clause and compare the `state` field to the string 'MA'.  Notice that since the `state` field is a string value, we need to enclose MA in quotation marks, and here we use single quotes for that purpose.
# MAGIC
# MAGIC Since our above query selected out the business columns we are going to use in this notebook, if we want to build on the results of our prior query, we need to first create a new temporary view from the resulting `df_working_business` DataFrame.
# MAGIC
# MAGIC The `WHERE` clause always comes after the `FROM` clause and provides the condition that the rows included in our result should match.  Here we are saying we want rows where the `state` field matches the string value MA. If we wanted our result to include only those businesses in Massachusetts that had an average rating of 4.0 stars or more (the "stars" field in the business data is the average rounded to 0.5-star increments) we could use:<br/>
# MAGIC WHERE state = 'MA' AND stars >= 4.0
# MAGIC
# MAGIC **Question:** What if we wanted businesses in Massachusetts OR Ohio that were 4.0 stars or higher?
# MAGIC
# MAGIC One possibility is to combine these in the WHERE clause as follows:<br/>
# MAGIC WHERE (state = 'MA' OR state = 'OH') AND stars >= 4.0
# MAGIC
# MAGIC However, since two of the conditions are on the state field, we could alternately use the following:<br/>
# MAGIC WHERE state IN ('MA','OH') AND stars >= 4.0<br/>
# MAGIC The `IN` compares the value in the `state` column for each row to the comma-separated list of values in the parenthesis.
# MAGIC
# MAGIC In the `SELECT` clause we need to say which columns we want, and for this query we are going to include all of the columns in our prior query, so we can use the asterisk (\*) as a wildcard to mean all of the columns in our temporary view. 
# MAGIC
# MAGIC **NOTE**: Similar to the `show` method, `createOrReplaceTempView` does not return a DataFrame (or any value), so we cannot add that to the end of our prior query, but instead need to create the view on a separate line.
# MAGIC
# MAGIC #### The following cell is Step 4

# COMMAND ----------

# Modify the query to include only those businesses in MA or OH with a star rating of 4.0 or higher
df_working_business.createOrReplaceTempView("working_business")

spark.sql("""
SELECT *
FROM working_business
WHERE state IN ('MA', 'OH') AND stars >= 4.0
""").show()

# COMMAND ----------

spark.sql("""
SELECT *
FROM working_business
WHERE (state='MA' OR state='OH') AND stars >= 4.0
""").show()

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 5: Aggregate Functions and GROUP BY 
# MAGIC
# MAGIC The `WHERE` clause allowed us to filter out rows and only keep those we wanted, but it was applied individually to each row.
# MAGIC
# MAGIC If we wanted to calculate across rows, we need to use aggregate functions and grouping.  As described in the ***SQL Examples*** notebook, some of the common aggregate functions are:<br/>
# MAGIC * COUNT (number of rows in each group)
# MAGIC * SUM (sum of a column for the group)
# MAGIC * MIN, MAX, AVG (the lowest, highest, or average value of a column for each group)
# MAGIC * STDDEV (standard deviation of a column for each group)
# MAGIC * FIRST, LAST (The value for the first or last row in a group) 
# MAGIC * DISTINCT (not an aggregate function, but often used with aggregation to not include duplicates)
# MAGIC
# MAGIC #### Aggregating without grouping
# MAGIC
# MAGIC If we want to aggregate all of the records, we can omit a `GROUP BY` clause.<br/>
# MAGIC **Example**: The `is_open` field contains the value 1 if a business is still operating, but a 0 if they have gone out of business.<br/>
# MAGIC SELECT COUNT(\*)<br/>
# MAGIC FROM working_business<br/>
# MAGIC WHERE is_open = 0
# MAGIC
# MAGIC **How could we instead use `SUM` without a `WHERE` clause?**
# MAGIC
# MAGIC #### The following cell is Step 5a

# COMMAND ----------

# Finish the query to get a total of the number of businesses in the data that went out of business
# using the SUM aggregate function, but no WHERE clause
spark.sql("""
SELECT SUM(1-is_open) AS closed
FROM working_business
""").show()

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Aggregating with GROUP BY
# MAGIC If, instead of an overall total, we want subtotals based on some column, then we Need a `GROUP BY` clause, which always comes after the `WHERE` clause.
# MAGIC
# MAGIC Before we looked at using a WHERE clause to get only the businesses in certain state, but maybe we want to get the number of businesses in each state. For that we could `GROUP BY` state.
# MAGIC
# MAGIC In the following cell, complete the query to get a count of the businesses in each state.  For this we are going to use the `COUNT` function, but we have to tell Spark what column we want to count.  When selecting the column to count, we need to decide if we want to count null values.  If we count on a column with null values, the rows that are null for that column are omitted.
# MAGIC
# MAGIC If we want to include all rows, we can use COUNT(\*) or COUNT(1)
# MAGIC
# MAGIC The COUNT(1) alternative may seem odd, but we can use any literal value (a number, string, or boolean), and it will count the number of rows.  You can even use:<br/>
# MAGIC COUNT("I did it my way!")<br/>
# MAGIC We could even use SUM(1), but COUNT(\*) would be what other people are expecting to see.
# MAGIC
# MAGIC #### Columns in the SELECT clause when GROUP BY is used
# MAGIC
# MAGIC It may not seem obvious at first, but if we just wanted to count the number of businesses, we would just have `state`, the field we want to `GROUP BY` and the `COUNT(*)` function in the `SELECT` clause.  Why not any of the other columns?  When we GROUP BY state, if we also included the `city`  column, which city should be displayed for each state?
# MAGIC
# MAGIC When we use `GROUP BY`, any field in the `SELECT` either has to be enclosed in an aggregate function or in the `GROUP BY` clause. 
# MAGIC
# MAGIC If you are ever writing a query and including an ID field in the `GROUP BY` clause that is unique for each record (such as the `business_id` column in the Yelp business data), then something has gone horribly wrong with your query.
# MAGIC
# MAGIC #### The following cell is Step 5b

# COMMAND ----------

# Complete the query to get a count of the number of businesses in each state
spark.sql("""
SELECT state, COUNT(*) AS businesses 
FROM working_business
GROUP BY state
""").show(100)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 6: Filtering Grouped Data Using HAVING
# MAGIC
# MAGIC After we counted the businesses by state, we see that we have some bad data - we are supposed to have 8 metro areas, and some states have less than 100 businesses.  
# MAGIC
# MAGIC In our prior grouped query result, the number of businesses in each state is in the column `businesses`. We want to include only those rows where `businesses` is more than 1000.  We can't add this as a condition in our `WHERE` clause since we don't have that column until we have calculated the grouping.  This is where the `HAVING` clause can be used - it works similar to the `WHERE` clause, but the condition is based on the grouped result.
# MAGIC
# MAGIC The `HAVING` clause is always after the GROUP BY clause.
# MAGIC
# MAGIC
# MAGIC #### The following cell is Step 6

# COMMAND ----------

# Add the HAVING clause to the query
spark.sql("""
SELECT state, COUNT(*) AS businesses
FROM working_business
GROUP BY state
HAVING businesses >1000
""").show()

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 7: Sorting Using ORDER BY
# MAGIC
# MAGIC In the query result for step 6 above, we have the 9 states that comprise our 8 metro areas, but we might want to sort them either:
# MAGIC * •	alphabetically by state
# MAGIC * numerically by the number of businesses
# MAGIC
# MAGIC For this calculation we will sort them based on the number of businesses in descending order.  The `ORDER BY` clause comes after the `GROUP BY` and `HAVING` clauses (if they are used in the query).  We can sort on multiple fields, and we can sort in ascending order (smallest to largest), which is the default, or in descending order by including `DESC` after the field we are sorting on.
# MAGIC
# MAGIC #### The following cell is Step 7

# COMMAND ----------

# Copy the query for step 6 and add the ORDER BY clause
spark.sql("""
SELECT state, COUNT(*) AS businesses
FROM working_business
GROUP BY state
HAVING businesses >1000
ORDER BY businesses DESC
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 8: Summary Statistics
# MAGIC
# MAGIC For this step we are going to dip back into PySpark.  Although there are some SQL commands we can use, the functions for getting summary information work on tables (such as our `reviews_without_text_table ` table), but not with temporary views such as `working_business`.  Here we will look at two DataFrame methods:
# MAGIC * describe - returns the count, mean, standard deviation (stddev), min, and max for each column in the DataFrame
# MAGIC * summary - by default returns the values calculated by describe, plus the quartiles 25%, 50%, and 75%
# MAGIC
# MAGIC The `describe` method has a fixed set of statistics it will return. The `summary` method with no parameters returns a fixed set of calculations, some of which are similar, but you can also specify only some of the stats or also include other percentiles in quotation marks (e.g., "10%", "20%", etc.)
# MAGIC
# MAGIC Here we are first running the `select` DataFrame method on our `df_working_business` DataFrame to get only the numeric `review_count` and `stars` columns, and then calling each method.
# MAGIC
# MAGIC Looking at the summary for the `review_count` we realize that although there are some businesses with lots of reviews, the median business has only 17 reviews and even the 75th percentile is only 44 reviews.  This means we will need to look at the metro areas and the categories businesses operate in - possibly smaller metro areas have fewer reviews per business.  Similarly, possibly restaurants have a lot of reviews, but a lot of other business categories do not.

# COMMAND ----------

df_working_business.select("review_count", "stars").describe().show(truncate=False)

# COMMAND ----------

df_working_business.select("review_count", "stars").summary().show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 9a: Rapid Investigation
# MAGIC In the following cell we are going to build on the query in Step 7 where we calculated the number of businesses in each state that represents a metro area (one of the metro areas is represented by two states).
# MAGIC
# MAGIC After copying that query, we are going to add the following calculations to it:
# MAGIC * Average number of reviews per business in each state
# MAGIC * Maximum number of reviews for a business in each state
# MAGIC * Number of closed businesses in each state
# MAGIC * Number of businesses without any business categories specified
# MAGIC * Number of businesses without any attributes
# MAGIC
# MAGIC When a business has no value for the `categories` or `attribute` column, the value in that column is null.  We cannot compare to say if a column is equal to null, because null is not equal to anything.  However, we can say:<br/>
# MAGIC categories IS NULL<br/>
# MAGIC or<br/>
# MAGIC categories IS NOT NULL
# MAGIC
# MAGIC But we need to be able to do that calculation in the `SELECT` clause and not the `WHERE` clause, since we don't want to exclude the businesses without attributes or categories, we just want to count them.  To do this we will use the SQL `IF` function, which if you have ever created an Excel spreadsheet is amazingly similar to the IF function there:<br/>
# MAGIC IF( some_condition, then_value, else_value)
# MAGIC
# MAGIC For our purposes, the condition would be:<br/>
# MAGIC attributes IS NULL
# MAGIC
# MAGIC #### The following cell is Step 9a

# COMMAND ----------

# build your query here based on the query for step 7

df_avg_reviews = spark.sql("""
SELECT state, COUNT(*) AS businesses, AVG(review_count) AS avg_reviews, MAX(review_count) AS max_reviews, SUM(1-is_open) AS closed, SUM(IF(categories IS NULL,1,0)) AS no_categories, SUM(IF(attributes IS NULL,1,0)) AS no_attributes
FROM working_business
GROUP BY state
HAVING businesses >1000
ORDER BY businesses DESC
""").show()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 9b: Rapid Investigation - Counting Attributes
# MAGIC In Step 9a asked a lot of summary questions about the business data, including the number of businesses with no attributes. What if we wanted to know the average number of attributes each business had?
# MAGIC
# MAGIC If the `attributes` field was an array or map (like a dictionary in Python), we could use the `SIZE` function to get the number of array entries or name:value pairs in the map.  However, the `SIZE` function will not work with a struct.<br/>
# MAGIC However:
# MAGIC * Since our struct came from JSON data, we could convert it back to JSON using the `TO_JSON` method 
# MAGIC * We can convert the JSON into a map using the `FROM_JSON` method.
# MAGIC * The `FROM_JSON` method requires a schema saying what's in the structure.  Here the fact that Yelp turned all of the values into strings is helpful (instead of having nested JSON objects for name:value pairs such as parking).  This means that we can say the schema for the `attributes` field is `MAP<STRING,STRING>`.
# MAGIC * Once we have our map for the `attributes` field, we can use the `SIZE` method on the map, but we have a wrinkle here, if the `attributes` field is null, when we feed it to `SIZE` we don't get back 0, we get back -1.  To solve this problem, we can use the `IF` function to see if attributes is null.
# MAGIC
# MAGIC You will not be expected to generate this code, but if you already know SQL, you could explore using some of the Spark SQL functions to write queries. Every function listed in the <a href="https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql.html#functions" target="_blank">PySpark function documentation</a> has a counterpart that can be used directly in a SQL query on Spark.

# COMMAND ----------

spark.sql("""
SELECT state, COUNT(*) AS businesses,
       AVG( IF(attributes IS NULL, 0, SIZE(FROM_JSON( TO_JSON(attributes),  "MAP<STRING,STRING>") ) ) ) AS average_attributes
FROM working_business
GROUP BY state
HAVING businesses > 1000
ORDER BY businesses DESC
""").show()

# COMMAND ----------

# MAGIC %md 
# MAGIC # Querying the Review Data
# MAGIC
# MAGIC First, we need to rebuild the table definitions from the parquet files we previously created for the `reviews_without_text_table ` table. We built the tables during the Working with Files exercise, and we are rebuilding the table using the same approach used in the SQL Examples notebook.  In the following cell we are running the `Building Review Table` notebook that was in the same folder as the Introduction to SQL notebook in the Databricks archive folder we loaded.  That notebook will rebuild the tables for us, and then we will show the tables to be sure it's loaded again.

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 10: Summary Statistics for Reviews
# MAGIC
# MAGIC In the following cell, generate summary statistics for the useful, funny, and cool vote columns using the same approach we did in Step 8 with the business data. 
# MAGIC
# MAGIC **One wrinkle:**  You have a table and the function takes a DataFrame.  You can use the `read` method of the Spark session to create a `DataFrameReader` (as we did for the business data), but instead of using the `json` method with the path to the JSON file as a parameter, use the `table` method which takes the name of the table as a parameter. alternately, write a simple Spark SQL query against the table to get the columns you need - the query will return a DataFrame.
# MAGIC
# MAGIC Columns to Analyze:
# MAGIC * useful
# MAGIC * funny
# MAGIC * cool
# MAGIC
# MAGIC #### The following cell is Step 10

# COMMAND ----------

# Create the DataFrame and add the calculation of the summary statistics for reviews in this cell
df_reviews_without_text_table = spark.read.table('reviews_without_text_table')

df_reviews_without_text_table.createOrReplaceTempView("reviews")

df_reviews_without_text_table.select("useful", "funny", "cool").summary().show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 11: Rapid Investigation for Reviews
# MAGIC   
# MAGIC One of the issues we need to look at is that earlier years have a lot less data, which likely meant fewer eyeballs looking at reviews and voting on reviews.
# MAGIC
# MAGIC If all of a business' "earlier reviews" were when there were fewer users on Yelp, maybe they would have a different result.  We want to find out some information about the reviews and votes per year.
# MAGIC
# MAGIC Although the `date` field in our review data is a string, it's in a format that Spark SQL will recognize as a date, and one of the date functions is `YEAR()`, so we can use `YEAR(date)` in our query to get the year when each review was written.
# MAGIC
# MAGIC Create a query in the following cell that uses the data from the `reviews_without_text_table` and calculates the following information by year (with the results sorted chronologically):
# MAGIC * Number of reviews per year
# MAGIC * Average and maximum useful votes per review per year
# MAGIC * Average and maximum funny votes per review per year
# MAGIC * Average and maximum cool votes per review per year
# MAGIC
# MAGIC ***NOTE:*** You can query a table the same way you query a temporary view
# MAGIC
# MAGIC #### Add your query in the following cell
# MAGIC

# COMMAND ----------

# Add your rapid investigation query as described for the review data in this cell
spark.sql("""
SELECT YEAR(date) AS year_written, COUNT(*) AS reviews, AVG(useful) AS avg_useful, MAX(useful) AS max_useful, AVG(funny) AS avg_funny, MAX(funny) AS max_funny, AVG(cool) AS avg_cool, MAX(cool) AS max_cool
FROM reviews
GROUP BY year_written
ORDER BY year_written
""").show()


# COMMAND ----------

# MAGIC %md
# MAGIC # Submitting Your Notebook
# MAGIC
# MAGIC After you have completed the additional queries described above, publish your notebook and submit the published URL.

# COMMAND ----------

