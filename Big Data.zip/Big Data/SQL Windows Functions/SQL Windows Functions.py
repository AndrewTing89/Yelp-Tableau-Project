# Databricks notebook source
#TBD5 - Andrew Ting, Bao Pham, Michelle Tran, Emily Wong, Emmanuel Zarate - we all worked seperately and came together in the end to ask each other questions and compare codes

# COMMAND ----------

# MAGIC %md 
# MAGIC Copyright &copy; 2022 Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md
# MAGIC # Windows Functions
# MAGIC
# MAGIC This is a type of function we can use in the SELECT clause that is totally different from other SQL or Spark SQL functions we have looked at.  These allow us to:
# MAGIC * Partition or group rows independent of any GROUP BY clause in the query
# MAGIC * Allows us to calculate values based on those partitions, but for ***each record*** in the partition, unlike a GROUP BY clause which only allows us to calculate an aggregate for the whole group
# MAGIC * Allows us to sort within these partitions, ***independent of*** any ORDER BY clause for the query
# MAGIC * Allows for calculations that considers other records in the partition ***sequentially*** (e.g., the preceding or next record based on the sort order in the partition) 
# MAGIC
# MAGIC #### Function Syntax:
# MAGIC
# MAGIC &lt; window function &gt; **(**field expression**)** **OVER (** PARTITION BY &lt; field(s) &gt; ORDER BY &lt; field(s) &gt; ROWS &lt; frame &gt;**)**
# MAGIC
# MAGIC **NOTE:**
# MAGIC * The above defines one column in the SELECT clause
# MAGIC * You would alias as you do every calculated column in the SELECT clause
# MAGIC * he part after **OVER** defines the partition of rows and their order
# MAGIC * The part before **OVER** defines what we are doing on each partition
# MAGIC * if the parenthesis after **OVER** are empty, the function operates on all of the data as a single group
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md # Creating the Review Data Table `reviews_without_text_table`
# MAGIC The following two cells load your Yelp review data into a table named `reviews_without_text_table` and then shows all tables existing on the cluster.
# MAGIC
# MAGIC To load the review data, we call a separate notebook named `Building Review Table` to create the table.  If you have previously run the `Working with Files` exercise, this will run very quickly (less than a minute), but if you have not completed `Working with Files` it could take 20 minutes to run.
# MAGIC
# MAGIC Since the reviews data is large, we are excluding the text field (this is the actual text of the review and the most space used.  Since we don't use it in this notebook, we don't want to be dragging it around)
# MAGIC
# MAGIC In the `Building Review Table` notebook you may notice that for the review data we also call the `cache()` method at the end of that line.  This holds the data in memory (instead of just keeping a "recipe" for how to create the data), this speeds up the other queries, but be *very* careful when using `cache` since if you cache too much, you will run out of memory and get a heap space error (Java-speak for running out of memory).  If you use the `cache` method, call the `unpersist()` method on the cached DataFrame when you no longer need it, and then it won't keep hogging your memory. Since we save the DataFrame out as a table, we then `unpersist` it since we do not directly access it again.
# MAGIC
# MAGIC After running the following cell, you may want to hide the output, but make sure it has completed running first.
# MAGIC
# MAGIC #### The following cell is step 0:

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 1: Assigning the order of the reviews within each business
# MAGIC
# MAGIC In the following query on the review data, we are going to partition the data based on the `business_id` field, so each business is its own partition.
# MAGIC
# MAGIC We want to number each review with the order in which the review was posted for the business it's reviewing. The first review for a business would be identified as 1 (separately for every business), and the second review posted for that particular business would be review 2, and so on.  Since we want to number the reviews in the order posted, we will sort the reviews within the partition based on the `date` field.
# MAGIC
# MAGIC To number the reviews, we will use the `ROW_NUMBER` windows function.  Since the row number is not calculated based on any column, but is just based on the sort order, the parenthesis after `ROW_NUMBER` are empty. We will alias the whole function as `review_order`, which will be the name of the column this function adds to the result.
# MAGIC
# MAGIC #### The following cell is step 1:

# COMMAND ----------

# Build the review_order calculation
df_ordered_reviews = spark.sql("""
SELECT *,
     ROW_NUMBER() OVER (PARTITION BY business_id ORDER BY date) AS review_order
FROM reviews_without_text_table
ORDER BY business_id, review_order
""")
print(f"review count:{df_ordered_reviews.count()}")
df_ordered_reviews.show(200, truncate=False)
df_ordered_reviews.createOrReplaceTempView("ordered_reviews")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Identifying Bins at Each Business
# MAGIC In the query for step 1,  some of the businesses shown only had 5 - 6 reviews in total, but another had 147 reviews.  
# MAGIC
# MAGIC We need to decide on a bin size, but first we should do some profiling to determine the distribution for review counts overall, and possibly by top-level categories.  
# MAGIC For this exercise we are going to use a bin size of 10, so the first 10 reviews at a business are bin 1, reviews 1-20 are bin 2, etc.  Here we could use the `LAG` windows function, but we will cover that later, plus there are easier calculations we could do for the bin number.
# MAGIC
# MAGIC Since we may want to explore multiple bin sizes later, we want something flexible.  If we cap the number of bins considered for any business, we could use a `CASE` function, but we would need to do a lot of re-coding if we want to change the bin size. Consider a business with 20 records as shown below:
# MAGIC
# MAGIC |review_id             |business_id           |date               |useful|review_order|bin #<br/>size = 3 | bin #<br/>size = 10 |
# MAGIC | -------------------- | -------------------- | ----------------- | ---- | ---------- | ------------------------ | ------------------------- |
# MAGIC |HcZ2W-oRHgnP6Zs0xYfoUw|--164t1nclzzmca7eDiJMw|2009-03-17 01:53:31|9     |1           | 1 | 1 |
# MAGIC |6kurfVrLY9LuZnH-5GGCgQ|--164t1nclzzmca7eDiJMw|2009-03-24 00:15:04|1     |2           | 1 | 1 |
# MAGIC |eKTlMEpr163ZegnJmHYrqA|--164t1nclzzmca7eDiJMw|2009-03-24 16:46:52|5     |3           | 1 | 1 |
# MAGIC |fvuwn2Aa3SNGeCTlC3O8Ew|--164t1nclzzmca7eDiJMw|2009-03-24 19:13:33|2     |4           | 2 | 1 |
# MAGIC |qUCBZ2I5Cuf3J4Yzn5k21g|--164t1nclzzmca7eDiJMw|2009-05-15 21:17:39|1     |5           | 2 | 1 |
# MAGIC |qrYMDYqXk6q3TZ2behT0gQ|--164t1nclzzmca7eDiJMw|2009-05-18 19:10:29|1     |6           | 2 | 1 |
# MAGIC |xp1L_gqkrU7-RcUYkvCobA|--164t1nclzzmca7eDiJMw|2009-05-19 14:35:33|0     |7           | 3 | 1 |
# MAGIC |F-edSmM7xoIH6mYBj1orXw|--164t1nclzzmca7eDiJMw|2009-05-20 20:02:39|0     |8           | 3 | 1 |
# MAGIC |ASpWBdx3gagkN1gbvvgFxg|--164t1nclzzmca7eDiJMw|2009-05-29 02:42:07|0     |9           | 3 | 1 |
# MAGIC |Nf8ekrd4R8cclmcY3C5fCw|--164t1nclzzmca7eDiJMw|2009-06-04 19:08:01|0     |10          | 4 | 1 |
# MAGIC |ZhwQUEK4r-7zLh3aY-VjnQ|--164t1nclzzmca7eDiJMw|2009-06-04 22:41:29|0     |11          | 4 | 2 |
# MAGIC |4vqgJVtzGeBZkQlgoQHFyQ|--164t1nclzzmca7eDiJMw|2009-06-22 18:48:49|1     |12          | 4 | 2 |
# MAGIC |itcQ1R-VZR8jlWiuXp2fZw|--164t1nclzzmca7eDiJMw|2009-06-24 04:51:47|5     |13          | 5 | 2 |
# MAGIC |UJmbZqDKRTDas5OQXf5Ypg|--164t1nclzzmca7eDiJMw|2009-07-21 12:39:30|0     |14          | 5 | 2 |
# MAGIC |4lLRGq9bfa0Z0_wGkyDksA|--164t1nclzzmca7eDiJMw|2009-08-23 22:41:18|0     |15          | 5 | 2 |
# MAGIC |nJpfbT-iCGoKNEHNYg-Z2w|--164t1nclzzmca7eDiJMw|2009-10-07 11:26:02|0     |16          | 6 | 2 |
# MAGIC |6RhtnNzz1av8CRPfNjI4oA|--164t1nclzzmca7eDiJMw|2009-11-30 07:06:54|4     |17          | 6 | 2 |
# MAGIC |TgrG405zvSY1xwCUDIkJSg|--164t1nclzzmca7eDiJMw|2009-12-03 23:06:47|2     |18          | 6 | 2 |
# MAGIC |70u7c0x1ji-57NwIQtej-A|--164t1nclzzmca7eDiJMw|2009-12-09 02:00:35|7     |19          | 7 | 2 |
# MAGIC |z29K4qrK38cTT3fggx0DQQ|--164t1nclzzmca7eDiJMw|2009-12-11 17:32:21|1     |20          | 7 | 2 |
# MAGIC
# MAGIC #### Dividing by the bin size
# MAGIC
# MAGIC If we divide the `review_order` by the bin size, the result should be rounded up to get the bin.  
# MAGIC For example, if we want to use a bin size of 3, then for the 8th review, the `review_order` divided by 3 is 8 / 3 = 2.67, but the bin is 3.  For the 9th review, 9 /3 = 3, which is the correct bin number.
# MAGIC
# MAGIC What we need is a function that will round the result up to the next integer value (if there is a fractional part to the result).  If you look in the *SQL Examples* notebook, there is a numeric function named `CEILING()` that will do just that.  For our calculation here, we are going to calculate the bin number for each review based on both bins of size 5 and 10.
# MAGIC
# MAGIC If we wanted to, we could include this calculation in step 1 by dividing our `review_order` calculation by the bin size and wrapping that in the `CEILING` function.
# MAGIC
# MAGIC #### The following cell is Step 2
# MAGIC

# COMMAND ----------

df_binned_reviews = spark.sql("""
SELECT *, 
( CEILING(review_order / 5) ) AS bin5, 
( CEILING(review_order / 10) ) AS bin10
FROM ordered_reviews
ORDER BY business_id, review_order
""")
df_binned_reviews.show(200, truncate=False)
df_binned_reviews.createOrReplaceTempView("binned_reviews")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bins using a CASE function
# MAGIC
# MAGIC If we were planning to cap the number of reviews we were going to consider (this should **NOT** be a guestimate, but should be based on analyzing the businesses to see the distribution of the review count).  For this example, we will use a cap of 50 reviews.
# MAGIC
# MAGIC You will see here that if we wanted to change the cap, or if we wanted to change the bin size, we would have to do some recoding, which also introduces the possibility of errors.
# MAGIC
# MAGIC ####The following cell is Step 2b:

# COMMAND ----------

spark.sql("""
SELECT *, 
CASE
  WHEN review_order <=10 THEN 1
  WHEN review_order <=20 THEN 2
  WHEN review_order <=30 THEN 3
  WHEN review_order <=40 THEN 4
  WHEN review_order <=50 THEN 5
  ELSE 0
END AS bin10
FROM ordered_reviews
ORDER BY business_id, review_order
""").show(200, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 3: Ranking Functions
# MAGIC
# MAGIC In addition to `ROW_NUMBER` which would arbitrarily order ties (if two users posted reviews for the same business at the same second of the same minute of the same hour of the same day in the same year), There are two other ranking functions that handle ties differently:
# MAGIC
# MAGIC * RANK will return the same order for duplicates and then have a gap.  
# MAGIC * DENSE_RANK returns the same order for duplicates (same as `RANK`), except has no gaps
# MAGIC * PERCENT_RANK returns what percentile the record is in in the data
# MAGIC * NTILE(X) based on X, breaks the data in the partition into percentiles
# MAGIC
# MAGIC We could rank the businesses in each metro area (state code) based on the number of reviews they have.
# MAGIC
# MAGIC First, we need to load the business data.
# MAGIC
# MAGIC #### The following cell is Step 3a:  

# COMMAND ----------

df_business_data = spark.read.json('/yelp/business.bz2').select("business_id", "name", "state", "review_count")
print ("record count:", df_business_data.count() )
df_business_data.show(truncate=False)
df_business_data.createOrReplaceTempView("business")

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Ranking businesses based on review_count
# MAGIC
# MAGIC In the following cell we have added a WHERE clause to only include those businesses with 100 or less reviews and that are in our metro areas. In an actual project, there would likely be no rationale for excluding businesses with more than 100 reviews, but it helps illustrate the ranking functions here in 200 lines.
# MAGIC
# MAGIC Here we can see the `RANK` and `DENSE_RANK` results when we partition by state and order the businesses in descending order based on the review count (so those businesses with the most reviews are ranked #1).
# MAGIC
# MAGIC The format of these ranking functions is the same as the `ROW_NUMBER` windows function.
# MAGIC
# MAGIC #### The next cell is step 3b

# COMMAND ----------

spark.sql("""
SELECT business_id, name, state, review_count,
       RANK() OVER (PARTITION BY state ORDER BY review_count DESC) AS rank,
       DENSE_RANK() OVER (PARTITION BY state ORDER BY review_count DESC) AS dense_rank,
       PERCENT_RANK() OVER (PARTITION BY state ORDER BY review_count DESC) AS percent_rank,
       NTILE(10) OVER (PARTITION BY state ORDER BY review_count) AS n_tile
FROM business
WHERE state IN (SELECT state 
                FROM business
                GROUP BY state
                HAVING COUNT(*) > 1000)
      AND review_count <= 100 
ORDER BY state, rank 
""").show(200, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 4: Interpreting our question
# MAGIC
# MAGIC Do reviews more often get voted useful when there are fewer reviews for a business? 
# MAGIC
# MAGIC We have divided the reviews into bins by business, so the reviews written for a business when there were fewer reviews are in the earlier (lower numbered) bins.  How should we measure "***more often get voted useful***"?
# MAGIC * Total votes per bin?
# MAGIC * Average votes per bin?
# MAGIC * Count of reviews with at least one vote?
# MAGIC * Median votes per bin?
# MAGIC
# MAGIC For these calculations we will use the bins of size 5.  The following cell calculates the total votes, average votes, and count of at least one vote.
# MAGIC
# MAGIC The calculation of the median is left as homework in Step 4b.
# MAGIC
# MAGIC #### The following cell is Step 4a

# COMMAND ----------

df_bin_values = spark.sql("""
SELECT business_id, bin5 AS bin, 
       SUM(useful) AS total_votes,
       AVG(useful) AS avg_votes,
       SUM( IF(useful > 0,1,0) ) AS useful_count
FROM binned_reviews
GROUP BY business_id, bin5
ORDER BY business_id, bin
""")
df_bin_values.show(200, truncate=False)
df_bin_values.createOrReplaceTempView("bin_values")


# COMMAND ----------

# MAGIC %md ### <span style="color:#0055A2;">Step 4b: Median Votes</span>
# MAGIC There is no median function, so we need another means to calculate the median number of votes in each bin.  We are using a bin size of 5, so the 3rd review in each bin has the median value when the reviews are sorted based on the number of useful votes.
# MAGIC
# MAGIC **How can you number the votes within a bin?** The `ROW_NUMBER()` function of course!
# MAGIC
# MAGIC <span style="color:#0055A2;">**In the following cell, add your code to calculate the median for each bin at each business</span>. Sort the results by business_id and bin.
# MAGIC
# MAGIC This will take two queries most likely.

# COMMAND ----------

# Add your Query using the ROW_NUMBER function and calculate the median
df_median_bins = spark.sql("""
SELECT business_id, useful, bin5 AS bin,
      ROW_NUMBER() OVER (PARTITION BY business_id,bin5 ORDER BY bin5) AS review_position
FROM binned_reviews
ORDER BY business_id, bin, review_position
""")
df_median_bins.show(200,truncate=False)
df_median_bins.createOrReplaceTempView("median_bins")


# COMMAND ----------

df_median_votes = spark.sql("""
SELECT business_id,bin,useful
FROM median_bins
WHERE review_position = 3
ORDER BY business_id, bin
""")
df_median_votes.show(100,truncate=False)
df_median_votes.createOrReplaceTempView("median_votes")

# COMMAND ----------

# MAGIC %md # Step 5: LEAD and LAG - Looking Forwards or Backwards in a Partition
# MAGIC
# MAGIC The `LEAD` and `LAG` windows functions allow you to compare each row to rows subsequent to or prior to the current row.
# MAGIC
# MAGIC The `OVER` and partitioning and ordering are the same as all of the other windows functions we have looked at.
# MAGIC
# MAGIC The difference is that in the windows function itself (e.g., `LAG`), you specify the column to be extracted from a prior or subsequent row and how many rows to go back (`LAG`) or forward (`LEAD`).
# MAGIC
# MAGIC In this example we first calculate in Step 5a the average ratings for the `stars` field for each business by year, filtering with a `WHERE` clause to include only businesses with a total of 100 or more reviews. This calculation is not using any windows functions, but instead is just getting the data prepared.
# MAGIC
# MAGIC In Step 5b, The `PARTITION BY` and `ORDER BY` use the `business_id` and  `year` so the `LAG` function is then looking back over the same summarization and ordering as was used in the calculation of the `review_summary` temporary view in the `FROM` clause as was calculated in Step 5a.
# MAGIC
# MAGIC We are going to use the `LAG` function to look back one row (which is one year based on our data) and get the value in the `avg_annual_rating` column for that row.
# MAGIC
# MAGIC The result in Step 5b has the current `average_annual_rating` and the `avg_annual_rating` from the prior year (as `prior`).  When there is no prior row in the partition (the first year of data for a business), the `prior` calculation is null.
# MAGIC
# MAGIC In Step 5c we are just using the `avg_annual_rating` and `prior` to determine how much the average increased or decreased each year and then calculate the ratio of that increase to the prior value.
# MAGIC
# MAGIC
# MAGIC #### The following cell is Step 5a

# COMMAND ----------

df_review_summary = spark.sql("""
SELECT business_id, YEAR(date) as year, COUNT(*) AS annual_review_count, ROUND( AVG(stars) ,2) AS avg_annual_rating
FROM reviews_without_text_table
WHERE business_id IN (SELECT business_id
                      FROM reviews_without_text_table 
                      GROUP BY business_id
                      HAVING COUNT(*) >=100)
GROUP BY business_id, YEAR(date)
ORDER BY business_id, year
""")
df_review_summary.show(truncate=False)
df_review_summary.createOrReplaceTempView("review_summary")

# COMMAND ----------

# MAGIC %md #### The following cell is Step 5b

# COMMAND ----------

df_current_prior = spark.sql("""
SELECT business_id, year, avg_annual_rating, 
       LAG(avg_annual_rating ,1) OVER (PARTITION BY business_id ORDER BY year) AS prior
FROM review_summary
ORDER BY business_id, year
""")
df_current_prior.show(200)
df_current_prior.createOrReplaceTempView("current_prior")

# COMMAND ----------

# MAGIC %md #### The following cell is Step 5c

# COMMAND ----------

spark.sql("""
SELECT business_id, year, avg_annual_rating, prior, ROUND(avg_annual_rating - prior, 2) AS increase, 
       ROUND( (avg_annual_rating - prior)/prior, 4) AS growth
FROM current_prior
ORDER BY business_id, year
""").show(200, truncate=False)

# COMMAND ----------

# MAGIC %md # <span style="color:#0055A2;">Step 6: Applying the LAG Function to Compare Bins</span>
# MAGIC
# MAGIC Using the `bin_values` temporary view calculated in Step 4a, work with your team to calculate the change in the `total_votes` for each bin compared to the prior bin at the same business.

# COMMAND ----------

#create prior column using LAG function#
df_lag_prior = spark.sql("""
SELECT business_id,bin,total_votes,
      LAG(total_votes,1) OVER (PARTITION BY business_id ORDER BY bin) AS prior_bin
FROM bin_values
ORDER BY business_id, bin
""")
df_lag_prior.show()
df_lag_prior.createOrReplaceTempView("lag_prior")

#create difference column using subtraction#
df_lag_final = spark.sql("""
SELECT *,
      (total_votes - prior_bin) AS difference
FROM lag_prior
""")
df_lag_final.show()
df_lag_final.createOrReplaceTempView("lag_final")

# COMMAND ----------

