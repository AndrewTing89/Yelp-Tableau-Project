# Databricks notebook source
# MAGIC %md
# MAGIC # Creating a Column with the Order of Records Using SQL
# MAGIC Some teams may want to order records by business or user based on dates - such as ordering all of the records from 1 to X for each business 
# MAGIC based on the order in which they received their reviews (starting again at 1 for the first review at each restaurant).  Similarly, other teams
# MAGIC may want to order the review or tip records for each user.
# MAGIC
# MAGIC In this short notebook we are going to walk through an example using the `ROW_NUMBER()` function in SQL that will allow you to do just that.
# MAGIC The example we are going to use is ordering the reviews in each state based on their review date.
# MAGIC
# MAGIC To do this, we first need to join the business and review data so we can assign a state to each review.

# COMMAND ----------

df_business = spark.read.json("/yelp/business.bz2")
print ("total number of records: ", df_business.count() )
df_business.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### We only need the `business_id` and `state` fields

# COMMAND ----------

df_busState = df_business.select("business_id", "state").cache()
df_busState.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Eliminating states without much data
# MAGIC If states are relavant to your project, your team needs to profile for this threshold (if you just use this limit without any reason other than it was 
# MAGIC used here, that could  count against your team's grade).  For purposes of this exercise, we will get those states with more than 500 reviews.

# COMMAND ----------

df_stateCount = df_busState.groupBy("state").count().filter("count > 500").sort("count", ascending=False)
df_stateCount.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Businesses in States with Over 500 Reviews
# MAGIC Joining our summary by state with the DataFrame containing the `business_id` and `state` for every business will 
# MAGIC give us the business IDs and states for all businesses in those states.  We can then join that data with the review
# MAGIC data to tag each review with it's state (if it's in one of those states).

# COMMAND ----------

df_busState500 = df_busState.join(df_stateCount, df_busState.state == df_stateCount.state, 'left_semi')
df_busState500.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Load the Review Data
# MAGIC The following two cells load your Yelp review data into a table named `reviews_without_text_table` and then shows all tables existing on the cluster.
# MAGIC
# MAGIC To load the review data, we call a separate notebook named `Building Review Table` to create the table.  If you have previously run the `Working with Files` exercise, this will run very quickly (less than a minute), but if you have not completed `Working with Files` it could take 20 minutes to run.

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Joining the business and review data to assign a state to the reviews
# MAGIC Since only the businesses in states with over 500 reviews are included in our business data, any
# MAGIC reviews from states with 500 or fewer reviews in the dataset will be eliminated
# MAGIC in the result due to our INNER JOIN.

# COMMAND ----------

df_busState500.createOrReplaceTempView("busState500")

df_reviewsByState = spark.sql("""
SELECT R.review_id, R.business_id, R.date, B.state 
FROM reviews_without_text_table AS R INNER JOIN busState500 AS B
ON R.business_id = B.business_id
""")
print("record count:", df_reviewsByState.count() )
df_reviewsByState.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating a temporary view
# MAGIC Since the `ROW_NUMBER` function is a SQL function, we are going to first create a temporary view for the reviews by state data.

# COMMAND ----------

df_reviewsByState.createOrReplaceTempView("reviewsByState")

# COMMAND ----------

# MAGIC %md
# MAGIC # Ordering Reviews by Date within Each State
# MAGIC The following cell uses the `ROW_NUMBER()` function to order the records within each state based on the date of the review.  This
# MAGIC function is a bit different from other functions in that instead of a function name followed by all of the parameters within a pair of parenthesis, 
# MAGIC the `ROW_NUMBER()` function always has an empty pair of parenthesis followed by an `OVER` clause that says how to partition and order the records.
# MAGIC You most likely would always want to say how to order the records, but a partition is not required.  If we wanted to order *all* of the reiews in the 
# MAGIC dataset based on the date, we could do that without a partition.  This would be similar to just ordering the results, but it would create a new column with
# MAGIC that row order.
# MAGIC
# MAGIC Here we are going to partition based on the `state` because we want to start renumbering for each state.  We could put the 
# MAGIC `state` field in the `ORDER BY` part of the `OVER` clause, but we don't need to. We will say to `ORDER BY` the `date` field since we
# MAGIC want all of the reviews numbered from the earliest to the latest within each state.  We would not actually need the business_id field to come along, 
# MAGIC but if we ever wanted to find out the actual business that was reviewed first in each state, we would need their ID.

# COMMAND ----------

df_orderedReviews = spark.sql("""
SELECT state, 
       ROW_NUMBER() OVER (PARTITION BY state ORDER BY date) AS review_order, 
       date, business_id
FROM reviewsByState
""")
df_orderedReviews.show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Let's see how well this worked
# MAGIC By selecting only those reviews numbered 5 or less and ordering by state and review order, we see the first 5 reviews for each state.

# COMMAND ----------

df_orderedReviews.filter("review_order <= 5").sort(["state", "review_order"]).show(55, truncate=False)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Growth in Reviews by Year by Metro Areas
# MAGIC
# MAGIC The `OVER` clause can also be used with other functions such as:
# MAGIC * Aggregate functions: SUM AVG, MIN, MAX, COUNT
# MAGIC * Analytic Functions: FIRST_VALUE, LAST_VALUE, LEAD, LAG, CUME_DIST, PERCENTILE_CONT, PERCENTILE_DISC, PERCENT_RANK
# MAGIC * Ranking functions: RANK, DENSE_RANK, NTILE, and ROW_NUMBER as covered above is a ranking function
# MAGIC
# MAGIC If you are looking for documentation on the use of the OVER clause, the <a href="https://docs.microsoft.com/en-us/sql/t-sql/queries/select-over-clause-transact-sql?view=sql-server-ver15" target="_blank">Microsoft documentation</a> provides a good overview.
# MAGIC
# MAGIC **You may be asking, where would you use these?**
# MAGIC
# MAGIC ***Aggregate Functions:*** If you are comfortable using these, some could replace a join, such as the aggregate functions would allow you to 
# MAGIC do the equivalent of separately summarizing and joining a view.  For example, if you wanted to get the average, minimum, or maximum ranking for each business in the 
# MAGIC review data, but still have the review level data, you could do either of the following:
# MAGIC
# MAGIC 1. Group the review data by business and get the average minimum, and maximum, and then take that result and join it with the review data on business_id
# MAGIC 2. Instead select the review data and in the SELECT clause use the OVER clause and PARTITION based on business_id
# MAGIC
# MAGIC The second approach avoids the join and doing a second query, but may only be beneficial if you don't spend too much time getting this to work for you (or just like learning 
# MAGIC new things and figure now you have one more SQL skill).
# MAGIC
# MAGIC ***Analytic Functions:*** We will use the LAG function below to calculate how much the number of reviews written in each state increased over the prior year.  Alternately you can use the LEAD
# MAGIC function to look forward to the next year.  You could use this to see if the next review for a business was higher or lower than the current review. The other analytic functions could be used to say where a 
# MAGIC business ranks compared to other businesses (as far as number of reviews for example)
# MAGIC
# MAGIC ***Ranking Functions:*** The ROW_NUMBER function used earlier in this notebook is an example of a ranking function.  RANK and DENSE RANK are useful when ordering records that could have duplicate 
# MAGIC values, such as if you were ordering businesses within each metro area based on the number of reviews they had received or the number of years they have been reviewed on Yelp.  Similarly, if ordering users based on the number of years elite or number of reviews written.  The NTILE will break records into even sized bins such as quartiles, but it does not have to be quarters, hence the name ntiles.
# MAGIC
# MAGIC ### Example Comparing to Prior Years
# MAGIC In the example below, we do the following:
# MAGIC 1. Bring the business data and review data together to calculate the number of reviews written for businesses in each metro area (using state) for each year.
# MAGIC 2. Unpersist DataFrames we cached earlier.  If we were using these again in this notebook, we probably would not want to do that.
# MAGIC 3. Use the LAG function and OVER clause to compare each year's number of reviews in a state to the prior year.  This is described more below.

# COMMAND ----------

df_busState.createOrReplaceTempView("stateData")
                                   
df_stateSummary = spark.sql("""
SELECT S.state,YEAR(R.date) AS review_year, COUNT(R.review_id) AS review_count
FROM stateData AS S INNER JOIN reviews_without_text_table AS R
ON S.business_id = R.business_id
GROUP BY S.state, YEAR(R.date)
ORDER BY S.state, YEAR(R.date)
""").cache()
df_stateSummary.show(50)

# COMMAND ----------

df_busState.unpersist()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using the LAG function with the OVER clause
# MAGIC
# MAGIC In this example, we are comparing the current year's review count within a state to the prior year's review count in order to calculate the growth rate.  A growth rate of 1.0 means the 
# MAGIC current year is the same as last year.
# MAGIC
# MAGIC The `OVER` clause here works similar to when we were ordering reviews within a state.  the `OVER` clause below is:
# MAGIC
# MAGIC `OVER(PARTITION BY state ORDER BY review_year)`
# MAGIC
# MAGIC This means that we start over when we reach a new `state` value.  Within a state, the records will be ordered based on the `review_year`, so for example, 2017 will be directly prior to 2018.
# MAGIC The `LAG` function then says what we are doing for each row.  Here we have:
# MAGIC
# MAGIC `LAG(review_count,1)`
# MAGIC
# MAGIC The first parameter (`review_count`) says what column we are working with.  The second parameter says how many records we look back.  Here we say 1, so since our records are ordered by year, 
# MAGIC that means we are looking back to get the value for the review_count field in the prior year.  When the query is processing the 2018 row for the state of AZ (Phoenix metro area), the following will get the `review_count` for AZ in 2017:
# MAGIC
# MAGIC ` LAG(review_count,1) OVER(PARTITION BY state ORDER BY review_year)`
# MAGIC
# MAGIC What happens when the query is processing the year 2004 for AZ which is the first year we have data for that state code?  You will see in the result below, the value is null since we don't know
# MAGIC the prior year's value (in this case, Yelp was not around, so there was no prior value).  What if we don't want null?  There is an optional third parameter that says, what we should use when there is not a prior row within the same partition. We could use 0, but for our formula, we would then be dividing by zero and end up with null anyways.  What if in that case we wanted to say the growth rate should be 1 (no change)?
# MAGIC In that case we could use the following:
# MAGIC
# MAGIC `LAG(review_count,1,review_count)`
# MAGIC
# MAGIC That may look odd, but think of what it means when the query is processing 2004 for AZ.  That would be saying, "look at the `review_count` column" (first parameter), "and look back 1 year" (second parameter), "and if there is no prior year value, use the `review_count` value ***from the current row***".  Since the rest of the formula for the `growth_rate` field is dividing the current row’s review_count by the value from the `LAG` function and `OVER` clause, this would divide the review_count by itself, which is 1.

# COMMAND ----------

df_stateSummary.createOrReplaceTempView("stateSummary")

spark.sql("""
SELECT state, review_year, review_count, 
       (review_count / LAG(review_count,1) OVER(PARTITION BY state ORDER BY review_year) ) AS growth_rate
FROM stateSummary
ORDER BY state, review_year
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### An alternative without the OVER clause
# MAGIC If for some reason you don't like the `OVER` clause, you could use a self join, meaning you join a view with itself.
# MAGIC
# MAGIC In the example below, we join the `stateSummary` with itself using two different aliases (`S1` and `S0`) and in the `ON` clause not only does the state need to match, but we compare the 
# MAGIC `review_year` minus 1 from `S1` to the `review_year` from `S0`.  So when the query is processing the row for 2018 for AZ the `review_count-1` would be 2017, so 2018 is compared to 2017.
# MAGIC
# MAGIC In this query we are using a `LEFT JOIN` so that when we are processing the first year in a state it's still included in the result (but the `growth_rate` is null).
# MAGIC

# COMMAND ----------

spark.sql("""
SELECT S1.state, S1.review_year, S1.review_count, (S1.review_count / S0.review_count) AS growth_rate
FROM stateSummary AS S1 LEFT JOIN stateSummary AS S0
ON S1.state = S0.state AND
   S1.review_year-1 = S0.review_year
ORDER BY S1.state, S1.review_year
""").show(50)