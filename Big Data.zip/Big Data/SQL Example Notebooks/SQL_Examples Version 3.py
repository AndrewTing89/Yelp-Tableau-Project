# Databricks notebook source
# MAGIC %md
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.
# MAGIC
# MAGIC # Using This Notebook
# MAGIC This notebook illustrates the basic structures of queries and also a multitude of functions you can use in your queries.  The functions are divided up based on what they are working with (e.g., strings, dates, etc.) or the type of function they are (e.g., logical).
# MAGIC
# MAGIC All of the examples are based on the Yelp review and business data.  To use the notebook, you will first need to run the cells to create the table for the review data, the DataFrame for the business data, and the temporary view for the business data (the cells up to the header "The Most Basic Select Query").  The rest of the notebook can be run from top-to-bottom using the "Run All" feature, or selectively run.  If the notebook titled `Building Review and User Tables` has previously been run, then the whole notebook will take only a couple minutes to run.

# COMMAND ----------

# MAGIC %md ## Creating the table `reviews_without_text_table`
# MAGIC The following two cells load your Yelp review data into a table named `reviews_without_text_table` and then shows all tables existing on the cluster.
# MAGIC
# MAGIC To load the review data, we call a separate notebook named `Building Review Table` to create the table.  If you have previously run the `Working with Files` exercise, this will run very quickly (less than a minute), but if you have not completed `Working with Files` it could take 20 minutes to run.
# MAGIC
# MAGIC Since the reviews data is large, we are excluding the text field (this is the actual text of the review and the most space used.  Since we don't use it in this notebook, we don't want to be dragging it around)
# MAGIC
# MAGIC In the `Building Review Table` notebook you may notice that for the review data we also call the `cache()` method at the end of that line.  This holds the data in memory (instead of just keeping a "recipe" for how to create the data), this speeds up the other queries, but be *very* careful when using `cache` since if you cache too much, you will run out of memory and get a heap space error (Java-speak for running out of memory).  If you use the `cache` method, call the `unpersist()` method on the cached DataFrame when you no longer need it, and then it won't keep hogging your memory. Since we save the DataFrame out as a table, we then `unpersist` it since we do not directly access it again.

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating the `df_businesses` DataFrame
# MAGIC
# MAGIC The following cell loads your Yelp business data into a DataFrame named `df_businesses`.

# COMMAND ----------

import pyspark.sql.functions as f

df_businesses = spark.read.json("/yelp/business.bz2")
print ("total number of records: ", df_businesses.count() )
df_businesses.printSchema()
df_businesses.show(5,truncate=False,vertical=True)

# COMMAND ----------

# MAGIC %md # The Most Basic Select Query
# MAGIC The most basic SQL query has two clauses, a `SELECT` and a `FROM` clause.  In these examples, the SQL code will be capitialized.  In your project you will be graded on this since it improves readability (and makes your teammate's code more readable for you).  However, it will run as lower case.
# MAGIC
# MAGIC Since we already created a table named `reviews_without_text_table` from the JSON review data, we do not need to first create a temporary view.  However, since we loaded the business data from the JSON files into a DataFrame named `df_businesses`, we need to first call the DataFrame method `createOrReplaceTempView` to create a temporary view that we can use in a SQL query.  
# MAGIC
# MAGIC In both queries, the `select` returns a new DataFrame, so we include the `show()` function.  We also included a limit of 5 records and `truncate=False` in the call to the `show()` function so that we can see the full values for the `review_id` and `user_id` fields; otherwise when displaying the result, it will shorten the values shown (although the full value for each ID is still in the actual DataFrame).  If you use `truncate`, be sure the `F` in `False` is capitalized.
# MAGIC
# MAGIC Since the call to `spark.sql` returns a DataFrame, if we wanted to use the result in a subsequent SQL query, we would need to create a new temporary view.

# COMMAND ----------

spark.sql("SELECT user_id, cool, useful, funny FROM reviews_without_text_table").show(5,truncate=False)

df_businesses.createOrReplaceTempView("businesses")
spark.sql("SELECT business_id, name, city, state FROM businesses").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Adding a WHERE Clause
# MAGIC In the following example we will build on our query by adding a `WHERE` clause that specifies which rows we want to get back.  In the above example, we included the fields for votes on the reviews, but you may not have seen any votes.  Let's query for those reviews with at least some (more than zero) cool votes.

# COMMAND ----------

spark.sql("""
SELECT business_id, user_id, user_id, cool, useful, funny 
FROM reviews_without_text_table 
WHERE cool > 0
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Adding Multiple Conditions in the WHERE Clause
# MAGIC You may have see some votes also showing up for the useful and funny votes, but it would depend on which records you got back.  remember, you are looking at 5 records out of over 8 million and there is no guaranteed order to the records (despite the result saying that it is showing the top 5 records).  We would need to include an `ORDER BY` clause if we wanted a specific order.
# MAGIC
# MAGIC In the following cell we will get those records that have some cool votes and either 10 or more  funny votes or 10  or more useful votes.  Here we use both `AND` and `OR` to combine conditions in our query and add parenthesis to be sure it does these in the order we want.

# COMMAND ----------

spark.sql("""
SELECT business_id, user_id, user_id, cool, useful, funny 
FROM reviews_without_text_table 
WHERE cool > 0 AND (funny >= 10 OR useful >= 10)
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## The Operators You Can Use for Comparisons
# MAGIC In the above query we used the "greater than" symbol `>` and the "greater than or equal to" symbol `>=`.  The following table lists all of the comparisons you can do:
# MAGIC
# MAGIC | Operator | What it Does | Example |
# MAGIC | --- | --- | --- |
# MAGIC |  <       | less than | review_count < 100 |
# MAGIC | <=       | less than or equal to | review_count <= 100 |
# MAGIC | >        | greater than | review_count > 100 |
# MAGIC | >=        | greater than or equal to | review_count >= 100 |
# MAGIC | =        | equal | review_count = 100 |
# MAGIC | <>        | not equal to | review_count <> 100 |
# MAGIC | +        | add two fields | funny + cool > 100 | 
# MAGIC | -        | subtract two fields | funny - cool > 100 |
# MAGIC | *        | multiply two fields | funny * 2 > useful |
# MAGIC |  /       | divide one field by another<br/> (The divisor on the bottom cannot be zero) |funny / 2 > useful |
# MAGIC | %      | remainder of dividing one number by another | funny % 10 > 5<br/><br/> Means that if funny is divided by 10, <br/>the remainder is greater than 5, so a <br/>funny value of 16 matches (16 / 10 = 6) |
# MAGIC | BETWEEN *x and *y | matches values in a range <br/>(including the end points)  | funny BETWEEN 5 AND 20 |
# MAGIC | NOT      | finds rows that don't match the condition | funny NOT BETWEEN 5 and 20 <br/>matches rows where funny is less than 5 or more than 20 |
# MAGIC | IS NULL  | matches rows where the specified field is null | funny IS NULL |
# MAGIC | IS NOT NULL | this is an example of combining `NOT` and `IS NULL` | matches all rows where funny is not NULL |
# MAGIC
# MAGIC Most of these you know , but lets do a few examples.  Say you wanted those reviews where two times the number of cool votes was in the range 10 to 20 (inclusive) and the sum of the useful and funny votes was less than the cool votes.

# COMMAND ----------

spark.sql("""
SELECT business_id, user_id, user_id, cool, useful, funny 
FROM reviews_without_text_table 
WHERE (cool BETWEEN 10 AND 20) AND (funny + useful < cool)
""").show(5,truncate=False)

# COMMAND ----------

spark.sql("""
SELECT business_id, name, attributes
FROM businesses
WHERE attributes IS NULL
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Aggregate Functions and the GROUP BY Clause
# MAGIC If we just want to get a count of the number of records (as we did earlier with the DataFrame directly) or do some oher aggregate, we can use an aggregate function without a `GROUP BY` clause as shown in the first two examples where we:
# MAGIC * get a count of the number of reviews 
# MAGIC * get the average, minimum, and maximum number of cool votes as well as the standard deviation of the cool votes
# MAGIC
# MAGIC In the second example we set an alias for each resulting column using `AS`.  This gave us a more human-readable column name that the formula in the first example (and will cause less confusion if we feed this result into another query).
# MAGIC
# MAGIC However, if we want to see subtotals, we need a `GROUP BY` clause as in the next example where we get the total number of cool votes by user.  When we use aggregate functions, any field included in the `SELECT` clause that is not in an aggregate function must be in the `GROUP BY` clause.

# COMMAND ----------

spark.sql("""
SELECT COUNT(business_id) 
FROM reviews_without_text_table
""").show(5,truncate=False)

spark.sql("""
SELECT AVG(cool) AS avg_cool,  
MIN(cool) AS min_cool,
MAX(cool) AS max_cool,
STDDEV(cool) AS stddev_cool
FROM reviews_without_text_table
""").show(5,truncate=False)

spark.sql("""
SELECT user_id, SUM(cool) AS total_cool 
FROM reviews_without_text_table 
GROUP BY user_id
""").show(5,truncate=False)

spark.sql("""
SELECT (attributes IS NOT NULL) AS has_attributes,
count(business_id) AS business_count
FROM businesses
GROUP BY attributes IS NOT NULL
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC Some of the more common aggregation functions are listed in the following table.  The "what's returned" column assumes you are not doing any grouping.
# MAGIC
# MAGIC | Function | Example | What's Returned |
# MAGIC | ----- | ---- | --- |
# MAGIC | SUM | SUM(yearsElite) | combined total of the number of years <br/>any user has been elite |
# MAGIC | AVG | AVG(yearsElite) | the average number of years that yelpers were elite |
# MAGIC |STDDEV | STDDEV(yearsElite) | the standard deviation of the <br/>number of years that yelpers were elite |
# MAGIC | MIN | MIN(review_count) | the lowest review count <br/>of any user in the data |
# MAGIC | MAX | MAX(review_count) | the most reviews any user <br/>in the data has written |
# MAGIC | COUNT | COUNT(user_id) | counts the number of users in the data<br/>since we can get a count of the DataFrame, <br/>this is more useful when grouping |
# MAGIC | DISTINCT | COUNT (DISTINCT name) | DISTINCT is not a grouping function, but is <br/>often used with grouping - it excludes<br/>duplicates from the result. |

# COMMAND ----------

# MAGIC %md ## Grouping Based on a Calculated Field
# MAGIC In the above example, we grouped by the `user_id` field which was in the `SELECT` clause.  We could also have a formula the we want
# MAGIC to use for grouping.  In the following example, we want to calculate the total number of votes for each review (funny, useful, and cool combined)
# MAGIC and then get a count of the number of reviews with each total.  To do this, we need to include our function in the `SELECT` clause, but also in the `GROUP BY` clause.  In a query like this, we would likely want to sort the result or it won't make much sense.
# MAGIC
# MAGIC You can also do grouping based on a field that's not in the `SELECT` clause as shown in the second example, but why would you? That's not a quiz question.
# MAGIC I have never come across a reason that would be useful.

# COMMAND ----------

spark.sql("""
SELECT (funny + useful + cool) AS total_votes, COUNT(business_id) 
FROM reviews_without_text_table 
GROUP BY (funny + useful + cool)
""").show(5,truncate=False)

spark.sql("""
SELECT SUM(cool) AS sum_cool 
FROM reviews_without_text_table 
GROUP BY user_id
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Numeric Functions
# MAGIC So far most of the functions and operators we have looked at are numberic, but there are a few other numeric functions you might find useful.
# MAGIC
# MAGIC | Function | What it Does |
# MAGIC | ---------|--------------|
# MAGIC | ROUND | rounds to a specified number of decimal digits|
# MAGIC | CEILING | always rounds up |
# MAGIC | FLOOR | always rounds down |
# MAGIC | % | modulus - returns the remainder from dividing the first parameter by the second parameter|
# MAGIC
# MAGIC Following is an example of all of these functions based on calculating the cool votes as a percentage of the total votes. 
# MAGIC We need to include the condition in the `WHERE` clause to avoid dividing by zero.
# MAGIC * We round the percentage to 1 decimal place
# MAGIC * We truncate the decimal portion of the cool percentage
# MAGIC * We get the ceiling and floor of the cool percentage
# MAGIC * We get the remainder of dividing the total votes by the cool votes (if this does not show a value, set the minimum in the WHERE clause to 2)
# MAGIC

# COMMAND ----------

spark.sql("""
SELECT user_id, cool, (cool + useful + funny) AS total_votes, 
cool / (cool + useful + funny) * 100 AS cool_percentage, 
ROUND( cool / (cool + useful + funny) * 100, 1) AS cool_rounded,
CEIL( cool / (cool + useful + funny) * 100) AS cool_ceiling,
FLOOR( cool / (cool + useful + funny) * 100) AS cool_floor,
(cool + useful + funny) % cool AS cool_remainder
FROM reviews_without_text_table 
WHERE cool  > 0
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Date Functions
# MAGIC In the reviews, tips, and user files there are fields with the date and time  
# MAGIC If you look at the schema that was inferred for the reviews data, you will see this date as a `string` data type 
# MAGIC which means it's being treated as alphanumeric data.  All of these functions will either take a string or convert 
# MAGIC the string to a date and process it.
# MAGIC
# MAGIC Following are examples of some date functions:
# MAGIC * CURRENT_DATE the current date when you are running the cell
# MAGIC * YEAR, MONTH, DAY respective parts within the date
# MAGIC * DATE_FORMAT to get the day of the week out as a description (there is other formatting you can do if needed - Google it if it applies to your project)
# MAGIC * DAYOFYEAR to get the day in the sequence 1 - 366 (if a leap year)
# MAGIC * LAST_DAY to get the last day of the month the date is in (returns the full date)
# MAGIC * WEEKOFYEAR to get the week 1-52
# MAGIC * QUARTER to get the quarter the date is in 1-4 (e.g., Jan-Mar is the first quarter and Oct-Dec is the fourth quarter)
# MAGIC * DATE_ADD to add days to a date
# MAGIC * DATE_SUB to subtract days from a date
# MAGIC * DATEDIFF to get the number of days between two dates (the later one specified first)
# MAGIC * MONTHS_BETWEEN gets the months between two dates
# MAGIC * UNIX_TIMESTAMP returns the number of seconds since January 1, 1970

# COMMAND ----------

spark.sql("""
SELECT user_id, date, CURRENT_DATE(),
YEAR(date) AS year, 
MONTH(date) AS month, 
DAY(date) AS day,
DATE_FORMAT(date, 'E') AS day_description,
DAYOFYEAR(date) AS day_of_year,
LAST_DAY(date) AS end_of_month,
WEEKOFYEAR(date) AS week_of_year,
QUARTER(date) AS quarter
FROM reviews_without_text_table
""").show(5,truncate=False)

spark.sql("""
SELECT user_id, date, CURRENT_DATE(),
DATE_ADD(date, 15) AS added_15_days,
DATE_SUB(date, 15) AS subtracted_15_days,
DATEDIFF(CURRENT_DATE(),date) AS days_from_now,
MONTHS_BETWEEN(CURRENT_DATE(),date) AS months_between,
UNIX_TIMESTAMP(date)
FROM reviews_without_text_table
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## String Functions
# MAGIC Alphanumeric data such as the IDs used for the businesses, users, and reviews, as well as business names, and the text of the reviews and tips
# MAGIC are know as strings.  Following are some examples of functions you can use with strings:
# MAGIC * LENGTH gets the length of the string, such as the number of characters in the review or tip
# MAGIC * CONCAT connects strings.  The `+` operator also connects strings.
# MAGIC * LOWER and UPPER converts the text to lower or upper case
# MAGIC * INITCAP capitalizes the first letter of each word in a string field
# MAGIC * LEFT and RIGHT returns the left-most or right-most X characters of a string
# MAGIC * SUBSTRING to take a part of a string from a starting position and a specified length. If you want to get the *rightmost* X characters, use a negative starting position.  For example, `SUBSTRING(text,-5,5)` to get the 5 characters at the end of the string
# MAGIC * LOCATE finds one string within another string
# MAGIC * LIKE does pattern-matching in a string.  The `%` at the start and end means any number of characters before and after. Case sensitive.
# MAGIC * SPLIT splits a string based on another string or characters (such as splitting a comma-seperated string).  The result returned is an array (in [ ] brackets).  In the example below we are using a regular expression pattern where `\\\s*` matches zero or more whitespace characters (such as hitting the space bar, tabs, linefeeds, etc.)
# MAGIC
# MAGIC
# MAGIC
# MAGIC Following are some examples using the business and review data.

# COMMAND ----------

spark.sql("""
SELECT business_id, user_id, 
CONCAT("business ID: ", business_id, ", user ID: ", user_id) AS concatenated_ids,
LEFT(date,4) AS year_string,
RIGHT(date,2) AS day_string,
UPPER( business_id ) AS uppercase_businessid
FROM reviews_without_text_table
""").show(5,truncate=False)

# COMMAND ----------

spark.sql("""
SELECT business_id, name,
LENGTH(name) AS name_length,
LOCATE(',', categories) AS separator_position,
SUBSTRING(name, 0, 10) AS leftmost_10_characters,
SUBSTRING(name, 2, 5) AS the_2nd_to_6th_characters,
SUBSTRING(name,-5,5) AS rightmost_5_characters,
LIKE(LOWER(name),'%coffee%') AS contains_coffee,
INITCAP(name) AS initial_capitalization,
SPLIT(categories,'\\\s*,\\\s*') AS category_list
FROM businesses""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md ## Using Functions in the Where Clause
# MAGIC In the following query, we use the `LIKE` and `LENGTH` functions from the above string function list in the `WHERE` clause to check for businesses with long names that contain the word coffee (or a word containing coffee, such as "Coffeehouse") 

# COMMAND ----------

spark.sql("""
SELECT business_id, name
FROM businesses
WHERE LIKE(LOWER(name),'%coffee%') AND LENGTH(name) > 40""").show(truncate=False)

# COMMAND ----------

# MAGIC %md ## Logical Functions
# MAGIC Sometimes you may want to add a column where the value is based on checking a condition.  You have most likely done this in Excel with
# MAGIC an IF function, and the format for the `IF` function in SQL is the same as in Excel.  In Excel spreadsheets you may have created nested IF functions, but SQL has a 
# MAGIC cleaner approach; that's the `CASE` function.  This function allows you to check multiple conditions, and the first condition that matches (is true), is the answer for that field in that record.  The `CASE` function should always have an `ELSE` that is applied when none of the other conditions being tested are true.
# MAGIC * IF(condition, true value, false value)<br/>**Example:** In the example below, we are checking if the `DogsAllowed` attribute is null.  If it is (the true value), we return the string "Unknown" because the data is not available, but possibly they allow dogs. Otherwise, if it's not null (the false value), we just return the value in that attribute.
# MAGIC * CASE<br/>  WHEN condition a THEN result a<br/>  WHEN condition b THEN result b<br/>  WHEN condition c THEN result c<br/>  ELSE default result<br/>END<br/>**Example:** In the example below we are using the state code to set a new field named `metro_area`.  We will see later that this is easier to do in Tableau, but the `CASE` function allows us to check the `state` field, and as soon as one matches, we have the value for the row.  Although we show the `CASE` function on multiple lines for readability, it creates a single new column in the resulting DataFrame.

# COMMAND ----------

spark.sql("""
SELECT business_id, name, IF(attributes.DogsAllowed IS NULL,"Unknown",attributes.DogsAllowed) AS dogs_allowed
FROM businesses
""").show(truncate=False)

# COMMAND ----------

spark.sql("""
SELECT business_id, name, state,
CASE
  WHEN state = 'WA' THEN 'Portland'
  WHEN state = 'OR' THEN 'Portland'
  WHEN state = 'MA' THEN 'Boston'
  WHEN state = 'TX' THEN 'Austin'
  WHEN state = 'FL' THEN 'Orlando'
  WHEN state = 'GA' THEN 'Atlanta' 
  WHEN state = 'BC' THEN 'Vancouver'
  WHEN state = 'OH' THEN 'Columbus'
  WHEN state = 'CO' THEN 'Boulder'
  ELSE 'bad data'
END AS metro_area
FROM businesses
""").show(100,truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Structural and Array Functions
# MAGIC This is not an exhaustive list of the structural functions available, but some that may be most helpful.  In these examples, columns are being combined, arrays columns sorted, or array values each generating a separate line.
# MAGIC
# MAGIC For the `EXPLODE` examples, we are starting with the categories field converted into an array using the `SPLIT` function.
# MAGIC
# MAGIC * EXPLODE A column containing an array (such as the business categories or user elite fields) can be exploded so that each entry in the array is a separate line.  The other columns for that line will be repeated for each line in the array.<br/>**Example:** We are exploding the categories field after converting it first to an array from a comma-separated string. 
# MAGIC * EXPLODE_OUTER Unlike the `EXPLODE` function, this version includes those rows in the data where the exploded column is null in the data being exploded.
# MAGIC * ARRAY SORT used to sort the values within the array within a column
# MAGIC * ARRAY_MIN retrieves the minimum value in an array
# MAGIC * ARRAY_MAX gets the maximum value in an array
# MAGIC * ARRAY can be used to create an array in a single colum,n out of values in multiple columns
# MAGIC * MAP, MAP_CONCAT, EXPLODE (map) These functions are used together to create a map of name:value pairs which we can then explode using the `EXPLODE` function as used on arrays, but now it creates two new columns in the result - one for the name and the other for the value in each name:value pair in the map.
# MAGIC

# COMMAND ----------

df_categories = spark.sql("""
SELECT business_id, name,
SPLIT(categories,'\\\s*,\\\s*') AS category_list
FROM businesses""")
print("number of business records:", df_categories.count() )
df_categories.show(5,truncate=False)
df_categories.createOrReplaceTempView("categories")

# COMMAND ----------

# MAGIC %md #### EXPLODE function
# MAGIC In this example, the `categories_list` array created from the categories field (above) is exploded.  The record count for the result is printed.  Since each category is now a separate line, the number of records has grown substantially.

# COMMAND ----------

df_exploded = spark.sql("""
SELECT business_id, name, EXPLODE(category_list) AS category
FROM categories
""")
print("Record count for business categories with categories exploded:", df_exploded.count() )
df_exploded.show(100,truncate=False)

# COMMAND ----------

# MAGIC %md #### EXPLODE_OUTER
# MAGIC Some businesses do not have a value for the categories field, so when we explode the array using the `EXPLODE` function above, those businesses are ***NOT*** included in the results. 
# MAGIC If instead we use the `EXPLODE_OUTER` function, the nulls are still included (the "outer" is similar to the concept of an outer join where thosee rows without a match are still included, but here it's those rows with no data for the exploded field).
# MAGIC
# MAGIC Compared to the `EXPLODE` function used above, you will see that the record count is slightly higher because the businesses with no attrbutes are also included in the results.  Since there are not many such businesses, those are then filtered and printed below.

# COMMAND ----------

df_exploded_outer = spark.sql("""
SELECT business_id, name, category_list, EXPLODE_OUTER(category_list) AS category
FROM categories
""")
print("Record count for business categories with categories exploded outer:", df_exploded_outer.count() )
df_exploded_outer.show(100,truncate=False)

df_exploded_nulls = df_exploded_outer.filter("category IS NULL")
print("Record count for businesses with no categories:", df_exploded_nulls.count() )
df_exploded_nulls.show(truncate=False)

# COMMAND ----------

# MAGIC %md #### ARRAY_SORT, ARRAY_MIN, ARRAY_MAX
# MAGIC In this example we use `ARRAY_SORT` to sort the categories array so the categories are listed alphabetically foer each business

# COMMAND ----------

spark.sql("""
SELECT business_id, name, ARRAY_MIN(category_list) AS min_category, ARRAY_MAX(category_list) AS max_category, ARRAY_SORT(category_list) AS sorted_list
FROM categories""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md #### ARRAY function

# COMMAND ----------

df_hours = spark.sql("""
SELECT business_id, name, hours.Monday, hours.Tuesday,hours.Wednesday,hours.Thursday,hours.Friday,hours.Saturday,hours.Sunday
FROM businesses
WHERE hours IS NOT NULL""")
df_hours.show(5,truncate=False)
df_hours.createOrReplaceTempView("hours")

# COMMAND ----------

spark.sql("""
SELECT business_id, name, ARRAY(Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday) AS hours
FROM hours
""").show(5,truncate=False)

# COMMAND ----------

# MAGIC %md #### MAP, MAP_CONCAT, EXPLODE (map)
# MAGIC
# MAGIC In the first cell we use `MAP` to create a column of the data type MAP which is a name:value pair like an entry in a Python dictionary or a JSON object.  We can base the map name and value on different columns, or as in the case shown here, we use a literal string as the name value (so it's the same for that field on every row).
# MAGIC
# MAGIC In the second cell we use the 'MAP_CONCAT' function to combine (concatenate) the maps created for the columns map_monday through map_sunday into a single map with 7 name:value pairs.
# MAGIC
# MAGIC In the third cell we use the `EXPLODE` function on the map to create a row for each of the name:value pairs in the map.  Notice that since we will be creating two new columns (one for the name and the other for the value), so we provide two field names for the alias.

# COMMAND ----------

df_hours_maps = spark.sql("""
SELECT business_id, name, MAP("Monday",hours.Monday) AS map_monday,
                          MAP("Tuesday",hours.Tuesday) AS map_tuesday,
                          MAP("Wednesday",hours.Wednesday) AS map_wednesday,
                          MAP("Thursday",hours.Thursday) AS map_thursday,
                          MAP("Friday",hours.Friday) AS map_friday,
                          MAP("Saturday",hours.Saturday) AS map_saturday,
                          MAP("Sunday",hours.Sunday) AS map_sunday
FROM businesses
WHERE hours IS NOT NULL""")
df_hours_maps.show(5,truncate=False)
df_hours_maps.createOrReplaceTempView("hours_map")

# COMMAND ----------

df_week_map = spark.sql("""
SELECT business_id, name, MAP_CONCAT(map_monday,map_tuesday,map_wednesday,map_thursday,map_friday,map_saturday,map_sunday) AS week_map
FROM hours_map
""")
df_week_map.show(5,truncate=False)
df_week_map.createOrReplaceTempView("week_map")

# COMMAND ----------

spark.sql("""
SELECT business_id, name, EXPLODE(week_map) AS (weekday,hours)
FROM week_map
""").show(truncate=False)

# COMMAND ----------

# MAGIC %md # Joins - Bringing Together DataFrames
# MAGIC
# MAGIC Restaurants are the largest share of the reviews for any top-level category in Yelp, so **let's assume we are interested only in businesses in the Restaurants category, but we want to know what percentage 
# MAGIC of each restaurant's reviews are funny**.  How could we find that out?
# MAGIC
# MAGIC <p>In the following code we will show two approaches.  First we will show doing this in steps - doing some initial wrangling of each of the data sources (businesses and reviews) and then doing the join.  If SQL joins are relatively new to you, we would STRONGLY recommend this approach.  Tackle problems step-by-step instead of trying to build one query.  After we walk through building incremetally in multiple steps, we will show the same question answered in one query.</p>
# MAGIC * Step 1: With the business data, we will use the `split` function to split the categories field in the business data to get an array of the categories for each business.  Since we are humans (I'm assuming...) we want a result that's human readable, so we are also going to include the name of each business.  Since we will want to match businesses with their reviews, we also include the business_id field.  This is the query below which generates the `df_bus_categories` DataFrame containing 3 fields: business_id, name, and categories (as an array).
# MAGIC * We show the results (the first 20 rows by default), and then create a new temporary view based on the DataFrame that has the same name except without the "df_" prefix.

# COMMAND ----------

df_bus_categories = spark.sql("""
SELECT business_id, name, SPLIT(categories,'\\\s*,\\\s*') AS categories
FROM businesses
""")
df_bus_categories.show(truncate=False)
df_bus_categories.createOrReplaceTempView("bus_categories")

# COMMAND ----------

# MAGIC %md
# MAGIC * Step 2: Since we are only interested in businesses that are restaurants (although they may be other things too), We are going to feed the `bus_categories` temporary view into a new query that uses a `WHERE` clause to filter for only those businesses in the "Restaurants" category.  We generate a new DataFame named `df_restaurants` and again create a new temporary view based on it that has the same name without the "df_" prefix, so the view is named `restaurants`.  This DataFrame only contains the business_id (so we can eventually join with reviews), and the name field.  Since for this question we don't care what other business categories the restaurants are in, we did not include the `categories` field in our `SELECT` clause, even though it's used in the `WHERE` clause.

# COMMAND ----------

df_restaurants = spark.sql("""
SELECT business_id, name
FROM bus_categories
wHERE ARRAY_CONTAINS(categories, 'Restaurants')
""")
df_restaurants.show(truncate=False)
df_restaurants.createOrReplaceTempView("restaurants")

# COMMAND ----------

# MAGIC %md
# MAGIC * Step 3: Next we do some wrangling of the review data since the only columns we care about for this question are the business_id (so we can join with the `restaurants` view) and the funny field which contains a count of how many funny votes each review received.  We start with the `reviews_without_text_table` and select out only the two fields are are interested in.  We named the resulting DataFrame `df_funny_reviews` and then created a temporary view named `funny_reviews` that we can join with the `restaurants` view.

# COMMAND ----------

df_funny_reviews = spark.sql("""
SELECT business_id, funny
FROM reviews_without_text_table
""")
df_funny_reviews.show(truncate=False)
df_funny_reviews.createOrReplaceTempView("funny_reviews")

# COMMAND ----------

# MAGIC %md 
# MAGIC * Step 4: Joining the restaurant and funny_reviews Temporary Views. Since both the business data and the review data contain the business_id field, we can ***join*** the two DataFrames on the buiness_id column.  We will do an INNER JOIN, so the business ID values are matched - multiple reviews would be matched with the same business record if they had the same business ID.  The resulting DataFrame will contain a row for each review that has a matching row in the `restaurants` view where the business ID is the same.  The values in the name and business_id columns we include from the `restaurants` data will be the same for each review from the same restaurant.
# MAGIC
# MAGIC * The join is done in the `FROM` clause, and since the business ID is in both the review and user data, we alias the restaurant data as R and the funny_reviews data as F.  It's just a common convention, but usually data analysts will alias tables or views in a query using a single captital letter (and having that match the data source helps).  The first line of the `FROM` clause says what views we are joining and the type of join we are doing (INNER JOIN).  This is follwed by the `ON`condition that says what fields o compare in the two views, and here our `ON` condition says the business_id field in the two tables must be the same (equal) in order for the records to be matched.
# MAGIC
# MAGIC * If you ever write a query and it's taking a *looooooonnnng* time to run, be sure you included the `ON` condition and have it correct.  If we ommitted it here, every restaurant wioud be matched with each of the over 8 millinn reviews in our data! If you realize you omitted the `ON` clause, cancel the query.
# MAGIC
# MAGIC * We name our new DataFrame `df_restaurant_reviews` and include the business_id and name columns from the `restaurants` view and include the funny field from the `funny_reviews` view. We also add a new calculated field here based on the `funny` field.  We have to decide what it means to be a "funny" review.  Is a review with 1 funny vote the same as a review with 1,000 funny votes, or is that materially different?  For our query, we will take the position that even 1 funny vote makes a review funny.  If this is your project, you have a *business decision to make here* in determining if that accurately reflects what you are trying to determine from a business point of view.  **If you get *that* decision wrong, it does not matter how fancy your SQL skills are - you still would have a useless result**. The field we will add is named `is_funny` and the formula will use an `IF` function to check if the `funny` field's value is greater than 0, in which case `is_funny` is equal to 1.  

# COMMAND ----------

df_restaurant_reviews = spark.sql("""
SELECT R.business_id, R.name, F.funny, IF(F.funny > 0,1,0) AS is_funny
FROM restaurants AS R INNER JOIN funny_reviews AS F  
ON R.business_id = F.business_id
ORDER BY name
""")
df_restaurant_reviews.show(truncate=False)
df_restaurant_reviews.createOrReplaceTempView("restaurant_reviews")

# COMMAND ----------

# MAGIC %md
# MAGIC * Step 5: Summarizing by restaurant.  The `df_restaurant_reviews` view has review level detail, but our question was about the percentage of each restaurant's reviews that are funny.  To calculate that, we need to summarize by business_id using a `GROUP BY` clause, and we need to add a calculated field that gets a count of those reviews at each business that have the value 1 for the `is_funny` field, divided by a count of all of the reviews for the restaurant.  We named this new field `funny_percentage` in the following query that creates the `df_funny_ratio` DataFrame.
# MAGIC
# MAGIC * Since the `is_funny` field has a value of 1 (is funny) or 0 (is not funny), we can use the `SUM` aggregation function to count the number of reviews that are funny at each business.

# COMMAND ----------

df_funny_ratio = spark.sql("""
SELECT business_id, name, ( SUM(is_funny)/COUNT(business_id) ) AS funny_percentage
FROM restaurant_reviews 
GROUP BY business_id, name
ORDER BY name
""")
df_funny_ratio.show(truncate=False)

# COMMAND ----------

# MAGIC %md ## Adding a HAVING Clause - a "WHERE" clause for grouped data 
# MAGIC The WHERE clause in a query filters out rows so you get only the rows that match your WHERE clause.
# MAGIC
# MAGIC The GROUP BY clause can then be used to put the remaining rows into groups and then do some type of aggregation, such as a sum, min, max, count, etc.
# MAGIC
# MAGIC However, what if *after* you grouped the data, you wanted another WHERE clause to then filter the grouped results?  Obviously one solution
# MAGIC would be to create a new temporary view from the result and then run a new query on that view to apply your WHERE clause; and that works, but
# MAGIC the HAVING clause provides a shortcut.
# MAGIC
# MAGIC For this example, we are going to use the same query used to summarize the results of the join above in `df_funny_ratio`.  That query had a `GROUP BY` clause that 
# MAGIC calculated the percentage of reviews that were funny at each restaurant, but what if we wanted to see only those restaurants where at least 25% of the reviews were funny.  We could create a new query that uses the results of `df_funny_ratio` as a starting point and filters the businesses based on the `funny_percentage` field, but instead in the follow cell we are going to modify the query that built that DataFrame to filter that grouped result by adding a `HAVING` clause after the `GROUPED BY` clause, but before any `ORDER BY` clause.
# MAGIC

# COMMAND ----------

df_funny_summary = spark.sql("""
SELECT business_id, name, ( SUM(is_funny)/COUNT(business_id) ) AS funny_percentage
FROM restaurant_reviews 
GROUP BY business_id, name
HAVING funny_percentage >= 0.25
ORDER BY name
""")
df_funny_summary.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Combining the filtering, JOIN, and HAVING clauses in one query
# MAGIC In the discussion of the JOIN query, we mentioned that all of the steps we were doing could be combined in a single query.  In the following cell,
# MAGIC we do all of those steps plus the `HAVING` clause's filtering of the grouped results as a single query.  If SQL is new to you, we would recommend **NOT** doing this early on, because if the query encounters an error, it may be difficult to debug and you could end up "poking" at the code until it runs, but then not being sure if it really is asking what you intended.

# COMMAND ----------

df_funny_ratio = spark.sql("""
SELECT B.business_id, B.name, ( SUM( IF(R.funny > 0,1,0))/COUNT(B.business_id) ) AS funny_percentage
FROM reviews_without_text_table AS R INNER JOIN businesses AS B
ON R.business_id = B.business_id
WHERE ARRAY_CONTAINS( SPLIT(categories,'\\\s*,\\\s*'), 'Restaurants')
GROUP BY B.business_id, B.name
HAVING funny_percentage >= 0.25
ORDER BY name
""")
df_funny_ratio.show()