# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This ds4all notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md
# MAGIC # PySpark and DataFrames
# MAGIC
# MAGIC In this notebook we are going to introduce some basic ideas about PySpark (since we will be using Python).  
# MAGIC The documentation for the classes and functions in that module can be found <a href="http://spark.apache.org/docs/latest/api/python/pyspark.sql.html" target="_blank">here</a>.
# MAGIC If you click on that link, it can be a bit intimidating - remember that page is documenting *every* method and function in PySpark.  At the top of that
# MAGIC page are the major classes in the PySpark SQL module.  We won't be using most of the methods and functions, but in this exercise and future notebooks we will walk through a few of them - mainly in the DataFrame API.
# MAGIC
# MAGIC We will start with the SparkSession, which is created by Databricks when you spun up your cluster and it's always named `spark` by convention (not just in Databricks - that's a Spark convention).
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start With A Question: What metro areas are in the yelp dataset?  
# MAGIC
# MAGIC The Yelp Dataset Challenge tells us there is data for 8 metro areas in the dataset, but it does not tell us 
# MAGIC which metro areas.  This means we need to do some data wrangling to find out.  We need to ask the data 
# MAGIC which metro areas are included in the data.  
# MAGIC
# MAGIC First, we need to read our JSON data into a DataFrame. From the metadata provided by Yelp, we know the business data includes 
# MAGIC information on where each business is located: latitude and longitude, postal code, state, city, neighborhood, address so we
# MAGIC will start by reading the Yelp business data into a DataFrame.  
# MAGIC
# MAGIC We will walk through reading our JSON files (zipped up in the bzip2 format). 
# MAGIC In future exercises we will just say we are reading the data - from experience you will know how to do that (or know which
# MAGIC of your notebooks to look at for an example).
# MAGIC
# MAGIC To read the data file, we start with the `read` method from our `SparkSession` variable named `spark`.
# MAGIC
# MAGIC If you look at the PySpark documentation for the **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.SparkSession.read.html#pyspark-sql-sparksession-read" target="_blank">read</a>** method, you will see that it returns a `DataFrameReader` 
# MAGIC which "can be used to read data in as a DataFrame".  If we entered the following in a cell, the variable we are creating on the left side of the = sign (named `dfr`) would be populated with an instance of a `DataFrameReader`.
# MAGIC
# MAGIC `dfr = spark.read`
# MAGIC
# MAGIC However, we want to read the business data into a DataFrame, not create a DataFrameReader, so we won't stop there.  Let's take a look at the documentation for 
# MAGIC a **<a href="https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql.html#input-and-output" target="_blank">DataFrameReader</a>**, click on it.  The first method you will probably see for 
# MAGIC a `DataFrameReader` is the `csv()` method which reads data in from a csv file such as our data from the 
# MAGIC Social Security Administration.  However, we have a JSON file, 
# MAGIC so scroll on down to the **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrameReader.json.html?highlight=dataframereader#pyspark-sql-dataframereader-json" target="_blank">json</a>** method.
# MAGIC You will see there are a lot of possible options, but for our purposes the defaults are fine, we just need to provide a path.  
# MAGIC In the cell below, add the path to your business data as a string (meaning the path is enclosed in quotes).  If you are not sure what that
# MAGIC path is, go take a look at your DBFS and come back here.  To see what is in DBFS on your account, click on the `Data` icon in the toolbar on the left in Databricks, and then click the `Create Table` button.
# MAGIC You may be saying, "but I'm not creating a table at the moment", however this is the path to seeing what you have stored in DBFS. In the `Create New Table` screen that appears, click on the `dBFS` button in the row of buttons on the top.  You are now in your DBFS, and if you loaded the Yelp data they way we discussed in class, it's in the `/yelp` directory, so click on that.  whenever you have a file or directory selected in DBFS, the path to get there is listed at the bottom of the screen, so you can copy and paste that path into the code below.
# MAGIC
# MAGIC The result of the `json` method of the `DataFrameReader` is a DataFrame, so we assign the result to a variable named `df_business`.
# MAGIC Keep in mind what is happening here.  The code `spark.read` generates a `DataFrameReader`, so the "dot" after that code is saying 
# MAGIC to call the `json` method from that class on that `DataFrameReader` which was created.
# MAGIC
# MAGIC ## Step 1: Loading the data
# MAGIC
# MAGIC The first line reads your Yelp business data file.  Be sure it has the correct path to your data.
# MAGIC
# MAGIC The last two lines of the cell print out a count of the number of businesses in the data file and the schema inferred by Spark for the data file.

# COMMAND ----------

df_business = spark.read.json('/yelp/business.bz2')
print ("record count:", df_business.count() )
df_business.printSchema()

# COMMAND ----------

# MAGIC %md ## Step 2: What does our data look like?
# MAGIC
# MAGIC The DataFrame class has a method named **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.show.html#pyspark-sql-dataframe-show" target="_blank">show()</a>** that will show us the first 20 rows.  
# MAGIC
# MAGIC Since some fields, such as the business address or the text of a review can be long, the default is to show the first 20 characters.  This is known as truncating the data (truncate means "chop off").  
# MAGIC
# MAGIC We can include optional parameters to say how many rows we want and whether to truncate the fields (or how many characters to truncate at). Example: `df_business.show(truncate=False)`
# MAGIC
# MAGIC If the result is wrapping around, we can add `vertical=True` to print each column for a row of data on a separate line (probably want to reduce the number of rows). Example: `df_business.show(2, vertical=True)`
# MAGIC
# MAGIC **In the next cell, show the DataFrame**

# COMMAND ----------

# Add a call to the show() method here
df_business.show(2, vertical=True, truncate=120)

# COMMAND ----------

# MAGIC %md # What are the 8 Metro Areas in the Data?
# MAGIC
# MAGIC ##Step 3: Getting the distinct cities
# MAGIC
# MAGIC Since the `city` field seems like it could be the metro area, (although there are more than 8 cities in the first 20 rows), we will explore that first.
# MAGIC
# MAGIC We can see that some cities appear multiple times in the first 20 rows, so what we would like to see is a list of the unique cities in the data.
# MAGIC
# MAGIC **Getting only the `city` column**<br/>
# MAGIC The first step is that we need to get a DataFrame with only the `city` column, and to do that we will use the **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.select.html#pyspark-sql-dataframe-select" target="_blank">select()</a>** method which allows us to say which columns we want from an existing DataFrame. 
# MAGIC
# MAGIC `df_business.select("city").show(100)`
# MAGIC
# MAGIC Here we again use the dot notation.  Since `select()` is a DataFrame method, we use the dot to say we care calling the `select` method of our `df_business` DataFrame.  We cannot change an existing DataFrame - we can only create a new DataFrame, so the `select` method is generating a new DataFrame and then we use the dot notation again to call the `show` method on that DataFrame, but this time we want to show 100 rows instead of the default 20 rows. At the end of the printed DataFrame, it says it's only showing the first 100 rows, which means we have over 100 rows.
# MAGIC
# MAGIC The `select` method generated a new DataFrame - what happened to it?  Has our `df_business` DataFrame been modified?  If you are not sure, reun the show method above where we howed all of the columns.
# MAGIC
# MAGIC **Getting the distinct cities**</br>
# MAGIC What we really want is a list of the distinct cities.  For example, Portland appears multiple times, but we only want to list it once.  There is another DataFrame method named **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.distinct.html#pyspark-sql-dataframe-distinct" target="_blank">distinct()</a>** that we can use to say we want only the distinct rows in a DataFrame.
# MAGIC
# MAGIC Add `distinct()` to the code cell below.
# MAGIC
# MAGIC

# COMMAND ----------

# Add a line to print the total number of distinct cities

print("Number of cities:", df_business.select("city").distinct().count())

df_business.select("city").distinct().show(100)

# COMMAND ----------

# MAGIC %md
# MAGIC ## There are more than 8 cities
# MAGIC
# MAGIC Our profiling provided valuable information - cities are not each considered a metro area.
# MAGIC
# MAGIC We will take a step back - how many businesses are there in each state?  Is there one metro area per state?  Are there multiple metro areas in a state (and also in our data)?  For example, if our data included
# MAGIC California, Los Angeles, San Francisco, and San Diego would all be separate metro areas in the data.
# MAGIC
# MAGIC First let's look at the states.
# MAGIC
# MAGIC The DataFrame class has a method named `groupBy` that will group our data based on a field or fields we specify 
# MAGIC (documentation is **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.groupBy.html#pyspark-sql-dataframe-groupby" target="_blank">here</a>**).
# MAGIC
# MAGIC You can think of `groupBy` as being like if you had a deck of cards and you wanted to group them by suit (hearts, clubs, etc.).  We want to 
# MAGIC group the business data by state.  This may seem similar to using `distinct`, but where that method got rid of duplicates, `groupBy` allows us to 
# MAGIC do calculations on each group.  
# MAGIC
# MAGIC The difference can be explained with a deck of cards.  If you asked your younger sister, "what are the distinct suits in a deck of cards", 
# MAGIC you would get four values back: diamonds, spades, clubs, and hearts.  If you asked her to group the cards by suit, you could then ask her to count how many there are in 
# MAGIC each suit.  If all of the cards are there, the answer would be 13 for each suit.
# MAGIC
# MAGIC After using the DataFrame `groupBy` method, we no longer have a DataFrame.  As stated in the documentation, 
# MAGIC we now have an instance of the `GroupedData` class as documented **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.GroupedData.html#pyspark-sql-groupeddata" target="_blank">here</a>**.
# MAGIC
# MAGIC The `GroupedData` class has a number of methods we can use to calculate information about each group (e.g., the mean, average, etc.). We want to get a count of the number of 
# MAGIC businesses in each state, so we will use the `count` method documented **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.GroupedData.count.html#pyspark-sql-groupeddata-count" target="_blank">here</a>**,
# MAGIC which returns a DataFrame, so we can call the `show` method on it.
# MAGIC
# MAGIC ## Step 4: Counting businesses by state

# COMMAND ----------

df_state = df_business.select("state").groupBy("state").count()
df_state.show(100, truncate=False)

# COMMAND ----------

# MAGIC %md ## Step 4a: Sorting the business count by state
# MAGIC
# MAGIC In Step 4 we created a new DataFrame named `df_state` with a count of the number of businesses in each state.  We can use the **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.orderBy.html#pyspark-sql-dataframe-orderby" target="_blank">orderBy()</a>** method to sort that DataFrame.
# MAGIC
# MAGIC Using the`df_state` DataFrame as a starting point, add the `orderBy` method to sort based on the `count` field and and set `ascending=False`

# COMMAND ----------

# Add code to sort the df_state DataFrame
df_state.orderBy("count", ascending=False).show()

# COMMAND ----------

type(df_state)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Step 5: What Metro Area(s) Are Included from Massachusetts?
# MAGIC When we showed the data in the business DataFrame earlier, there was a business named "Mr G's Pizza & Subs" in the state of Massachusetts (state code MA).  Above we calculated that there are 36,012 businesses in the data from Massachusetts.  Mr G's Pizza & Subs is located in Peabody, MA, so is Peabody one f or metro areas? In the following cell we will:
# MAGIC 1. Get all of the businesses from Massachusetts
# MAGIC 2. Get a count of the businesses in each city
# MAGIC 3. Sort the list by the count in descending order (ascending=False)
# MAGIC
# MAGIC This could tell us if there is a specific city that defines the metro area in the data from Massachusetts.  Possibly the other cities in the data from Massachusetts are just suburbs of Peabody, MA
# MAGIC
# MAGIC **There's just one problem, How do we get only those businesses (rows in the data) that are from Massachusetts?**
# MAGIC
# MAGIC To do this, you first need one other DataFrame method, **<a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.DataFrame.filter.html#pyspark-sql-dataframe-filter" target="_blank">filter</a>**.  Whereas `select` allowed us to choose to include only specific columns, `filter` allows us to include only specific rows that match some
# MAGIC criteria specified in our filter.  The following cell filters our business data to include only the rows for those businesses in Massachusetts.  If you already know SQL, this should sound very similar to the WHERE clause in a SQL query, and in fact you can use `where` as a substitute for `filter` in PySpark.
# MAGIC
# MAGIC **NOTE:** The parameter for the `filter` method is our condition, and we entered it as a string.  However, we are comparing the `state` column to the string "MA", so we need to enclose that in single quote marks so it's not confused with the double quote marks around our condition.

# COMMAND ----------

# Add the groupBy() and orderBy() methods (use count for the groupBy)
df_business.filter("state == 'MA'").show()