# Databricks notebook source
# MAGIC %md
# MAGIC ### Purpose of this Notebook:
# MAGIC In prior exercises and in your team project, you will be writing out tables that you will then use as a data source in Tableau.  
# MAGIC
# MAGIC In your team project, you may be using tables we created in the *Bringing it All Together* set of notebooks, or you may be building off those to rite your own tables.
# MAGIC
# MAGIC This code defines some functions we will be using to rebuild previously created tables.

# COMMAND ----------

# MAGIC %md ### What Tables Do I Have?
# MAGIC Run the following cell which will list all of the tables you have written to the hive warehouse.
# MAGIC
# MAGIC If you want to rebuild all of the tables (and see a summary), just run the following code (after defining the functions below):<br/>
# MAGIC `process_tables()`
# MAGIC
# MAGIC The code for rebuilding the tables **assumes you are using the Parquet file format** as we have been doing this semester.  If you have a table that was written as a Delta table or 
# MAGIC using some other format, you will get a message for that table that it could not be processed and to check the type.
# MAGIC
# MAGIC If the directory does not have the table files, you will see a message that the table files could not be found.  If these errors are encountered, a message is printed and it continues with the other directories.

# COMMAND ----------

dbutils.fs.ls("/user/hive/warehouse/")

# COMMAND ----------

# MAGIC %md ### Functions for processing tables
# MAGIC
# MAGIC If you want to rebuild all of the tables listed for the hive warehouse directory, run:<br/>
# MAGIC `process_tables()`
# MAGIC
# MAGIC If you want to rebuild one table (assuming it's called "my_table"), run:<br/>
# MAGIC `process_tables("my_table")`
# MAGIC
# MAGIC If you had the following three tables you want to rebuild: moe_table, larry_table, curly_table, run them as a list:<br/>
# MAGIC `tables = ["moe_table","larry_table","curly_table"]`<br/>
# MAGIC `process_tables(tables)`
# MAGIC
# MAGIC #### Suppressing the summary:
# MAGIC
# MAGIC All of the above will recreate the tables and then print a record count and a 10-row summary.  If you do not want a summary, include the parameter: `summary=False`

# COMMAND ----------

PATH_PREFIX = "/user/hive/warehouse/"

def files_exist(path):
  '''If the directory path passed as a parameter exists and is a non-empty 
     directory (the directory contains files), this function returns true.
  '''
  files_exist = False # default, the directory does not exist or is empty
  try:
    file_list = dbutils.fs.ls(path)
    if len(file_list) > 0:
      return(True)
  except Exception:
    pass # files-exist is still False
  return(False) #if empty or path does not exist

def build_table(table_path, table_name):
  '''Given the path to where the files for the table are, which is 
     generally under /user/hive/warehouse, and the name of the table,
     this function builds the table.  Note that it assumes the table
     was originally built using PARQUET.
  '''
  print(f"building {table_name} from existing table files")
  spark.sql(f"""
    CREATE TABLE {table_name} 
    USING PARQUET 
    LOCATION '{table_path}' 
  """)

def table_summary(table_name):
  '''Given a table name, this function will print the
     number of records in the table and then print 10
     records from the table.
  '''
  spark.sql(f"""
    SELECT COUNT(*) AS record_count
    FROM {table_name}
  """).show()
  # show 10 rows from the table
  spark.sql(f"""
    SELECT * 
    FROM {table_name} LIMIT 10 
  """).show(truncate=22)
  
  
def process_table(table_name, summary):
  '''This method is provided a string that should be a table name, but there is no guarantee.'''
  if len(table_name) == 0:
    print("A blank table name was passed and could not be processed")
    return
  table_path = PATH_PREFIX + table_name
  if ( spark.catalog._jcatalog.tableExists(table_name) ):
    print(f"{table_name} table exists")
    if summary == True:
      try:
        table_summary(table_name)
      except Exception:
        print(f"A summary could not be generated for the table {table_name}, check the table type. ")
        pass
    return
  elif files_exist(table_path): # If the table files exist build from the existing table files
    try:
      build_table(table_path, table_name)
      if summary == True:
        table_summary(table_name)
    except Exception:
      print(f"Could not create the table {table_name}, check the data type.")
    finally:
      return      
  else:
    print(f"The table files do not exist for {table_name}, so the table was not created.")
    return
  
def get_table_list():
  '''Returns a list of the directory names in the user hive warehouse'''
  table_list = []
  fileinfo_list = dbutils.fs.ls(PATH_PREFIX)
  for fileinfo in fileinfo_list:
    filename = fileinfo.name.strip().rstrip('/')
    filename
    if len(filename) > 0:
      table_list.append(filename)
  return(table_list)
  

def process_tables(table_names=None, summary=True):
  '''This method is optionally passed a string with a table name or a list of table names.  For each table, If a table by that name 
     already exists, there is nothing to create.  If the files exist in the hive warehouse, 
     then the table is recreated from those files.  If the files don't exist, an exception is encountered and prints the offending table name.
     If no parameter is passed for the table name(s), then the program tries to rebuild any table in the hive warehouse.
     If the table(s) exist or could be created, and summary is True, 
     then a record count and 10 rows are printed.
  '''
  tables = []
  if table_names is None:
    tables = get_table_list()
    print(f"building {len(tables)} tables from DBFS")
  elif isinstance(table_names, str):
    tables.append(table_names.strip() )
    print(f"building {table_names}")
  elif isinstance(table_names, list):
    tables = table_names
    print(f"building {len(tables)} tables provided as list")
  else:
    raise TypeError("optional table_names must be str of single table or list of tables")
  for table in tables:
    process_table(table.strip(), summary)

# COMMAND ----------

# MAGIC %md ### Edit the following cell for tables to be rebuilt
# MAGIC See discussion above about the parameters to use

# COMMAND ----------

my_list=["business_category_table","frequency_pairs_table","user_gender_table","reviews_without_text_table"]

process_tables(my_list)

# COMMAND ----------

