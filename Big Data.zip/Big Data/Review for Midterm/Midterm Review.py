# Databricks notebook source
# MAGIC %md
# MAGIC # Reviewing some basics about Spark SQL and PySpark
# MAGIC In this notebook we are going to use the Yelp data to recap some basics about SQL that we have covered so far.
# MAGIC
# MAGIC To illustrate some concepts, we will filter our data in ways that your team should not be limiting your data (such as only businesses in a specific metro area or reviews in a single year).
# MAGIC
# MAGIC For these examples, we will load our business and review data into DataFrames.  The business data we will load directly from the JSON data file, and since we created a Spark table earlier in the semester, we will load our transaction data from that table.  If for some reason you did not do the exercise that builds the review table, the following cell will generate an error message saying you need to run that earlier notebook.
# MAGIC
# MAGIC For both the business and review data we are going to call the `count` method from the DataFrame class to print the number of records in each DataFrame and we are going to print the schema for each DataFrame so we can see the fields available to us.
# MAGIC #### Step 1a - load the business data

# COMMAND ----------

df_business = spark.read.json('/yelp/business.bz2')
print ("Total number of businesses:", df_business.count() )
df_business.printSchema()

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Step 1b: Preview a couple rows of business data
# MAGIC Here we are showing only the first 5 rows.  We are also setting the `truncate` parameter in the `show` method to `False` so we can see all of the data.
# MAGIC
# MAGIC Since the business data has a lot of columns, we also include `vertical-True` (this will not be on the midterm)

# COMMAND ----------

df_business.show(5, truncate=False, vertical=True)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Step 2: Loading the review data from a table
# MAGIC Since our review data was large, we previously stored it in a Spark table which is actually a set of parquet files.  Those files still exist in DBFS, but we need to recreate the table definition.
# MAGIC
# MAGIC Run the following cell to create the `reviews_without_text_table` again. 

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

# MAGIC %md 
# MAGIC # Step 3: Components of a SQL Query
# MAGIC There are 2 required components or clauses in a SQL query:
# MAGIC 1. SELECT - which columns we want (possibly based on a formula)
# MAGIC 2. FROM - what view the data is from
# MAGIC
# MAGIC In addition, we have covered the following additional clauses which would appear in the following order (if they are included):
# MAGIC
# MAGIC * WHERE - filtering rows
# MAGIC * GROUP BY - if we are aggregating the data based on one or more columns (could also be a formula)
# MAGIC * HAVING - Filters the grouped results
# MAGIC * ORDER BY - sorting the results based on some column one or more columns
# MAGIC
# MAGIC ### SELECT and columns within nested objects
# MAGIC Let's start with the required clauses, SELECT and FROM to select the following fields from our `df_business` DataFrame:
# MAGIC * business_id
# MAGIC * name
# MAGIC * state (which we are using as a proxy or substitute for metro area)
# MAGIC * review_count
# MAGIC * categories (**but as an array**)
# MAGIC * and a couple columns **from within attributes** that seem relevant in a pandemic:
# MAGIC   * OutdoorSeating
# MAGIC   * RestaurantsTakeOut
# MAGIC   
# MAGIC For the fields within `attributes` we need to reach inside the nested structure for attributes to get these fields.  Each business is a JSON object in our data, so it's composed of name:value pairs, and the value for attributes is itself a nested JSON object, so each of these five fields within attributes is a name:value pair within that nested JSON object.
# MAGIC
# MAGIC Since we have a DataFrame, but we want to run a Spark SQL query, we first need to create a temporary view and then create our query.
# MAGIC #### Step 3 - Use Spark SQL to <span style="font-size:1.5em;">SELECT columns and nested columns</span> from the business attributes
# MAGIC
# MAGIC In the result that's displayed, what is the order of the columns based on?  Can we make the result have a more sensible order?

# COMMAND ----------

df_business.createOrReplaceTempView("business")

# COMMAND ----------

#INCORRECT#
df_business_attr = spark.sql("""
SELECT SPLIT(categories, '\\\s*,\\\s*') AS category_list,
       attributes.OutdoorSeating,
       attributes.RestaurantsTakeOut,
       business_id, name, state, review_count
FROM business
""").show()
df_business_attr.createOrReplaceTempView("business_attr")

# COMMAND ----------

#CORRECT#
df_business_attr = spark.sql("""
SELECT business_id, name, state, review_count,
       SPLIT(categories, '\\\s*,\\\s*') AS category_list,
       attributes.OutdoorSeating,
       attributes.RestaurantsTakeOut
FROM business 
""")
df_business_attr.show()
df_business_attr.createOrReplaceTempView("business_attr")

# COMMAND ----------

# MAGIC %md # Poll 1

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 4: Filtering the business data by adding a WHERE clause
# MAGIC Next, we are going to filter the business data to <strong><span style="color:red;">include only restaurants in the Boston metro area</span></strong> in our data.
# MAGIC
# MAGIC By filtering our data to include only specific rows, we are doing a **structural transformation**.  We could do this with the PySpark `filter` method, **but instead, add it to the prior query**.
# MAGIC

# COMMAND ----------

df_boston_restaurants = spark.sql("""
SELECT *
FROM business_attr
WHERE ARRAY_CONTAINS(category_list, 'Restaurants') AND state='MA'
""")
print("boston restaurants:", df_boston_restaurants.count())
df_boston_restaurants.show(50)
df_boston_restaurants.createOrReplaceTempView("boston_restaurants")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 5: Aggregating the Review Data to Summarize Reviews by Year
# MAGIC In the review data there is a date field that has the date and time of the review in a commonly recognized date format.  We can use that with the SQL `YEAR()` function to summarize the reviews by year.  What do we want to know by year?
# MAGIC
# MAGIC Let's calculate the following for each year:
# MAGIC * The average review rating
# MAGIC * The number of reviews
# MAGIC * the total number of funny votes
# MAGIC * The number of distinct businesses that received reviews that year
# MAGIC
# MAGIC **We would want to see the summary in chronological order.<br/>
# MAGIC What clauses do we need to add?**
# MAGIC
# MAGIC <strong><p style="font-size:1.2em;">We want to see only the years with 100,000 or more unique businesses reviewed</p></strong>

# COMMAND ----------

spark.sql("""
SELECT YEAR(date) AS review_year, 
       AVG(stars) AS avg_rating,
       COUNT(funny) AS review_count, 
       SUM(funny) AS total_votes,
       COUNT(DISTINCT business_id) AS unique_businesses
FROM reviews_without_text_table
GROUP BY YEAR(date)
HAVING unique_businesses >= 100000
ORDER BY review_year
""").show()

# COMMAND ----------

# MAGIC %md #Poll 2

# COMMAND ----------

# MAGIC %md ### Step 6: Filtering the Reviews to Include Only Those Posted in 2020
# MAGIC Using the same SQL `YEAR` function we used above, we can filter the review data
# MAGIC to include only the reviews posted in 2020.
# MAGIC
# MAGIC After we do our 
# MAGIC transformation, we do some profiling to make sure we still have the same count for 2020 that we had above when summarizing by year.

# COMMAND ----------

df_2020_reviews = spark.sql("""
SELECT business_id, date, stars
FROM reviews_without_text_table
WHERE YEAR(date) = 2020
""").cache()
print("number of 2020 reviews:",df_2020_reviews.count())
df_2020_reviews.show(truncate=22)
df_2020_reviews.createOrReplaceTempView("reviews2020")

# COMMAND ----------

# MAGIC %md
# MAGIC # Exploring Joins
# MAGIC We have two DataFrames at this point that we want to bring together:
# MAGIC
# MAGIC 1. df_boston_business - This contains data about the businesses in Boston that were reviewed on Yelp
# MAGIC 2. df_2020_reviews - This contains data about the Yelp reviews written in 8 metro areas in 2020
# MAGIC
# MAGIC # Poll 3
# MAGIC
# MAGIC For a discussion of the different JOIN types, see the short video <strong><a href="https://www.youtube.com/embed/M4ZyrmqfKjI?rel=0" target="_blank">Exploring SQL Joins</a></strong>.
# MAGIC
# MAGIC #### Step 7: Joining Boston restaurants and 2020 reviews

# COMMAND ----------

# Add the type of join you need ???????
df_boston_2020 = spark.sql("""
SELECT B.business_id, name, category_list, review_count,
       OutdoorSeating, RestaurantsTakeOut, date, stars
FROM boston_restaurants AS B INNER JOIN reviews2020 AS R
ON B.business_id = R.business_id
""")

print ("Number of restaurant reviews in Boston in 2020:", df_boston_2020.count())
df_boston_2020.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 8: How many Boston Restaurants Had Reviews in 2020?
# MAGIC
# MAGIC In this case we just want to know there's at least one match for a business in the review data, but we don't actually need any data from the review temporary view, we are really just using it as a filter.  In that case we could use a **LEFT SEMI JOIN**, where the view with the Boston businesses is listed first in the JOIN:
# MAGIC
# MAGIC boston_restaurants LEFT SEMI JOIN reviews2020

# COMMAND ----------

businesses_with_reviews = spark.sql("""
SELECT business_id
FROM boston_restaurants AS B LEFT SEMI JOIN reviews2020 AS R
ON B.business_id = R.business_id
""").count()

print ("Number of Boston businesses with 2020 reviews:", businesses_with_reviews)

# COMMAND ----------

# MAGIC %md
# MAGIC ### <span style="color:blue;">Why is the `business_id` in the `SELECT` ***NOT*** ambiguous in Step 8?</span>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 9: How many Boston Restaurants Had NO Reviews in 2020?
# MAGIC In this case we are again not wanting any data from the review data, we are only using it to filter the the Boston restaurants.  These would be the restaurants eliminated in an INNER JOIN since there is no review with a matching `business_id` in the review data.
# MAGIC
# MAGIC For this query we can use a LEFT ANTI JOIN with the Boston restaurants on the left side of the join and the 2020 reviews on the right-hand side.

# COMMAND ----------

#Left Anti Join only grabs non-matching#
businesses_without_reviews = spark.sql("""
SELECT business_id
FROM boston_restaurants AS B LEFT ANTI JOIN reviews2020 AS R
ON B.business_id = R.business_id
""").count()

print ("Number of Boston businesses without any reviews posted in 2020:", businesses_without_reviews)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 10: Could We Summarize the Number of Boston Restaurants With and Without Reviews in 2018?
# MAGIC If we look back to step 4, we see that the total number of Boston restaurants that have ever gotten Yelp reviews is 10,550.  In step 8 we found that 6,141 of those restaurants had at least one Yelp review posted in 2018, and in step 9 we found that there were 4,409 Boston restaurants in the dataset that did not receive a review on Yelp in 2020 (but did at some point since they are in the dataset). 
# MAGIC
# MAGIC These numbers tie, but if we wanted to summarize those Boston restaurants that did and did not get any reviews in 2020?
# MAGIC
# MAGIC First, what could we do to identify for each Boston restaurants if they did or did not have any 2020 reviews?
# MAGIC
# MAGIC # Poll 4
# MAGIC
# MAGIC #### The following cell is step 10
# MAGIC In the following cell we have started a query, but you need to add the JOIN type AND GROUP BY clause.

# COMMAND ----------

# Add the type of join you need
#Left Outer Join includes every business, whether there are matches or not
spark.sql("""
SELECT IF(R.business_id IS NOT NULL, True, False) AS has_reviews, COUNT(DISTINCT B.business_id) AS business_count
FROM boston_restaurants AS B LEFT OUTER JOIN reviews2020 AS R
ON B.business_id = R.business_id
GROUP BY IF(R.business_id IS NOT NULL, True, False)
""").show()

# COMMAND ----------

# MAGIC %md # Step 11: Window Functions
# MAGIC
# MAGIC If we wanted to number all of the reviews at each business by month, what would our PARTITION BY and ORDER BY be?<br/>
# MAGIC **HINT:** There is a MONTH() function

# COMMAND ----------

# Complete the window function
spark.sql("""
SELECT B.business_id, name, date, RestaurantsTakeOut, stars,
       ROW_NUMBER() OVER (PARTITION BY B.business_id, MONTH(date) ORDER BY date) AS monthly_order
FROM boston_restaurants AS B INNER JOIN reviews2020 AS R
ON B.business_id = R.business_id
ORDER BY name, business_id, date
""").show(truncate=False)

# COMMAND ----------

