# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md 
# MAGIC # Working With Files Part 1: Loading The Yelp Data
# MAGIC
# MAGIC Although the Yelp datset is not "Big" by commercial standards, for an academic dataset it's large in that unzipped it's approximately 10GB. Fortunately, Spark can work directly with compressed data in certain formats, and we will be loading zipped data using the bzip2 format (WinZip files will not work - don't try it).
# MAGIC
# MAGIC Some of the data files, particularly the reviews and the user data files, are nearly 2GB even when compressed, so loading them from a home Internet connection is not possible for many students (keep in mind that if your ISP is a cable company, data download speeds are usually much faster than data upload speeds, and you would need to do both).  If you are curious about your Internet speed, see the <a href="https://www.att.com/support/speedtest/" target="_blank">AT&T speedtest</a> (there's also a link in Canvas) - you would have roughly 900 Mbps both directions when using a wired Ethernet (not Wi-Fi) connection on campus.
# MAGIC
# MAGIC For this reason, we staged the zipped data on Amazon's S3 storage service and we will use the code in this notebook to load the data directly to your Databricks account (which is also on AWS's servers).  The code is designed so that if you re-run this code and the data is already in your account, it will not try to reload it.  This is also why you completed the Yelp dataset agreement exercise where you submitted the request to Yelp and agreed to be bound by their license.
# MAGIC
# MAGIC We will walk through this notebook in class. Since the review and user files are rather large  (almost 2GB each when compressed), you will also need to run the notebook named `Building Review and User Tables` to create tables for the review and user data files. 
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Spinning up a cluster
# MAGIC To be able to calculate any cells in your notebook, you will need to be attached to a cluster.  If you completed the exercise in the *Intro to Jupyter and Python* video lecture, this is the same process.  From the toolbar on the
# MAGIC left-hand side, click on the `Compute` icon (it looks like a cloud and used to be amed Clusters).  You won't have any clusters to start with, so click on the `+Create Cluster` button.
# MAGIC The defaults in that screen are fine, but you will need to enter a name for your cluster.  Once your cluster's status is 
# MAGIC running (and has a solid green circle by it), come back to your notebook and from the drop-down list in the top-left corner, attach 
# MAGIC your notebook to the cluster listed with the solid green circle.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Using a Databricks widget to enter the path to the data manifest
# MAGIC
# MAGIC Since some of the data files are too large to manually upload even when compressed, you will be importing the data from where we temporarily staged it on AWS, but **you *MUST* complete the dataset agreement assignment in order to earn credit for *ANY* of the exercises or the team assignments which use the Yelp data**.  To bring the data from where we staged it on AWS to your Databricks account hosted on AWS (for free by Databricks! Yay!) the code below needs to know where it can downlaod the data from.
# MAGIC
# MAGIC When you run the next cell, a "widget" will appear **at the top of the notebook** that prompts you for your the path to a data manifest.  
# MAGIC On the right-hand side of that widget bar you will see a pushpin (a.k.a. thumbtack) icon that will allow you to pin that to the top of the code window even when you scroll down.  Once you have entered the manifest's path, you can "unpin" the widget bar to make more screen real estate available.
# MAGIC
# MAGIC We will be importing three files to your Databricks account and eventually we will be putting the compressed files they contain in a directory named `/yelp` on the Databricks File System (DBFS) on your Databricks account. The manifest uses a JSON format and contains a JSON array with an object for each file.  Each JSON object provides three properties: the name of the file, an MD5 sum for the file, and a flag as to whether the file should be unzipped. The MD5 sum is a one-way hash that allows us to make sure the file download did not encounter any errors and is exactly the same as the file we originally staged on AWS.  The flag for whether to unzip is because we compress the data flies using the bzip2 format, but the review and user data files have been split by year (the year of the review or the year a user joined Yelp), so we zipped up the directories containing those files.  We need to unzip those directories before moving the files to the `/yelp` irectory on DBFS. You may be wondering why the manifest file is used, but it allows us to easily move the files or update them, and we only need to provide you with the URL to where you can find the current manifest.
# MAGIC
# MAGIC To see the widget (if you just imported the notebook), click on the arrow in the upper 
# MAGIC right-hand corner of the next code cell and select `Run Cell`.  If the widget is already displayed, you can skip this step, but must still complete step 3.
# MAGIC
# MAGIC #### The following cell is Step 2

# COMMAND ----------

dbutils.widgets.text("manifest_url","xxxxxxxxxxxxxxx","Enter the manifest URL:")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Entering the file manifest URL
# MAGIC
# MAGIC In the input box for the widget with the prompt "Enter the manifest URL", enter the URL we provide in class.
# MAGIC
# MAGIC Once you have entered the URL in the widget, we can get started.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Step 4: Getting familiar with the Databricks File System (DBFS)
# MAGIC
# MAGIC When you create a cluster, the cluster has a "driver node", and if you were paying for the resources, you could have as many "worker nodes" as you are willing to pay for.  We are not paying for the cluster, so we have a driver node.  This is a virtual computer, but you can think of it as being like your laptop with a multi-core processor and local hard disk space. DBFS is where we store our data, and it's separate from the cluster, but accessible from the cluster.  As an analogy, you can store data on Google Drive, and you can access that data from your laptop. When you shut your laptop down, the data on Google Drive is still out there on the cloud and accessible to you from any other computer.  The difference is that once your cluster shuts down, your driver node is deleted.  This would be similar to if you borrow a laptop from the library, use it to load data onto your Google Drive account, and then shutdown and return the laptop. If you went back a week later and borrowed a laptop again, it woud liekly be a different laptop, and even if it was the same one, the library may have deleted any files you created on it locally. However, you could still access your data you previously uploaded to Google Drive.  Similarly, when we start a new cluster, we have a different drive node (with a different "local" hard disk), but the data we stored on DBFS is still there in our account.
# MAGIC
# MAGIC You are going to be running code to bring your data over from our bucket on Amazon's S3 to your account on Databricks.  As discussed previously, your data is stored in the Databricks File System, which is referred to as DBFS.  To be able to store your data in DBFS, we are going to first bring it over to the local drive on the driver node and then move it to a new folder named `/yelp` that we create in your account on DBFS.
# MAGIC
# MAGIC The commands for working with DBFS are very similar to Linux, but if you have not used Linux, don't panic, the number of commands we will be using can be counted on one hand (unless you are ET - he only had 2 fingers, but we are assuming you are an Earthling).  If you are a Mac user and have played around at the command line on your laptop, these commands will look familiar since the operating system for a Mac is a variant of Unix (and so is Linux).  All of the commands for working with DBFS are in the dbutils library (which Databricks has conveniently already installed in your account when you spun up a cluster).  Although we will be using only a few commands, you don't need to memorize them, just run the following command in a blank cell and it will show you all of the available commands:
# MAGIC
# MAGIC `dbutils.fs.help()`
# MAGIC
# MAGIC This will display each file system method along with the syntax and a brief description.
# MAGIC
# MAGIC
# MAGIC
# MAGIC Here we are using the Python dot notation.  The `dbutils` module contains functions for handling a number of tasks in Databricks (the name is short for Databricks utilities).  At the moment, we are only interested in the file system utilities for working with DBFS, so we use the dot notation to get the fileystem commands which are in `fs`, and then within the file system commands, we use the dot notation again to say we want to call the `help` method.
# MAGIC
# MAGIC The `dbutils.fs` methods are divided into file system utilities (fsutils) and mount methods.  You won't be mounting other drives, so you will only be using the fsutils methods.  If you have not done so, run the command shown above in the blank code cell below.

# COMMAND ----------

# Run the help function as described above to see the file system functions
dbutils.fs.help()

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 5: Importing the data
# MAGIC
# MAGIC The code in the following cell will import the data files to your yelp directory.  While that cell is running (**it will probably take around 5 minutes**), let's talk about what is happening in that cell.
# MAGIC <ol>
# MAGIC   <li style="padding-bottom:5px;">First, we are importing the library named `requests` which allows us to retrieve data over the web.  This is not built into the core of Python, so it's a separate library.  However, since it's one that's commonly used, Databricks has it in your cluster already.  If this was a less commonly used library, you would need to first load the library on your cluster.</li>
# MAGIC   
# MAGIC   <li style="padding-bottom:5px;">We define a few variables, such as the part of the URL that's the same for all files located on AWS, where we will be downloading the data from.</li>
# MAGIC
# MAGIC   <li style="padding-bottom:5px;">To make the process easier to understand, we break it into steps that can be defined as separate functions.  Each function is defined starting with `def` and the indenting in Python tells it when each function has ended.  The main code near the end of the cell is less than 10 lines long and calls the functions defined above.</li>
# MAGIC
# MAGIC   <li style="padding-bottom:5px;">One of the first functions called is `get_manifest`, which is passed the URL you entered for the widget at the top of the notebook, it tries to download the manifest from that URL, and the manifest says what files are being downloaded.  The manifest is a tiny JSON file that we store out at a public URL and that file is a JSON object containing a name:value pair with the id for the bucket where the data is stored, and two name:value pairs with arrays as the values:
# MAGIC     <ul>
# MAGIC       <li style="padding-bottom:3px;">An array of the files or directories that will be created in the directory where we download the data.</li>
# MAGIC       <li style="padding-bottom:3px;">The second array contains a JSON object for each download file with:
# MAGIC         <ol>
# MAGIC           <li>The name of the file being downloaded</li>
# MAGIC           <li>The MD5 sum of the file. The MD5 sum is a hash of the file contents that returns a string - this is used to make sure the file downloaded is complete.</li>
# MAGIC           <li>A flag indicating if the downladed file should be unzipped.  The review and user downloads are zipped files containing a directory of files.</li>
# MAGIC         </ol>
# MAGIC       </li>
# MAGIC     </ul>
# MAGIC   </li>
# MAGIC   <li style="padding-bottom:5px;">The code cycles through downloading and unzipping the files (as needed), and in our case the user and review files contain a directory of files compressed using the bzip2 format which Spark can load.  As each file is downloaded, the MD5 sum of the file is calculated and compared to the MD5 sum in the manifest to make sure the download is complete and data is not missing.</li>
# MAGIC </ol>  
# MAGIC
# MAGIC When downloading the data, we cannot work directly in DBFS, so we download and unzip the data using the driver node and then movng the data to DBFS.  Keep in mind that where we download the files
# MAGIC on the file system local to the driver node of the cluster disappears when the cluster terminates, but the files we move to DBFS are permanent and will be there again when you start a new cluster.

# COMMAND ----------

import pyspark.sql.functions as f
import requests
import re
import tarfile
import zipfile
import json
import hashlib

FORCE_DOWNLOAD = False

URL_HOST = ".s3-us-west-2.amazonaws.com/"
TEMP_DIR = "/yelptemp/"
ZIPPED_DIR = "/yelptemp/zipped/"
UNZIPPED_DIR = "/yelptemp/unzipped/"
DATA_DIR = "/yelp"

def clean_all():
  ' Removes the data directory if it exists on DBFS'
  try:
    dbutils.fs.rm(DATA_DIR,recurse=True)
  except Exception:
    pass
  

def get_manifest():
  ''' Returns the dictionary that's the download manifest based on the URL
      entered in the URL widget.
      If it's not a valid URL or returns a status code other than 200, an exception is raised.
      If the manifest is not valid JSON, or does not contain name:value pairs named
      id, data_list, and download_list, an exception is raised.  
  ''' 
  manifest_url = dbutils.widgets.get("manifest_url")
  response = requests.get(manifest_url)
  if response.status_code != 200:
    raise Exception(f"The manifest URL {manifest_url} returned a status of " + str(response.status))
  manifest = response.text
  try:
    manifest_dict = json.loads(manifest)
    # The manifest should have a data_list element and a down_Load list element
    if "data_list" in manifest_dict == False:
      raise Exception("The manifest does not contain a data_list.")
    if "download_list" in manifest_dict == False:
      raise Exception("The manifest does not contain a download_list.")
    return(manifest_dict)
  except json.JSONDecodeError as err:
    raise Exception("The manifest is not a valid JSON document.", err)
    

def check_data(manifest):
  ''' Function used to check if the data directory contains valid
      copies of all of the files in the download. The manifest dictionary
      is passed as a parameter and is expected to comtain a data_list containing
      the names of each file expected in the data directory.
      If a file is missing, this method returns False.
      If all of the files exist, it returns True.
  '''
  try:
    data_dir_list = dbutils.fs.ls(DATA_DIR)
    if len(db_dir_list) == 0:
      return(False)
      file_list = manifest["file_list"]
      existing_list = dbutils.fs.ls(DATA_DIR)
      for file_name in file_list:
        found == False
        for info in existing_list:
          if info.name == file_name:
            found == True
            break
        if found == False:
          return(False)
      # looped through all of the required files and they are there
      return(True)
  except Exception:
    # The directory does not exist, does not match the manifest, or the hashes don't match
    return(False)
  
def get_bucket_id(manifest):
  ''' The manifest is expected to contain a name:value pair named id
      where the value is the bucket name on S3 where the files are
      staged.  If the id is missing or is a blanks string, then an
      exception is raised, otherwise the bucket id is returned.
  '''
  try:
    bucket = manifest['id'].strip()
    if len(bucket) == 0:
      raise Exception("The id provided in the manifest was an empty string, but should be the name of the bucket being downloaded from.")
    else:
      return(bucket)
  except Exception as e:
    raise Exception("An error occurred in retrieving the bucket id from the manifest", e)
      
  
def download_file(manifest_item, bucket_id):
  ''' Given a dictionary from the download list, download the file to the
      temporary directory for downloading the file and check the
      MD5 sum to make sure it matches.
      If the MD5 sum does not match, an excetion is raised, otherwise it prints
      that the file was successfully downloaded.
  '''
  file_name = manifest_item["name"]
  item_md5sum = manifest_item["md5"]
  request_url = "https://" + bucket_id + URL_HOST + file_name
  local_name = ZIPPED_DIR + file_name 
  print("requesting file from:", request_url)
  r = requests.get(request_url, stream=True)
  status_code = r.status_code
  # If the status code is 200, then we successfully retrieved the file
  if status_code != 200:
    raise Exception(f"The {file_name} download failed. A status code of {str(status_code)} was returned from the URL:{request_url}.")
  else: # write the file 
    with open(local_name, 'wb') as file:
      for chunk in r.iter_content(chunk_size=4096):
        file.write(chunk)
        file.flush()
    file.close()
  #check if the hash of the file downloaded matches the md5 sum in the manifest
  with open(local_name, 'rb') as data_file:
    md5sum = hashlib.md5( data_file.read() ).hexdigest()
    if md5sum.lower() != item_md5sum.lower():
      raise Exception(f"The file {file_name} downloaded from Google Drive generated a MD5 sum of {md5sum} instead of the MD5 sum in the manifest ({item_md5sum}) so it may be corrupted and the processing was terminated.")
    else:
      print ("successfully downloaded:", file_name)

      
def process_file(manifest_item):
    ''' The file is now downloaded.  If the file is zipped,
        it first needs to be unziiped, and either way, moved
        to the DBFS data directory.
    '''
    local_name = ZIPPED_DIR + manifest_item["name"]
    local_path = "file:" + local_name
    is_zipped = manifest_item["zipped"] == "true" # This is either Ture or False
    if is_zipped:
      with zipfile.ZipFile(local_name,"r") as zip_ref:
        zip_ref.extractall(UNZIPPED_DIR)
      untar_info = dbutils.fs.ls("file:" + UNZIPPED_DIR)
      # The zip file could contain a directory, a file, or more than 1 file,
      # so we loop through the file list, moving all of them to DBFS
      for info in untar_info:
        destination = DATA_DIR + "/" + info.name
        dbutils.fs.mv(info.path, destination, recurse=True)  
      dbutils.fs.rm(local_path)
    else: # file was not zipped (or should remain zipped), so just move it
        destination = DATA_DIR + "/" + manifest_item["name"]
        dbutils.fs.mv(local_path, destination)  
    print ("processed:", local_name)
    
                      
def load_data(manifest_list, bucket_id):
  ''' Loops through the files in the download list from the manifest and 
      downloads the file, verifies the MD5 sum is correct, unzips it if needed,  
      and moves the file or folder that was in it to the data directory.'''
  # Create the empty temporary directories
  try:
    dbutils.fs.rm("file:" + TEMP_DIR,recurse=True)
  except Exception:
    pass
  # Create the temporary local directory and sub-directories
  dbutils.fs.mkdirs("file:" + TEMP_DIR)
  dbutils.fs.mkdirs("file:" + ZIPPED_DIR)
  dbutils.fs.mkdirs("file:" + UNZIPPED_DIR)
  # Loop through the files to download
  for item in manifest_list:
    download_file(item, bucket_id)
    process_file(item)
  # Remove the temp directory used to unzip the files
  dbutils.fs.rm("file:" + TEMP_DIR, recurse=True)
  
  
# *******************************************  
# Run the Actual Routine to Load the Data
# This code uses the above defined functions
# *******************************************
if FORCE_DOWNLOAD == True:
  clean_all()
manifest_dict = get_manifest()
if check_data(manifest_dict) == False:
  bucket_id = get_bucket_id(manifest_dict)
  download_list = manifest_dict["download_list"]
  load_data(download_list, bucket_id)
else:
  print("All of the required files exist in the data directory already, so the download was not processed.")
print("Done")
  

# COMMAND ----------

# MAGIC %md ### Step 6: Listing the Files Loaded
# MAGIC
# MAGIC In the above cell that brought the data over to your Databricks account, we use the dbutils method to list the file contents of the directory.  Here you are going to use that utility again, but since it will be the only line in your cell (so it's the last line), you don't need to assign the value returned to a variable, the result return will be printed as the output of the cell.
# MAGIC
# MAGIC In the following cell, add a line of code to list the `/yelp` directory.  You should see three files and two directories listed.
# MAGIC
# MAGIC If we wanted to *use* the list returned by the `ls` method, we could assign it to a variable name. 

# COMMAND ----------

# Add your code here and run it to list the contents of your /yelp directory on DBFS
dbutils.fs.ls("/yelp")

# COMMAND ----------

yelplist = dbutils.fs.ls("/yelp")
type(yelplist)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 7: Listing the Review and User Subdirectories
# MAGIC In the above cell when you listed the contents of the `/yelp` directiory on DBFS, both `review` and `user` had a size of zero and ended with a slash, indicating they were directories and not files.  Copy the code you used in the above cell to list the `/yelp` directory (copy it twice actually), and modify the path passed as a parameter so that it first lists the contents of the `review` directory and then the contents of the `user` directory.

# COMMAND ----------

# Add code here and run it to list the contents of the /yelp/review director on DBFS
dbutils.fs.ls("/yelp/review")

# COMMAND ----------

# Add code here and run it to list the contents of the /yelp/user directory on DBFS
dbutils.fs.ls("/yelp/user")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Working With Files - Part 2: Getting the Category Definitions
# MAGIC
# MAGIC Above you loaded the Yelp data as zipped files in the bzip2 format to save space.  In the following cell we will take a slightly different approach using the `urllib` module to read a JSON data file from a page on Yelp's website.  
# MAGIC
# MAGIC In the dataset's business file, most businesses have a `categories` field which is a comma-separated list of the categories in which a business operates.  Some categories are at a high level (such as "Restaurants"), but the categories form a hierarchy with increasing levels of detail, so there are more specific categories too, such as "Dim Sum" which is within the "Chinese" category, which in turn is within the "Restaurants" category.  There are over 1500 categories (and growing).  As part of their "Fusion API", Yelp makes this list available to web developers who are creating apps that use Yelp data (and drive traffic to Yelp).  The page documenting the controlled vocabulary for categories can be found **<a href="https://www.yelp.com/developers/documentation/v3/all_category_list" target="_blank">here</a>**.
# MAGIC
# MAGIC On that site there's a link to a JSON file defining the hierarchy for this controlled vocabulary.  Although there are a lot of categories, as a JSON file this file is tiny compared to the Yelp data, so we don't need to compress it.
# MAGIC
# MAGIC ### The categories.json file is a small file, so we can load it through the GUI interface
# MAGIC
# MAGIC To load the categories.json through the GUI:
# MAGIC 1. Download the categories.json file from the link to the website.  You should now have a file named categories.json
# MAGIC 2. Through the GUI on the Data option (click the Create Table button, then load the file, but don't create a table)
# MAGIC
# MAGIC You will now have a file on the path: /FileStore/tables/categories.json
# MAGIC
# MAGIC You want to move that file to the path: /yelp/categories.json
# MAGIC
# MAGIC ### Moving the file in DBFS
# MAGIC
# MAGIC In the output for the help command when you ran it earlier, you will see a function named `mv` which is described as "Moves a file or directory, possibly across FileSystems"
# MAGIC
# MAGIC The file you loaded is on the path: /FileStore/tables/categories.json
# MAGIC
# MAGIC You want to move that file to the path: /yelp/categories.json
# MAGIC
# MAGIC The `mv` has two parameters you must enter, the "from" path and the "to" path.  There is a third parameter named "recurse" that has the default boolean value `False`.  The recurse parameter is only needed when we are moving directories, so we won't use it here. If we were moving a directory, we would want to set it to `True` so any subdirectories are also moved.
# MAGIC
# MAGIC We know the path where our file currently is and where we want to move it to, so use the `dbutils.fs.mv` function in the next cell and include the "from" and "to" paths, seperated by a comma.  Keep in mind that the paths are string variables (probably obvious, but it also tells you that in the help output), so the paths must be enclosed within quotation marks.
# MAGIC
# MAGIC #### Step 1: Use the `mv` method from file system methods in dbutils to move the file

# COMMAND ----------

# Add your code to move the file in this cell
dbutils.fs.mv("/FileStore/tables/categories.json" , "/yelp/categories.json")

# COMMAND ----------

# MAGIC %md #### **<span style="color:#22b922">Riddle me this</span>**: Why does the output have the value `True`?  
# MAGIC
# MAGIC The `mv` function has a Boolean return value, so instead we could have run the following code:
# MAGIC
# MAGIC `result = dbutils.fs.mv("/FileStore/tables/categories.json", "/yelp/categories.json")`
# MAGIC
# MAGIC That would have created a new variable named `result` and assigned the value returned by `mv` to that variable.  The value assigned to `result` would have been the Boolean value `True` (assuming the file was moved successfully)
# MAGIC and then we could have printed the value of `result` with the following Python code:
# MAGIC
# MAGIC `print(result)`
# MAGIC
# MAGIC In the code we actually ran, we did not assign the value returned by the `mv` method to a variable, so Jupyter printed out the value returned by the function call.
# MAGIC
# MAGIC **PLEASE NOTE:** Although Jupyter printed out the returned value of our call to `mv`, this is only because it's the last line in our code cell.  If we had additional code in that cell that wrote out or generated other values, the `True` returned by the call to `mv` would not be shown.

# COMMAND ----------

# MAGIC %md #### Step 1b: List the files in /yelp
# MAGIC
# MAGIC You have now moved the categories.json file into the same directory where you loaded the Yelp data above in Part 1. In the following cell, list the files again and you will now see the Yelp data and the categories.json file.

# COMMAND ----------

# Add your code to list the directory in this cell


# COMMAND ----------

# MAGIC %md 
# MAGIC # Working with Files - Part 3: Finding Gender Data
# MAGIC
# MAGIC Yelp wants to create the best user experience possible and show authentic reviews.  They have a proprietary 
# MAGIC algorithm for ranking the reviews they show users.  The average star rating for a business is part of it,
# MAGIC but not the whole story.  The number of reviews is part of it, but not the whole story.  
# MAGIC Since many users will not read more than a couple reviews, having a good algorithm when ordering the reviews to 
# MAGIC show them to a user is critical to Yelp's business.  They need to always be thinking of how to make the ranking better
# MAGIC in order to improve the customer experience.
# MAGIC
# MAGIC What if men and women review differently?  Is a 4-star rating from a man the same as a 4-star rating from a woman?
# MAGIC In other words, might men or women consistently rate businesses higher or lower?  Would this depend on the type
# MAGIC of business?  Are ratings by one gender more consistent than the other?  If so, could we be more certain of the validity
# MAGIC of the ranking of a business based on 5 reviews by women than we would by 5 reviews by men (or vice versa)?
# MAGIC
# MAGIC If there is a difference, should that be taken into account when Yelp ranks businesses based on their ratings?

# COMMAND ----------

# MAGIC %md ### Using First Name as a Proxy for Gender
# MAGIC
# MAGIC We have a problem.  We don't have information about the user's gender.  However, we are curious and persistent.  Is there a proxy
# MAGIC we could use?  A proxy is a stand-in or substitute for something else.  Could a user's first name be a proxy for their gender?  What issues would we have if we use name
# MAGIC as a proxy for gender?
# MAGIC
# MAGIC First, we need some data to associate user names with genders.  We can start searching on the web.  Possibly lists of baby names?
# MAGIC If you were to search for a while, you would find the Social Security Administration's (SSA) website with the 1000 most popular baby names
# MAGIC for girls and boys (at least in the U.S.), but we want more than the most popular names, we want to tie as many names as possible to a gender.
# MAGIC If you dig a little further, you'll find the SSA page titled <a href="https://www.ssa.gov/oact/babynames/limits.html" target="_blank">Beyond the Top 1000 Names</a>.
# MAGIC
# MAGIC Read that page - they have a zip file there with national data as to every first name used to apply for a social security account and a count
# MAGIC of the number of men and women applying with that name, based on their date of birth.  Hover your mouse over that link, the file can be downloaded 
# MAGIC from the following URL:  <a href="https://www.ssa.gov/oact/babynames/names.zip" target="_blank">https://www.ssa.gov/oact/babynames/names.zip</a>
# MAGIC
# MAGIC We could download that file and unzip it (and you may want to do that after class), but what the zip file contains is a file for each year-of-birth, so 
# MAGIC for those little girls and boys born in 2017 who applied for a social security card, the file is named `yob2017.txt` (a copy is in this week's module in Canvas) and it contains data in the following
# MAGIC format:
# MAGIC
# MAGIC Emma,F,19738 <br/>
# MAGIC Isabella,F,15100 <br/>
# MAGIC Sophia,F,14831 <br/>
# MAGIC Mia,F,13437 <br/>
# MAGIC Liam,M,18728 <br/>
# MAGIC Logan,M,13974 <br/>
# MAGIC Benjamin,M,13733
# MAGIC
# MAGIC So if you just had a baby boy or girl and named her Isabella or named him Liam because you thought it would be unique, apparently so did everybody else.
# MAGIC
# MAGIC As you can see, the file has 3 columns, the name, the gender (M or F), and the number of people with that name who were born in 2017 and applied for a social security card.  You should also note there are no headers.
# MAGIC
# MAGIC It does not say what year the data is from, but the year is in the name of each file, so in a later exercise we will do an *enriching transformation* to insert
# MAGIC that metadata into a new column in the DataFrame.
# MAGIC
# MAGIC ### Step 1: Downloading the data
# MAGIC
# MAGIC We are again going to use the `urllib` module. As before with the Yelp categories data, for the download, all of the necessary code is already included below.
# MAGIC
# MAGIC Using `dbutils.fs`, we will create a new directory named `ssa` where we are going to download the zip file from the SSA: `names.zip`.  However, we use the `file:` prefix for the path to say we want to create the directory local to the driver node for our cluster.  We need to do this because we cannot treat DBFS as a local file system.  Later we will move the zipped and unzipped data to DBFS.

# COMMAND ----------

import requests
import urllib

SSA_URL = "https://www.ssa.gov/oact/babynames/names.zip"
SSA_DIR ="/ssa/"
SSA_FILENAME = "names.zip"

# If the ssa directory exists, remove it
dbutils.fs.rm("file:"+SSA_DIR, recurse=True)
dbutils.fs.mkdirs("file:"+SSA_DIR)

urllib.request.urlretrieve(SSA_URL, SSA_DIR+SSA_FILENAME)

# COMMAND ----------

# MAGIC %md ###  Step 2: Check if your file was written
# MAGIC
# MAGIC Did the file end up in our `ssa` directory?  In the cell below, add code that uses the `ls` method from  `dbutils.fs` to list 
# MAGIC the contents of the `file:/ssa` directory which is a directory local to the driver node and ***not*** part of the DBFS.  We cannot store
# MAGIC files on the local system long-term since the local file system is on the driver node and it is gone when the cluster terminates.  Any
# MAGIC files moved to DBFS will still be there after the cluster terminates so=ince DBFS is accessible from the driver node, but not onthe driver node.

# COMMAND ----------

# Add your code here to list the /ssa directory (and run the code)
dbutils.fs.ls("file:/ssa")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Unzipping the data
# MAGIC When we loaded our Yelp data we loaded bzip2 files because Spark does not read zip files, but here we
# MAGIC are still using Python (not Spark), to unzip the file, so that's not a problem.
# MAGIC
# MAGIC We will need to import another Python module that has the functions to unzip a file, and we will
# MAGIC use the Databricks `dbutils` functions to create a subdirectory we are going to unzip the data files into. 
# MAGIC
# MAGIC **Keep in mind that when we are running the zip commands, we are just using Python and not Spark**.  Why does that matter?  The paths we provide
# MAGIC are not pointing to paths on DBFS (since the plain old Python does not "know" about DBFS).  When we use the path "/ssa", the zip command assumes
# MAGIC we are talking about the `ssa` directory off the root of the driver node.  If we use the path "/ssa" in a dbutils command, it assumes we are
# MAGIC referring to a DBFS path since we did not prefix the path with `file:`.
# MAGIC
# MAGIC Once we unzip the data, we must move the directory to DBFS.  While data on DBFS will remain when our cluster shuts down, the files 
# MAGIC local to the driver will not exist once the cluster is shutdown.
# MAGIC
# MAGIC **After running the following cell, in Step 4 be sure to use the `ls` method to see the listing of all of the SSA files for each year**

# COMMAND ----------

import zipfile

SSA_SUBDIR = "data"
ssaDataDir = "file:" + SSA_DIR + SSA_SUBDIR
dbutils.fs.mkdirs(ssaDataDir) 

ssaNamesZip = SSA_DIR + SSA_FILENAME

with zipfile.ZipFile(ssaNamesZip,"r") as zip_ref:
    zip_ref.extractall(SSA_DIR + SSA_SUBDIR)
    
# Move the files to DBFS
dbutils.fs.rm("dbfs:"+SSA_DIR, recurse=True)
dbutils.fs.mv("file:"+SSA_DIR, "dbfs:"+SSA_DIR, recurse=True)

# COMMAND ----------

# MAGIC %md ###  Step 4: Check if your data was unzipped properly
# MAGIC
# MAGIC Did the files for each year's data end up in our `data` subdirectory under `ssa`?  Use the `ls` method from  `dbutils.fs` to list 
# MAGIC the contents of the `/ssa/data` directory.

# COMMAND ----------

# Add your code here to list the contents of the /ssa/data directory (and run it)
dbutils.fs.ls("/ssa/data")

# COMMAND ----------

# MAGIC %md ### Step 5: What does one of these data files look like?
# MAGIC
# MAGIC Using the `head` method in `dbutils.fs` we can take a peek at the first "X" bytes.  We will use the default of 64K.

# COMMAND ----------

dbutils.fs.head("dbfs:/ssa/data/yob1880.txt")

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 6: Making it more human-readable
# MAGIC In the above command, the `head` function is just getting bytes.  For a more human-readable view of the head of the file, we can enclose the call to `dbustils.fs.head()` inside a call 
# MAGIC th the Python print function and the `\r\n` which represent line feeds in the file will now show each name on a separate line.
# MAGIC
# MAGIC **In the following cell**, enclose the call to the `head` function from the cell above in a call to the python `print` function.

# COMMAND ----------

# In this cell, add a call to the print function around the call to the dbutils.fs.head method
print(dbutils.fs.head("dbfs:/ssa/data/yob1880.txt"))

# COMMAND ----------

# MAGIC %md # Working With Files - Part 4: Creating Tables for Reviews and Users
# MAGIC Loading the review and user data from the JSON files is tedious, so we will create tables to load the data and strips out the text of the reviews.
# MAGIC
# MAGIC There is a separate notebook named "Building Review and User Tables Version 2" that will build the tables, and when you imported the Databricks archive (dbc) file containing this notebook, that other notebook was loaded into the same folder. You will need to run it (it takes about 25 minutes).  
# MAGIC
# MAGIC Once you have run it, come back here and 
# MAGIC run the following cells (you *won't* need to rerun the code above), which will rebuild the tables and print out the tables that are defined.  You do not even need to run on the same cluster, so if your cluster had shut down, just start a new one.  After you run this cell, you can hide the results.

# COMMAND ----------

# MAGIC %run "./Building Review and User Tables Version 2"

# COMMAND ----------

# MAGIC %md ### Show the Tables
# MAGIC The above cell re-ran the *Building Review and User Tables Version 2* notebook.  If that notebook was not connected to the current cluster, it did not matter.  The above cell **MUST** finish before running the following cell.
# MAGIC
# MAGIC That other notebook recreated the tables for the user and review data, so in the following cell we can show (list) those tables.

# COMMAND ----------

spark.sql("SHOW TABLES").show(truncate=False)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Assignment Deliverable
# MAGIC
# MAGIC * Make sure you have added and run code for those steps where you were supposed to list or print the results.
# MAGIC * Make sure you have successfully run the code in part 4 to load the review and user tables
# MAGIC * Publish your notebook as you have done before
# MAGIC * Submit the published URL as the deliverable for this assignment