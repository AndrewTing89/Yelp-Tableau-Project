# Databricks notebook source
# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("business_category_table", None, summary=True, delete=False)

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

#Assigning a review_order number using the ROW_NUMBER() clause so they can be binned#
df_ordered_reviews = spark.sql("""
SELECT *, 
ROW_NUMBER() OVER (PARTITION BY business_id ORDER BY date) AS review_order
FROM reviews_without_text_table
ORDER BY business_id, review_order
""").cache()
print(f"review count:{df_ordered_reviews.count()}")
df_ordered_reviews.show(200, truncate=False)
df_ordered_reviews.createOrReplaceTempView("ordered_reviews")
process_or_create_table("ordered_reviews_table", "df_ordered_reviews", summary=True, delete=False)

# COMMAND ----------

df_all_binned_reviews = spark.sql("""
SELECT * ,
( CEILING(review_order / 5) ) AS bin5 
FROM ordered_reviews
ORDER BY business_id, review_order
""")
print(f"review count:{df_all_binned_reviews.count()}")
df_all_binned_reviews.show(200, truncate=False)
df_all_binned_reviews.createOrReplaceTempView("all_binned_reviews")
process_or_create_table("all_binned_reviews_table", "df_all_binned_reviews", summary=True, delete=False)

# COMMAND ----------

#Binning the reviews#
#Binned by 5#
#Only compare across the first 80 reviews across all businesses
#Final dataframe to be joined with combined_reviews_categories dataframe later#
df_binned_reviews = spark.sql("""
SELECT business_id, review_id, useful, funny, cool, review_order,
CASE
  WHEN review_order <=5 THEN 1
  WHEN review_order <=10 THEN 2
  WHEN review_order <=15 THEN 3
  WHEN review_order <=20 THEN 4
  WHEN review_order <=25 THEN 5
  WHEN review_order <=30 THEN 6
  WHEN review_order <=35 THEN 7
  WHEN review_order <=40 THEN 8
  WHEN review_order <=45 THEN 9
  WHEN review_order <=50 THEN 10
  WHEN review_order <=55 THEN 11
  WHEN review_order <=60 THEN 12
  WHEN review_order <=65 THEN 13
  WHEN review_order <=70 THEN 14
  WHEN review_order <=75 THEN 15
  WHEN review_order <=80 THEN 16  
  ELSE 0
END AS bins
FROM ordered_reviews
WHERE review_order <=80
ORDER BY business_id, review_order
""")
print("Record Count:", df_binned_reviews.count())
df_binned_reviews.show(200)
df_binned_reviews.createOrReplaceTempView("binned_reviews")

# COMMAND ----------

#Binning the reviews#
#Binned by 5#
#Only compare across the first 80 reviews across all businesses
#Final dataframe to be joined with combined_reviews_categories dataframe later#
df_binned_reviews = spark.sql("""
SELECT business_id, review_id, useful, funny, cool, review_order,
CASE
  WHEN review_order <=5 THEN 1
  WHEN review_order <=10 THEN 2
  WHEN review_order <=15 THEN 3
  WHEN review_order <=20 THEN 4
  WHEN review_order <=25 THEN 5
  WHEN review_order <=30 THEN 6
  WHEN review_order <=35 THEN 7
  WHEN review_order <=40 THEN 8
  WHEN review_order <=45 THEN 9
  WHEN review_order <=50 THEN 10
  WHEN review_order <=55 THEN 11
  WHEN review_order <=60 THEN 12
  WHEN review_order <=65 THEN 13
  WHEN review_order <=70 THEN 14
  WHEN review_order <=75 THEN 15
  WHEN review_order <=80 THEN 16  
  ELSE 0
END AS bins
FROM ordered_reviews
WHERE review_order <=80 AND useful <= 140
ORDER BY business_id, review_order
""")
print("Record Count:", df_binned_reviews.count())
df_binned_reviews.show(200)
df_binned_reviews.createOrReplaceTempView("binned_reviews_useful_140")

# COMMAND ----------

df_bin_values = spark.sql("""
SELECT business_id, bins, 
SUM(useful) AS sum_of_useful_per_bin,
AVG(useful) AS avg_of_useful_per_bin,
SUM( IF(useful > 0,1,0) ) AS useful_count_per_bin
FROM binned_reviews
GROUP BY business_id, bins
ORDER BY business_id, bins
""")
print("Record Count:", df_bin_values.count())
df_bin_values.show(200, truncate=False)
df_bin_values.createOrReplaceTempView("bin_values")


# COMMAND ----------

#Combining categories#
df_combined_categories = spark.sql("""
SELECT  business_id, name, review_count, category_count, top_categories,
CASE
  WHEN ARRAY_CONTAINS(top_categories, 'Shopping') THEN 'Shopping'
  WHEN ARRAY_CONTAINS(top_categories, 'Pets') THEN 'Pets'
  WHEN ARRAY_CONTAINS(top_categories, 'Automotive') THEN 'Automotive'
  WHEN ARRAY_CONTAINS(top_categories, 'Restaurants') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Nightlife') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Food') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Nightlife') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Home Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Local Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Professional Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Financial Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Active Life') THEN 'Health & Wellness'
  WHEN ARRAY_CONTAINS(top_categories, 'Health & Medical') THEN 'Health & Wellness'
  WHEN ARRAY_CONTAINS(top_categories, 'Beauty & Spas') THEN 'Beauty & Spas'
  WHEN ARRAY_CONTAINS(top_categories, 'Event Planning & Services') THEN 'Travel & Events Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Hotel & Travel') THEN 'Travel & Events Related'
  ELSE 'Other'
END AS combined_category
FROM business_category_table
ORDER BY business_id
""")
print("Record Count:", df_combined_categories.count())
df_combined_categories.show()
df_combined_categories.createOrReplaceTempView("combined_categories")
#process_or_create_table("combined_categories_table", "df_combined_categories", summary=True, delete=False)

# COMMAND ----------

df_business_review_count = spark.sql("""
SELECT business_id, name, review_count
FROM combined_categories
ORDER BY business_id
""")
print("Record Count:", df_business_review_count. count())
df_business_review_count.show()
df_business_review_count.createOrReplaceTempView("business_review_count")

# COMMAND ----------

df_combined_reviews_categories = spark.sql("""
SELECT A.business_id, A.name, A.combined_category, A.review_count, Z.review_id, Z.useful, Z.funny, Z.cool, Z.review_order, Z.bins
FROM combined_categories as A INNER JOIN binned_reviews as Z
ON A.business_id = Z.business_id
ORDER BY A.business_id, review_order
""")
print("Record Count:", df_combined_reviews_categories.count())
df_combined_reviews_categories.show()
df_combined_reviews_categories.createOrReplaceTempView("combined_reviews_categories")
process_or_create_table("combined_reviews_categories_table", "df_combined_reviews_categories", summary=True, delete=False)

# COMMAND ----------

df_combined_values_categories = spark.sql("""
SELECT A.business_id, A.name, A.combined_category, Z.sum_of_useful_per_bin, Z.useful_count_per_bin, Z.avg_of_useful_per_bin, Z.bins
FROM combined_categories as A INNER JOIN bin_values as Z
ON A.business_id = Z.business_id
ORDER BY A.business_id, bins
""")
print("Record Count:", df_combined_values_categories.count())
df_combined_values_categories.show()
df_combined_values_categories.createOrReplaceTempView("combined_values_categories")
process_or_create_table("combined_values_categories_table", "df_combined_values_categories", summary=True, delete=False)

# COMMAND ----------

