# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright &copy; 2022 Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md # Who worked on this assignment:
# MAGIC
# MAGIC -Andrew Ting, Emmanuel Zarate, Michelle Tran, Bao Pham, Emily Wong
# MAGIC
# MAGIC Business and Categories notebook: https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/336624331222120/826850450897495/7222240468955367/latest.html
# MAGIC

# COMMAND ----------

# MAGIC %md # Bringing All of Our Data Together
# MAGIC
# MAGIC #### The ***main*** question we are asking of the Yelp data is:<br/>
# MAGIC *<div style="margin-left:50px;max-width:600px;background-color:#39506B;"><div style="margin:20px;font-size:1.5em;color:#ffffff">Do reviews more often get voted useful when there are fewer reviews for a business?</div></div>*
# MAGIC
# MAGIC ***Our hypothesis is:*** since a user must see a review (and most likely read it), before clicking the "Useful" button, users are more likely to read reviews when there are fewer reviews for a business.  If there are many reviews, our hypothesis is that the user would go with the wisdom of the crowd and not read individual reviews, and even if they did read reviews, they would not read many.  When there are fewer reviews, our hypothesis is that they would read all or at least more of the reviews since there is no crowd providing an opinion yet.
# MAGIC
# MAGIC
# MAGIC In class we have done a number of data wrangling exercises looking at the different data files relevant to our question and bringing them together.
# MAGIC For the question we are asking, we need the following data sources:
# MAGIC * Yelp categories (not part of the Yelp dataset, but avalable **<a href="https://www.yelp.com/developers/documentation/v3/all_category_list" target="_blank">here</a>**).
# MAGIC * Yelp business data - all of the businesses in the 8 metro areas included in the dataset.
# MAGIC * Yelp reviews - the reviews written on all of the businesses in the business data (to the extent that Yelp considers them to be legitimate reviews).
# MAGIC * Yelp user data - The data describing those Yelp users who wrote the reviews included in the Yelp review data (we do NOT have all of the users' revirews - only those written about the 8 metro areas in the dataset).
# MAGIC * Social Security Administration (SSA) data - This data ia available at this SSA page titled **<a href="https://www.ssa.gov/oact/babynames/limits.html" target="_blank">Beyond the Top 1000 Names</a>**. We will use it to predict the gender of Yelp users.
# MAGIC
# MAGIC **<span style="font-size:1.2em;">The connections between our data files are as follows:</span>**<br/>
# MAGIC <img src="https://www.sjsu.edu/people/scott.jensen/courses/BUS4_118D/Yelp_Project_Data.png"/>
# MAGIC
# MAGIC **Notes about the combined notebooks:**<br/>
# MAGIC * The category definitions and Yelp business data is combined and wrangled in the Business and Categories notebook
# MAGIC   * That data is written out to the table `business_category_table`
# MAGIC * The Yelp user data and the SSA name data are wrangled and combined to predict each Yelp user's gener in the `User and Gender` notebook
# MAGIC   * That data is written out to the table `user_gender_table`
# MAGIC * Since this notebook was extracted from a notebook that combinse all of the steps, this notebook starts at Step 13

# COMMAND ----------

# MAGIC %md
# MAGIC # Step 0: Loading table definitions written in other notebooks 
# MAGIC
# MAGIC Functions from the `Process or Create Table` notebook are embedded here and used to load the tables writtin in the other notebooks. The function used is named `process_or_create_table` and the format is:<br/>
# MAGIC `process_or_create_table(TBL_NAME, DF_NAME, summary=True, delete=False)`
# MAGIC
# MAGIC Since the tables are built in another notebook, and the DataFrames written out to create the tables are NOT in this notebook, the `delete` parameter should ***always*** be `False` (the defualt), so it can be omitted.  
# MAGIC
# MAGIC Similarly, the `DF_NAME` parameter should be omitted or set to `None`. If the table does not already exist, the other notebook will need to be run first.  If the table's Parquet files exist, but the table definition has not been created on the current cluster, 
# MAGIC the `process_or_create_table` function will rebuild the table from the files.
# MAGIC
# MAGIC #### The following cell is Step 0:

# COMMAND ----------

# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("business_category_table", None, summary=True, delete=False)

# COMMAND ----------

process_or_create_table("user_gender_table", None, summary=True, delete=False)

# COMMAND ----------

# MAGIC %md # Step 13: Loading the Review Data
# MAGIC The following cell imports a notebook that loads the Yelp review data into a table named `reviews_without_text_table`.
# MAGIC
# MAGIC If the review data has been previously loaded, the table will load very quickly (less than a minute), but if has not previously been created, this could take 20 minutes to run.
# MAGIC
# MAGIC Since the reviews data is large, we exclude the text field (this is the actual text of the review).
# MAGIC
# MAGIC After running the following cell, you may want to hide the output, but make sure it has completed running first.
# MAGIC
# MAGIC #### The following cell is step 13:

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

# MAGIC %md ### Step 14: Identifying early reviews
# MAGIC
# MAGIC Since our question is asking wheher earlier reviews at a business (that's when there are fewer reviews), get more useful votes, we need to decide how to identify those reviews and compare them.  As a starting point we order the reviews chronologically.
# MAGIC
# MAGIC In this step we are also bring in the data from the `ser_gender_table` to identify user characteristics of the reviews.
# MAGIC
# MAGIC #### The following cell is Step 14:

# COMMAND ----------

df_ordered_reviews = spark.sql("""
SELECT R.*, 
       ARRAY_CONTAINS(elite_years, YEAR(R.date)) AS elite, 
       U.is_elite AS ever_elite, 
       COALESCE(YEAR(R.date) >= U.first_elite, false) AS after_elite, 
       U.gender,
       ROW_NUMBER() OVER (PARTITION BY business_id ORDER BY date) AS review_order
FROM reviews_without_text_table AS R INNER JOIN user_gender_table AS U
ON R.user_id = U.user_id
ORDER BY business_id, review_order
""").cache()
print(f"review count:{df_ordered_reviews.count()}")
df_ordered_reviews.show(200, truncate=False)
df_ordered_reviews.createOrReplaceTempView("ordered_reviews")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 15: Dividing reviews into bins
# MAGIC
# MAGIC To compare the voting patterns for early reviews with later reviews, we want to break the reviews at a business into segments of an equal number of reviews; we refer to these segments as bins.
# MAGIC
# MAGIC <img src="https://www.sjsu.edu/people/scott.jensen/courses/BUS4_118D/TimelineForReviews.png" width="647" height="99"/>
# MAGIC
# MAGIC The bins are not equal length in time, but in number of reviews.  The hypothesis for our question is that when there are fewer reviews, Yelp users would be more inclided to read the reviews, and when they do, vote for those they find useful.  Whether the reviews were written a day, week, or month apart is less likely to matter than the number of reviews.
# MAGIC
# MAGIC **NOTE:** Your team ***will need to do some profiling*** of the number of reviews at businesses and adjust the bin size accordingly.  Here we are calculating bins of 5 reviews and bins of 10 reviews.
# MAGIC
# MAGIC #### The following cell is Step 15:

# COMMAND ----------

df_binned_reviews = spark.sql("""
SELECT *, 
( CEILING(review_order / 5) ) AS bin5, 
( CEILING(review_order / 10) ) AS bin10
FROM ordered_reviews
ORDER BY business_id, review_order
""")
df_binned_reviews.show(200, truncate=False)
df_binned_reviews.createOrReplaceTempView("binned_reviews")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 16: Votes per bin
# MAGIC There are at least four approaches we could use for determining the number of useful votes recieved by the reviews in each bin at a business:
# MAGIC 1. Total number of useful votes summed for all reviews in that bin
# MAGIC 2. Average (mean) number of votes per review in a bin (could be heavily influenced by outliers)
# MAGIC 3. Total number or percentage of reviews in each bin that recieved at least 1 useful vote
# MAGIC 4. Median number of useful votes received by the reviews in each bin
# MAGIC
# MAGIC In the following cell we calculate these for the bins consisting of 10 votes.  The calculation of the median for 5 votes would be easier since there is not a need to average the reviews in the 5th and 6th positions as the median (with 5 reviews, the 3rd review in sorted order is the median).
# MAGIC
# MAGIC **NOTE**: Here we address the issue of partial bins.  For example, of a business has 32 reviews in total, when using a bin size of 10, there have 3 full bins and one partial bin.  Only the full bins are retained.  If the number of useful votes per review were constant, partial bins would appear to have fewer votes when using the first and third approaches listed above.
# MAGIC
# MAGIC The following cell calculates the number of useful votes for the four approaches listed above **when the bin size is 10**.
# MAGIC
# MAGIC If we wanted to, we could make the query adapt to other bin sizes by using a formatted string with formulas for the portion of the calculation dependent on the bin size.  This would make the query more flexible, but harder to understand.  We could use a formatted string because the query is really just a string parameter for the `spark.sql` method.
# MAGIC
# MAGIC #### The following cell is step 16a: (bins of size 10)

# COMMAND ----------

df_bin_summary = spark.sql("""
WITH ordered AS 
     (SELECT review_id, business_id, bin10 AS bin, review_order, useful, elite, ever_elite, after_elite, gender,
             ROW_NUMBER() OVER (PARTITION BY business_id, bin10 ORDER BY useful) As median_order,
             COUNT(*) OVER (PARTITION BY business_id, bin10) As bin_count
      FROM binned_reviews),

     median AS 
     (SELECT business_id, bin, AVG(useful) AS median_votes
      FROM ordered
      WHERE median_order IN (5,6) AND bin_count = 10
      GROUP BY business_id, bin),
      
     avg AS 
     (SELECT business_id, bin, 
             SUM(useful) AS total_votes,
             AVG(useful) AS avg_votes,
             SUM( IF(useful > 0,1,0) ) AS useful_count,
             ( SUM( IF(useful > 0 AND elite,1,0) ) /  SUM( IF(elite,1,0) ) ) AS elite_percentage, 
             ( SUM( IF(useful > 0 AND gender = 'M',1,0) ) /  SUM( IF(gender = 'M',1,0) ) ) AS male,
             ( SUM( IF(useful > 0 AND gender = 'F',1,0) ) / SUM( IF(gender = 'F',1,0) ) ) AS female,
             ( SUM( IF(useful > 0 AND gender = 'Unknown',1,0) ) / SUM( IF(gender = 'Unknown',1,0) ) ) AS unknown
      FROM ordered
      WHERE bin_count = 10
      GROUP BY business_id, bin)
      
SELECT A.business_id, A.bin, A.total_votes, A.avg_votes, M.median_votes, A.useful_count, A.elite_percentage, A.male, A.female, A.unknown
FROM avg AS A INNER JOIN median AS M
ON A.business_id = M.business_id AND A.bin = M.bin
ORDER BY business_id, bin
""")
print("Businesses with at least one bin of size 10:", df_bin_summary.select("business_id").distinct().count())
df_bin_summary.show(200,truncate=22)
df_bin_summary.createOrReplaceTempView("bin_summary")


# COMMAND ----------

# MAGIC %md ### Comparing bins using LAG
# MAGIC
# MAGIC We have calculated information about the number of useful votes in each bin, but how are you going to analyze that?
# MAGIC
# MAGIC One possibility is to look at each business and compare each bin to the earlier bin at the same business.  Your tem could do that with the `LAG` window function.  You could also use a Window frame to either compare to multiple prior bins or all prior bins.

# COMMAND ----------

# If you decide to try the LAG function appraoch, add your code in the process here before combining with the business data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 17: Combining bins and business data
# MAGIC In the `Business and Categories` notbook we generated the table named `business_category_table` which has business level data, including an array of the top-level categories for each business.
# MAGIC
# MAGIC Here we bring that data by bin together with the business data and include the following:
# MAGIC * Business name
# MAGIC * State
# MAGIC * Number of reviews
# MAGIC * longitude and latitude
# MAGIC * Number of top-level categories the business is in
# MAGIC * Array of top-level categories the business is in
# MAGIC * Restaurant flag (Boolean as to whether it's a restaurant)
# MAGIC * Home Service / Local Service flag
# MAGIC

# COMMAND ----------

df_combined_data = spark.sql("""
SELECT  B.business_id, B.name, B.state, B.review_count, B.longitude, B.latitude, B.category_count,
        ARRAY_CONTAINS(B.top_categories, "Restaurants") AS is_restaurant,
        ( ARRAY_CONTAINS(B.top_categories, "Home Services") OR ARRAY_CONTAINS(B.top_categories, "Local Services") ) AS is_home_local,
        S.bin, S.total_votes, S.avg_votes, S.median_votes, S.useful_count, S.elite_percentage, S.male, S.female, S.unknown
FROM business_category_table AS B INNER JOIN bin_summary AS S
ON B.business_id = S.business_id
ORDER BY B.category_count DESC, B.business_id, S.bin
""")
print("Record Count:", df_combined_data.count())
df_combined_data.show()

# COMMAND ----------

df_combined_data2 = spark.sql("""
SELECT  B.business_id, B.name, B.review_count, B.category_count, B.top_categories, R.useful,
CASE
  WHEN ARRAY_CONTAINS(top_categories, 'Shopping') THEN 'Shopping'
  WHEN ARRAY_CONTAINS(top_categories, 'Pets') THEN 'Pets'
  WHEN ARRAY_CONTAINS(top_categories, 'Automotive') THEN 'Automotive'
  WHEN ARRAY_CONTAINS(top_categories, 'Restaurants') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Nightlife') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Food') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Nightlife') THEN 'Restaurant Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Home Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Local Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Professional Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Financial Services') THEN 'Service Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Active Life') THEN 'Health & Wellness'
  WHEN ARRAY_CONTAINS(top_categories, 'Health & Medical') THEN 'Health & Wellness'
  WHEN ARRAY_CONTAINS(top_categories, 'Beauty & Spas') THEN 'Beauty & Spas'
  WHEN ARRAY_CONTAINS(top_categories, 'Event Planning & Services') THEN 'Travel & Events Related'
  WHEN ARRAY_CONTAINS(top_categories, 'Hotel & Travel') THEN 'Travel & Events Related'
  ELSE 'Other'
END AS combined_category
FROM business_category_table as B INNER JOIN reviews_without_text_table as R
ON B.business_id = R.business_id
ORDER BY R.useful DESC
""")
df_combined_data2.show()
df_combined_data2.createOrReplaceTempView("combined_data2")
process_or_create_table("combined_data2_table", "df_combined_data2", summary=True, delete=False)

# COMMAND ----------

df_combined_data3 = spark.sql("""
SELECT *,
IF (review_count > 140,140,review_count) AS new_review_count
FROM combined_data2
""")
df_combined_data3.show()
df_combined_data3.createOrReplaceTempView("combined_data3")
process_or_create_table("combined_data3_table", "df_combined_data3", summary=True, delete=False)

# COMMAND ----------

df_binned_data = spark.sql("""
SELECT business_id, review_id, useful, review_order,
CASE
  WHEN review_order <=5 THEN 1
  WHEN review_order <=10 THEN 2
  WHEN review_order <=15 THEN 3
  WHEN review_order <=20 THEN 4
  WHEN review_order <=25 THEN 5
  WHEN review_order <=30 THEN 6
  WHEN review_order <=35 THEN 7
  WHEN review_order <=40 THEN 8
  WHEN review_order <=45 THEN 9
  WHEN review_order <=50 THEN 10
  WHEN review_order <=55 THEN 11
  WHEN review_order <=60 THEN 12
  WHEN review_order <=65 THEN 13
  WHEN review_order <=70 THEN 14
  WHEN review_order <=75 THEN 15
  WHEN review_order <=80 THEN 16  
  ELSE 0
END AS bins
FROM ordered_reviews
ORDER BY business_id, review_order
""")
print("Record Count:", df_binned_data.count())
df_binned_data.show(200)
df_binned_data.createOrReplaceTempView("binned_data")




# COMMAND ----------

df_binned_data = spark.sql("""
SELECT B.business_id, B.review_id, B.useful, B.review_order,
CASE
  WHEN review_order <=5 THEN 1
  WHEN review_order <=10 THEN 2
  WHEN review_order <=15 THEN 3
  WHEN review_order <=20 THEN 4
  WHEN review_order <=25 THEN 5
  WHEN review_order <=30 THEN 6
  WHEN review_order <=35 THEN 7
  WHEN review_order <=40 THEN 8
  WHEN review_order <=45 THEN 9
  WHEN review_order <=50 THEN 10
  WHEN review_order <=55 THEN 11
  WHEN review_order <=60 THEN 12
  WHEN review_order <=65 THEN 13
  WHEN review_order <=70 THEN 14
  WHEN review_order <=75 THEN 15
  WHEN review_order <=80 THEN 16  
  ELSE 0
END AS bins
FROM ordered_reviews as B INNER JOIN combined_data3 as R
ON B.business_id = R.business_id
ORDER BY business_id, review_order
""")
print("Record Count:", df_binned_data.count())
df_binned_data.show(200)
df_binned_data.createOrReplaceTempView("binned_data")




# COMMAND ----------

