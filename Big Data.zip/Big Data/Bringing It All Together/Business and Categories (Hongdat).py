# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright &copy; 2022 Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md # Bringing All of Our Data Together - Business and Categories
# MAGIC
# MAGIC #### The ***main*** question we are asking of the Yelp data is:<br/>
# MAGIC *<div style="margin-left:50px;max-width:600px;background-color:#39506B;"><div style="margin:20px;font-size:1.5em;color:#ffffff">Do reviews more often get voted useful when there are fewer reviews for a business?</div></div>*
# MAGIC
# MAGIC ***Our hypothesis is:*** since a user must see a review (and most likely read it), before clicking the "Useful" button, users are more likely to read reviews when there are fewer reviews for a business.  If there are many reviews, our hypothesis is that the user would go with the wisdom of the crowd and not read individual reviews, and even if they did read reviews, they would not read many.  When there are fewer reviews, our hypothesis is that they would read all or at least more of the reviews since there is no crowd providing an opinion yet.
# MAGIC
# MAGIC
# MAGIC In this notebook we are going to bring together the Yelp categories and business data:
# MAGIC * The result of the notebook is written out as the table `business_category_table`
# MAGIC * Businesses outside of the nine states used as proxies for the metro areas are filtered out
# MAGIC * The top-level categories in Yelp's category hierarchy are identified
# MAGIC * Businesses with no categories identified are set to an "Unknown" category
# MAGIC * A count is added as to the number of top-level categories a business is in
# MAGIC * The comma-separated category string for each business is replaced with an array of just the top-level categories the business is in
# MAGIC
# MAGIC **<span style="font-size:1.2em;">The connections between our data files are as follows:</span>**<br/>
# MAGIC <img src="https://www.sjsu.edu/people/scott.jensen/courses/BUS4_118D/categoriesbusiness.png"/>

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 id="categories">Step 1: Loading the Categories Data</h1>
# MAGIC Since the categories data is our smallest data source, we are going to load and process that first.
# MAGIC
# MAGIC #### The following cell is Step 1:

# COMMAND ----------

df_categories = spark.read.option("multiLine",True).json("/yelp/categories.json")
print( "number of categories:", df_categories.count() )
df_categories.show()
df_categories.printSchema()
df_categories.createOrReplaceTempView("categories")

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 2: Identifying top-level categories
# MAGIC
# MAGIC
# MAGIC We are going to focus on the top-level categories (which you can find <a href="https://www.yelp.com/developers/documentation/v3/category_list" target="_blank">here</a>.  The top-level categories (e.g., Active Life), have no parents, so we are going to select those where the parents array has a size of zero.  The title field is used in the categories column in the business data to identify what categories a business is in.
# MAGIC
# MAGIC #### The following cell is Step 2:

# COMMAND ----------

df_top_categories = spark.sql("""
SELECT title
FROM categories
WHERE SIZE(parents) = 0
""")
print(f"Number of top-level categories: {df_top_categories.count()}")
df_top_categories.show(30, truncate=False)
df_top_categories.createOrReplaceTempView("top_categories")

# COMMAND ----------

# MAGIC %md 
# MAGIC # Step 3: Loading the Business Data
# MAGIC We need to do some wrangling in the business data and identify what categories the business is in. 
# MAGIC
# MAGIC #### The following cell is Step 3a:

# COMMAND ----------

df_business_data = spark.read.json('/yelp/business.bz2')
print ("record count:", df_business_data.count() )
df_business_data.show()
df_business_data.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Deciding What Business Data We Need
# MAGIC
# MAGIC This process is iterative, but for now we are going to include the following:
# MAGIC * business_id (so we can join with our review data)
# MAGIC * name (something human readable)
# MAGIC * categories (so we can identify the type of business and join with the category data)
# MAGIC * state (as a proxy for the metro area)
# MAGIC * review_count (so we can decide how much data we have or need for each business)
# MAGIC * attributes 
# MAGIC * longitude
# MAGIC * latitude
# MAGIC
# MAGIC #### The following cell is Step 3b:

# COMMAND ----------

df_business_data.createOrReplaceTempView("business_data")

df_business = spark.sql("""
SELECT business_id, name, categories, state, review_count, attributes, longitude, latitude
FROM business_data
""")
print ("record count:", df_business.count() )
df_business.show()
df_business.createOrReplaceTempView("business")

# COMMAND ----------

# MAGIC %md ### Step 4: Identifying the state that are the metro areas
# MAGIC
# MAGIC In the following cell we get a count of the businesses per state and find we need to do some clean-up.  There are actually 9 states for our 8 metro areas.
# MAGIC
# MAGIC #### The following cell is Step 4a:

# COMMAND ----------

spark.sql("""
SELECT state, COUNT(*) AS businesses
FROM business
GROUP BY state
ORDER BY businesses
""").show(100)

# COMMAND ----------

# MAGIC %md #### Step 4b: Doing some clean up to filter out states that are not part of our metro areas

# COMMAND ----------

df_proxy_states = spark.sql("""
SELECT state, COUNT(*) AS businesses
FROM business
GROUP BY state
HAVING businesses > 1000
ORDER BY businesses
""")
df_proxy_states.show()
df_proxy_states.createOrReplaceTempView("proxy_states")

# COMMAND ----------

display(df_proxy_states)

# COMMAND ----------

# MAGIC %md #### Step 4c: Cleaning up the business data to eliminate businesses not in the 8 metro areas (9 states)
# MAGIC

# COMMAND ----------

df_valid_business = spark.sql("""
SELECT *, IF(state='WA', 'OR', state) AS metro_area
FROM business AS B LEFT SEMI JOIN proxy_states AS S
ON B.state = s.state
""")
print(f"Valid business count: {df_valid_business.count()}")
df_valid_business.show(truncate = 50)
df_valid_business.createOrReplaceTempView("valid_business")

# COMMAND ----------

# MAGIC %md #### Summary of 8 metro areas
# MAGIC This combaines WA and OR as OR

# COMMAND ----------

display(df_valid_business.groupBy("metro_area").count().orderBy("count", ascending=False))

# COMMAND ----------

# MAGIC %md #### Step 4e: Summary by Metro Area

# COMMAND ----------

display(
spark.sql("""
SELECT metro_area, SUM(review_count) AS total_reviews, COUNT(*) AS total_businesses
FROM valid_business
GROUP BY metro_area
ORDER BY total_businesses DESC
""")
)

# COMMAND ----------

# MAGIC %md #### Step 4f: Comparing reviews and businesses

# COMMAND ----------

display(
spark.sql("""
SELECT metro_area, SUM(review_count) AS total, 'reviews' AS aggregation
FROM valid_business
GROUP BY metro_area
UNION
SELECT metro_area, COUNT(*) AS total, 'businesses' AS aggregation
FROM valid_business
GROUP BY metro_area
ORDER BY metro_area
""")
)

# COMMAND ----------

# MAGIC %md ### Step 5: Identifying the Categories Each Business is In
# MAGIC
# MAGIC In the business data, the `categories` column contains a comma-seperated string of the categories a business is classified as being in.  However,  some businesses may not be in any categories.
# MAGIC
# MAGIC Example:<br/>
# MAGIC Oskar Blues Taproom: Gastropubs, Food, Beer Gardens, Restaurants, Bars, American (Traditional), Beer Bar, Nightlife, Breweries
# MAGIC
# MAGIC We see that the categories used at this business have the following hierarchy:
# MAGIC
# MAGIC <div>Food<br/>
# MAGIC   <span style="padding-left:20px">├─ Breweries</span><br/>
# MAGIC Nightlife<br/>
# MAGIC <span style="padding-left:20px">├─  Bars<br/>
# MAGIC <span style="padding-left:20px">├─  Beer Gardens<br/>
# MAGIC Restaurants<br/>
# MAGIC <span style="padding-left:20px">├─  American (Traditional)<br/>
# MAGIC <span style="padding-left:20px">├─  Gastropubs<br/>
# MAGIC
# MAGIC The `categories` column in the business data always walks the tree up to the top-level categories, possibly through multiple levels.
# MAGIC
# MAGIC #### The following cell is Step 5:

# COMMAND ----------

df_business_categories = spark.sql("""
SELECT business_id, name, state, review_count, attributes, longitude, latitude,
SPLIT(categories,'\\\s*,\\\s*') AS categories
FROM valid_business
""")
df_business_categories.show()
df_business_categories.select("business_id", "name","categories").show(truncate=False)
df_business_categories.printSchema()
df_business_categories.createOrReplaceTempView("business_categories")

# COMMAND ----------

# MAGIC %md ### Step 6: Identifying the top-level categories businesses are in
# MAGIC
# MAGIC The `valid_business` temporary view has all of the businesses in the 9 states we are using as proxies for the 8 metro areas.  The categories column (unless null) has all of the categories a business is in, using the same labels and format as the `title` field in the `top_categories` to the extent those categories are top-level categories.
# MAGIC
# MAGIC If a business is not in any categories, we don't want to exclude them, so we will set the title for their category to "Unknown".
# MAGIC
# MAGIC #### The following cell is Step 6:

# COMMAND ----------

df_business_top_categories = spark.sql("""
SELECT B.*, COALESCE(title, "Unknown") AS category
FROM business_categories AS B LEFT OUTER JOIN top_categories AS C
ON ARRAY_CONTAINS(categories, C.title)
ORDER BY SIZE(categories) DESC
""")
print(f"number of businesses:{df_business_top_categories.count()}")
df_business_top_categories.show(100, truncate=30)
df_business_top_categories.createOrReplaceTempView("business_top_categories")

# COMMAND ----------

# MAGIC %md ### Step 6a: Profiling to check that we have the same number of businesses
# MAGIC The number of distinct businesses should mmatch the number of businesses after we filtered out the businesses in states that should not be in the dataset because they are outside our 8 metro areas.
# MAGIC
# MAGIC We also get a count of the number of businesses that have no category information and were set to the "Unknown" category.  Since the number of businesses without categories is minimal, we also printed those rows.
# MAGIC
# MAGIC #### The following cell is Step 6a:

# COMMAND ----------

print(f"Businesses:{df_business_top_categories.select('business_id').distinct().count()}")
print("Businesses in unkown categories:", df_business_top_categories.filter("category == 'Unknown'").distinct().count())
df_business_top_categories.filter("category == 'Unknown'").show(200, truncate = 50)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Step 6b: Identifying the number of categories each business is in
# MAGIC
# MAGIC Depending on how we decide to calculate the early reviews for a business, we may want to weight some businesses based on the number of top-level categories they are operating in.  To do this, we count the number of top-level categories a business is operating in.  If we decide to weight based on the number of categories, we can multiply by the fraction 1 / category_count.
# MAGIC
# MAGIC #### The following cell is Step 6b:

# COMMAND ----------

df_business_top_category_count = spark.sql("""
SELECT *, 
COUNT(*) OVER (PARTITION BY business_id) AS category_count
FROM business_top_categories
ORDER BY category_count DESC, business_id
""")
df_business_top_category_count.show(100,truncate=30)
df_business_top_category_count.createOrReplaceTempView("business_top_category_count")

# COMMAND ----------

# MAGIC %md ### Step 6c: Consolidate each business back to one row
# MAGIC
# MAGIC In the prior step we have each top-level category is in as a separate row, but when we bring this together with our review data, we want one row for each business.  To do that we are going to make the categories for a business back into an array, but this time it will only contain the top-level categories a business is in.
# MAGIC
# MAGIC

# COMMAND ----------

df_business_and_categories = spark.sql("""
SELECT business_id, 
       FIRST(name) AS name, 
       FIRST(state) AS state,
       FIRST(review_count) AS review_count, 
       FIRST(longitude) AS longitude, 
       FIRST(latitude) AS latitude,
       FIRST(category_count) AS category_count,
       COLLECT_LIST(category) AS top_categories
FROM business_top_category_count
GROUP BY business_id
ORDER BY category_count DESC, business_id
""").cache()
print("business count:", df_business_and_categories.count() )
df_business_and_categories.show(truncate=False)
df_business_and_categories.printSchema()


# COMMAND ----------

# MAGIC %md #### Step 6d: Review count distribution for Restaurants

# COMMAND ----------

df_business_and_categories.createOrReplaceTempView("business_and_categories")

# COMMAND ----------

display(
spark.sql("""
SELECT IF(review_count > 400, 400, review_count) AS review_count
FROM business_and_categories
WHERE ARRAY_CONTAINS(top_categories, 'Home Services') OR ARRAY_CONTAINS(top_categories, 'Local Services')
""")
)

# COMMAND ----------

# MAGIC %md #### Review Count Distribution for Home and/or Local services

# COMMAND ----------

display(
spark.sql("""
SELECT IF(review_count > 80, 80, review_count) AS review_count
FROM business_and_categories
WHERE ARRAY_CONTAINS(top_categories, 'Home Services') OR ARRAY_CONTAINS(top_categories, 'Local Services')
""")
)

# COMMAND ----------

# MAGIC %md ### Step 6e: Write the wrangled business and category data to a table
# MAGIC As a separate notebook, this is generating the data we need from business and category data and writing it out to a table named `business_category_table`.  Unless this needs to change, we will not need to regenerate this table, but just reload the table files from the notebook using the table.
# MAGIC
# MAGIC For writing out the table, functions from the `Process or Create Table` notebook are first embedded here.
# MAGIC
# MAGIC In the future, if we need to force the table to be rebuilt, the `delete` parameter in the call to the `process_or_create_table` function should be set to `True`.

# COMMAND ----------

# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("business_category_table", "df_business_and_categories", summary=True, delete=False)
df_business_and_categories.unpersist()

# COMMAND ----------

# MAGIC %md ### Notes on profiling the data
# MAGIC If this were your project from scratch, you would want to do some of the profiling we have done in other notebooks before joining with the review data:
# MAGIC * How many businesses are in each top-level category?
# MAGIC * How many businesses are in multiple top-level category? (summarized by the numer in 1-22 categories)
# MAGIC * Which top level categories overlap - and how much?
# MAGIC

# COMMAND ----------

# MAGIC %md # Combining Categories

# COMMAND ----------

df_category_pairs = spark.sql("""
SELECT A.title AS category1, B.title AS category2
FROM top_categories AS A CROSS JOIN top_categories AS B
WHERE A.title <> B.title
""")
print("pairs:", df_category_pairs.count() )
df_category_pairs.show(100)
df_category_pairs.createOrReplaceTempView("category_pairs")

# COMMAND ----------

df_category_pairs = spark.sql("""
SELECT business_id, name, review_count, C.category1, C.category2
FROM business_category_table AS B INNER JOIN category_pairs AS C
ON ARRAY_CONTAINS(top_categories, C.category1) AND ARRAY_CONTAINS(top_categories, C.category2)
WHERE B.category_count = 2
""")
print("records:", df_category_pairs.count() )
df_category_pairs.show(truncate=False)
df_category_pairs.createOrReplaceTempView("category_pairs")

# COMMAND ----------

df_category_singles = spark.sql("""
SELECT business_id, name, review_count, top_categories[0] AS category1, top_categories[0] AS category2
FROM business_category_table
WHERE category_count = 1 AND
NOT ARRAY_CONTAINS(top_categories, "Unkown")
""")
print("records:", df_category_singles.count() )
df_category_singles.show(truncate = False)
df_category_singles.createOrReplaceTempView("category_singles")

# COMMAND ----------

df_frequency_pairs = spark.sql("""
(SELECT * FROM category_pairs)
UNION
(SELECT * FROM category_singles)
""")
df_frequency_pairs.show(truncate = False)

# COMMAND ----------

process_or_create_table("frequency_pairs_table","df_frequency_pairs", delete = False)


# COMMAND ----------

