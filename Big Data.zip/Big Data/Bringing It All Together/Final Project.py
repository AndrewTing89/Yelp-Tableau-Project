# Databricks notebook source
# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("business_category_table", None, summary=True, delete=False)

# COMMAND ----------

# MAGIC %run "./Building Review Table"

# COMMAND ----------

df_ordered_reviews = spark.sql("""
SELECT R.*, 
       ARRAY_CONTAINS(elite_years, YEAR(R.date)) AS elite, 
       U.is_elite AS ever_elite, 
       COALESCE(YEAR(R.date) >= U.first_elite, false) AS after_elite, 
       U.gender,
       ROW_NUMBER() OVER (PARTITION BY business_id ORDER BY date) AS review_order
FROM reviews_without_text_table AS R INNER JOIN user_gender_table AS U
ON R.user_id = U.user_id
ORDER BY business_id, review_order
""").cache()
print(f"review count:{df_ordered_reviews.count()}")
df_ordered_reviews.show(200, truncate=False)
df_ordered_reviews.createOrReplaceTempView("ordered_reviews")

# COMMAND ----------

df_binned_reviews = spark.sql("""
SELECT *, 
( CEILING(review_order / 5) ) AS bin5, 
( CEILING(review_order / 10) ) AS bin10
FROM ordered_reviews
ORDER BY business_id, review_order
""")
df_binned_reviews.show(200, truncate=False)
df_binned_reviews.createOrReplaceTempView("binned_reviews")

# COMMAND ----------

