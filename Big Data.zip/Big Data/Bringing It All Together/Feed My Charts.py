# Databricks notebook source
# MAGIC %md # Purpose of this Notebook
# MAGIC This notebook is based on some of the notebooks and tables built in the **Bringing It All Together** exercise folder.
# MAGIC
# MAGIC The purpose of the notebook is to have the data needed to feed the histogram and treemap examples.
# MAGIC
# MAGIC ### process_or_create_table
# MAGIC Since the tables being used were built in another notebook, and the DataFrames written out to create the tables are NOT in this notebook, the `delete` parameter should ***always*** be `False` (the defualt), so it can be omitted.  
# MAGIC
# MAGIC Similarly, the `DF_NAME` parameter should be omitted or set to `None`. If the table does not already exist, the notebook that created it originally will need to be run first.  If the table's Parquet files exist, but the table definition has not been created on the current cluster, the `process_or_create_table` function will rebuild the table from the files.

# COMMAND ----------

# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("business_category_table", None, summary=True, delete=False)

# COMMAND ----------

# MAGIC %md ### How many businesses are in multiple top-level categories?
# MAGIC Most are in a single top-level category, but about 1/4th are in 2 categories.  Only about 6% are in 3 categories, and it drops fast after that.

# COMMAND ----------

spark.sql("""
SELECT category_count, COUNT(*) AS business_count
FROM business_category_table
GROUP BY category_count
ORDER BY category_count
""").show()

# COMMAND ----------

# MAGIC %md ### Break businesses out by top category and weight the categories
# MAGIC In the following cell we use EXPLODE to breakout the array with the top-level categories a business is in so that each category is on a separate line.  We need to do this because Tableau does NOT have a data type that could handle an array.  However, businesses in multiple categories are now on multiple rows, and we want to uses rows to represent businesses in Tableau, so a weighted categories column was added so a business in multiple categories is apportioned across those categories.

# COMMAND ----------

df_weighted_categories = spark.sql("""
SELECT business_id, name, state, review_count,category_count,(1/category_count) AS weighted_category_count,
EXPLODE(top_categories) AS category
FROM business_category_table
""")
print("record count:", df_weighted_categories.count())
df_weighted_categories.createOrReplaceTempView("weighted_categories")
df_weighted_categories.show(100, truncate = False)

# COMMAND ----------

# MAGIC %md # Table for Tableau
# MAGIC In the following cell we write out the DataFrame above with the exploded and apportioned categories as `weighted_category_table` so we can use it in Tableau.

# COMMAND ----------

process_or_create_table("weighted_category_table", "df_weighted_categories", summary=True, delete=False)

# COMMAND ----------

# MAGIC %md ### Checking our work
# MAGIC Above, we broke out the categories for the businesses and apportioned them - but did we do it correctly?  The following two cells check our work.  First we total the weighted categories by category to see if it seems reasonable, and in the next  cell we sum up the apportioned category totals to make sure the apportioned categories ties back to the number of businesses we started with.

# COMMAND ----------

df_weighted_category_summary = spark.sql("""
SELECT category, ROUND(SUM(weighted_category_count),0) AS weighted_category_total
FROM weighted_categories
GROUP BY category
ORDER BY weighted_category_total DESC
""")
df_weighted_category_summary.show(100, truncate = False)
df_weighted_category_summary.createOrReplaceTempView("weighted_category_summary")

# COMMAND ----------

spark.sql("""
SELECT SUM(weighted_category_total) AS total
FROM weighted_category_summary
""").show()