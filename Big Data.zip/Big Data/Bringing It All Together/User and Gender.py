# Databricks notebook source
# MAGIC %md 
# MAGIC Copyright &copy; 2022 Scott Jensen, San Jose State University
# MAGIC
# MAGIC <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">This notebook</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Scott Jensen,Ph.D.</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

# COMMAND ----------

# MAGIC %md # Bringing All of Our Data Together - User and Gender
# MAGIC
# MAGIC #### The ***main*** question we are asking of the Yelp data is:<br/>
# MAGIC *<div style="margin-left:50px;max-width:600px;background-color:#39506B;"><div style="margin:20px;font-size:1.5em;color:#ffffff">Do reviews more often get voted useful when there are fewer reviews for a business?</div></div>*
# MAGIC
# MAGIC ***Our hypothesis is:*** since a user must see a review (and most likely read it), before clicking the "Useful" button, users are more likely to read reviews when there are fewer reviews for a business.  If there are many reviews, our hypothesis is that the user would go with the wisdom of the crowd and not read individual reviews, and even if they did read reviews, they would not read many.  When there are fewer reviews, our hypothesis is that they would read all or at least more of the reviews since there is no crowd providing an opinion yet.
# MAGIC
# MAGIC
# MAGIC In this notebook we are going to bring together the Yelp user data and name data from the Social Security Administration (SSA):
# MAGIC * This notebook is extracted from a larger notebook and starts at Step 7
# MAGIC * The result of the notebook is written out as `user_gender_table`
# MAGIC * The predominant gender of each name in the SSA data is determined
# MAGIC * When users were elite (and if they were ever elite) is identified
# MAGIC * The gender of Yelp users is predicted based on the SSA data
# MAGIC
# MAGIC **<span style="font-size:1.2em;">The connections between our data files are as follows:</span>**<br/>
# MAGIC <img src="https://www.sjsu.edu/people/scott.jensen/courses/BUS4_118D/user-gender.png"/>

# COMMAND ----------

# MAGIC  %md # Step 7: Loading the Social Security Administration (SSA) Data
# MAGIC  
# MAGIC  The SSA data contains the number of people by name born each year since 1880 who applied for a social security and breaks it out by gender.
# MAGIC  
# MAGIC  this data will be used to predict the gender of the Yelp users.
# MAGIC  
# MAGIC  #### The following cell is Step 7a:

# COMMAND ----------

df_ssa_data = spark.read.option("header","false").option("inferSchema","true").csv("/ssa/data/*.txt")
print(f"Number of records: {df_ssa_data.count() }")
df_ssa_data.show(truncate=False)
df_ssa_data.printSchema()
df_ssa_data.createOrReplaceTempView("ssa_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 7b: Formatting the SSA data
# MAGIC
# MAGIC As imported from the comma-separated value (CSV) files, the data is loaded by year, but does not include a year column, so the year is brought in from the file name.
# MAGIC
# MAGIC The data in the files is also lacking column headings, so column headins are added in this step.
# MAGIC
# MAGIC  #### The following cell is Step 7b:

# COMMAND ----------

df_ssa = spark.sql("""
SELECT _c0 AS name, _c1 AS gender, _c2 AS count, CAST( SUBSTRING( INPUT_FILE_NAME(), -8, 4) AS INTEGER ) AS ssa_year
FROM ssa_data
""")
print(f"Number of records: {df_ssa.count() }")
df_ssa.show(truncate=False)
df_ssa.printSchema()
df_ssa.createOrReplaceTempView("ssa")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 8: Summarize the SSA data by name
# MAGIC
# MAGIC The original SSA data had separate rows for the men and women with a name in a year.  For example, each year there would be a row of data for the women born that year who had the name "Elizabeth" and a separate row for the men born that year with the name "Elizabeth".  This initial transformation from two rows to a single row is done in step 8a.
# MAGIC
# MAGIC Although the data could be filtered by year to represent the probbable ages of Yelp users (not going back to 1880), for our purposes we will summarize all of the years in Step 8b.
# MAGIC
# MAGIC #### The following cell is Step 8a:

# COMMAND ----------

df_ssa_by_year = spark.sql("""
SELECT *
FROM ssa
PIVOT(
  SUM(count)
  FOR gender IN ('F' AS women, 'M' AS men)
)
ORDER BY name, ssa_year
""")
df_ssa_by_year.show()
df_ssa_by_year.createOrReplaceTempView("ssa_by_year")

# COMMAND ----------

# MAGIC %md ### Step 8b: Summarize the annual SSA data by name

# COMMAND ----------

df_ssa_by_name = spark.sql("""
SELECT name, SUM( COALESCE(women, 0) ) AS women, SUM( COALESCE(men,0) ) AS men
FROM ssa_by_year
GROUP BY name
""")
df_ssa_by_name.show()
df_ssa_by_name.createOrReplaceTempView("ssa_by_name")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 9: Identify the gender of each name in the SSA data
# MAGIC
# MAGIC Based on the total number of men and women with each name in the SSA data, the gender is set to the predominant gender for that name and a ratio is calculated as to how often the name is the predominant gender.

# COMMAND ----------

df_ssa_gender = spark.sql("""
SELECT name, women, men, 
(women + men) AS total,
IF(men > women, 'M', 'F') as gender,
( IF(men > women, men, women) / (women + men) ) AS gender_ratio   
FROM ssa_by_name
""").cache()
df_ssa_gender.show(truncate=False)
df_ssa_gender.createOrReplaceTempView("ssa_gender")

# COMMAND ----------

# MAGIC %md # Step 10: Loading the User Data 
# MAGIC Although the focus of our question is on the useful votes on early reviews versus later reviews at businesses, we may also want to consider whether useful votes are tied
# MAGIC more to whether the reviews were written by elite or non-elite users, or whether the reviews were written by men or women.
# MAGIC
# MAGIC in determining the gender of the user who wrote a review, we will be using data from the Social Security Administration (SSA).
# MAGIC
# MAGIC The following cell imports a notebook that loads the Yelp user data into a table named `user_table`.
# MAGIC
# MAGIC If the user data has been previously loaded, the table will load very quickly (less than a minute), but if has not previously been created, this could take 15 minutes to run.
# MAGIC
# MAGIC Since the frinds field can contain a lot of user IDs, we exclude the friends list and instead include a count of the number of Yelp friends a user has.
# MAGIC
# MAGIC After running the following cell, you may want to hide the output, but make sure it has completed running first.
# MAGIC
# MAGIC #### The following cell is Step 10:
# MAGIC

# COMMAND ----------

# MAGIC %run "./Building User Table"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 11: Identifying the years a user was elite
# MAGIC
# MAGIC The user data contains a comma-separated string with the 4-digit years a user was elite.  By converting this to an array, we can identify whether a user was elite the year each review was written.
# MAGIC
# MAGIC Since it may be that reviewing style f elite users was always different, even before they were elite, we also set a boolean `is_elite` field we can use to identify if a review was written by a user that was ever elite (even if not in the year they wrote a review).  It could also be that when becoming elite, a user's reviewing style changes, so we also track the first year they became elite as `first_elite` (which will be null if they were never elite).
# MAGIC
# MAGIC NOTE: Here we are using a common table expression (CTE) to conver the elite comma-separate string to an integer array so we can compare the years in the array to the year a review was written.  This could alternately be done using an RDD or a user-defined function (UDF).
# MAGIC
# MAGIC #### The following cell is Step 11:
# MAGIC

# COMMAND ----------

df_users = spark.sql("""
WITH elite_array AS 
     (SELECT user_id, name, review_count AS reviews_written, SPLIT(elite,"\\\s*,\\\s*") AS elite_years
      FROM user_table),
     
     exploded_elite AS
     (SELECT user_id, EXPLODE(elite_years) AS elite_year
      FROM elite_array),
      
     converted_elite AS
     (SELECT user_id, CAST(elite_year AS INTEGER) AS elite_year
      FROM exploded_elite),
      
     collected_elite AS
     (SELECT user_id, COLLECT_LIST(elite_year) AS elite_years
      FROM converted_elite
      GROUP BY user_id)
      
SELECT E.user_id, E.name, E.reviews_written, C.elite_years, (SIZE(C.elite_years) > 0) AS is_elite, ARRAY_MIN(C.elite_years) AS first_elite
FROM elite_array AS E INNER JOIN collected_elite AS C
ON E.user_id = C.user_id
""")
df_users.printSchema()
df_users.show(100, truncate=False)
df_users.createOrReplaceTempView("users")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 12: Predicting the gender of Yelp users
# MAGIC Based on the SSA data, the names of Yelp users, to the extent they match with names in the SSA data will be identified as male or female names.
# MAGIC
# MAGIC If a user's name does not have a match in the SSA data, the gender will be set to "unknown" and the gender ratio will be set to 0 (it could reasonably be set to either 0 to indicate no gender data or to 1 to indicate we are 100% sure the gender is unknown).
# MAGIC
# MAGIC #### The following cell is Step 12a:

# COMMAND ----------

df_user_gender = spark.sql("""
SELECT U.*, 
IF(gender IS NULL, 'Unknown', gender) AS gender, 
IF(gender IS NULL, 0, gender_ratio) AS gender_ratio
FROM users AS U LEFT JOIN ssa_gender AS G 
ON LOWER(U.name) = LOWER(G.name)
 """).cache()
print(f"Record count: {df_user_gender.count()}")
df_user_gender.show(truncate=False)
df_user_gender.createOrReplaceTempView("user_gender")
df_ssa_gender.unpersist()

# COMMAND ----------

# MAGIC %md ### Step 12b: Write the wrangled user and gender data to a table
# MAGIC As a separate notebook, this is generating the data we need from user and SSA gender data and writing it out to a table named `user_gender_table`.  Unless this needs to change, we will not need to regenerate this table, but just reload the table files from the notebook using the table.
# MAGIC
# MAGIC In the future, if we need to force the table to be rebuilt, the `delete` parameter in the next cell should be set to `True`.
# MAGIC
# MAGIC For writing out the table, functions from the `Process or Create Table` notebook are first embedded here.
# MAGIC
# MAGIC In the future, if we need to force the table to be rebuilt, the `delete` parameter in the call to the `process_or_create_table` function should be set to `True`.

# COMMAND ----------

# MAGIC %run "./Process or Create Table"

# COMMAND ----------

process_or_create_table("user_gender_table", "df_user_gender", summary=True, delete=False)
df_user_gender.unpersist()
df_ssa_gender.unpersist()

# COMMAND ----------

# MAGIC %md ### Step 12b: Summarizing Yelp user gender
# MAGIC
# MAGIC In this step we summarize the Yelp users by gender to see if it's fairly even and how many users were were not able to predict.
# MAGIC

# COMMAND ----------

spark.sql("""
SELECT gender, COUNT(*) AS user_count, ROUND( SUM( IF(is_elite,1,0) )/ COUNT(*), 4) AS elite_percentage, SUM(reviews_written) AS reviews_written
FROM user_gender_table
GROUP BY gender
ORDER BY gender
""").show()