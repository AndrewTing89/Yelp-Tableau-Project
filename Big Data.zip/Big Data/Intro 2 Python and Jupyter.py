# Databricks notebook source
# MAGIC %md
# MAGIC # Andrew's Notebook

# COMMAND ----------

# MAGIC %md 
# MAGIC # This is a Markdown Cell
# MAGIC
# MAGIC When you first load this notebook, this cell will have automatically been caclulated to generate HTML.  This is the beauty of markdown.  Although this is a very basic markdown cell, 
# MAGIC markdown allows a wide range of formatting capabilities including **bolding**, *italics*, headings, bullet point lists, numbered lists, tables, indented blocks, code blocks, and even math formulas.
# MAGIC Since markdown is a superset of HTML (meaning it includes HTML and more), you can also embed HTML directly if you know it within a markdown cell.
# MAGIC
# MAGIC To see the original code written to generate this markdown cell, double-click anywhere in this cell.
# MAGIC
# MAGIC The first line above uses the "magic" cell starting with a percent (%) sign to indicate this is a markdown cell (%md).
# MAGIC
# MAGIC When editing a markdown cell, it is automatically compiled into HTML when you exit the cell (in other Jupyter interfaces 
# MAGIC you may need to run the cell to get it to compile, but it's fast either way).
# MAGIC
# MAGIC The second line of this cell has a "#" sign followed by a space to indicate the rest of the line is a Heading 1 line (what it becomes in HTML - a large header).
# MAGIC If instead we had 2 "#" signs, it would be a header 2 line - slightly smaller header than a Header 1, and so on as you add more "#" signs.
# MAGIC
# MAGIC Although a markdown cell is for documentation, one quirk you will quickly notice is there is no spell checking - make sure to review 
# MAGIC your work or it will lok sloopey an unprofessianole (to your teammates, instructor, and any recruiter you show it to). One way to review the text is to copy it into Word or a similar editor.
# MAGIC
# MAGIC There are links in Canvas to guides on using markdown, but one of the most often referenced guides on the Internet is <a href="https://daringfireball.net/projects/markdown/syntax" target="_blank">Daring Fireball</a>.
# MAGIC
# MAGIC However, when you want to add a link such as the above link to Daring Fireball, don't use the markdown approach of a description in square brackets followed by a link in quotes:
# MAGIC
# MAGIC `[Daring Fireball](https://daringfireball.net/projects/markdown/syntax)`
# MAGIC
# MAGIC If you do that, it will launch you out of your notebook instead of opening it up in another tab. Instead, add your links using embedded HTML.  Since markdown is a superset of HTML, 
# MAGIC meaning it includes HTML, you can embed any HTML in your markdown.  The above link to Daring Fireball uses the following HTML (double-click on this markdown to see it in the markdown):
# MAGIC
# MAGIC `<a href="https://daringfireball.net/projects/markdown/syntax" target="_blank">Daring Fireball</a>`
# MAGIC
# MAGIC Since this embedded HTML includes `target="_blank"` in the opening anchor tag, it opens the Daring Fireball web page in a new tab - the same as if that HTML was on any regular web page.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Now for Some Simple Python ![Python_Powered](https://www.python.org/static/community_logos/python-powered-w-200x80.png)
# MAGIC
# MAGIC To get us started, we are going to do some simple Python code.  First we need to insert a new cell, so hover your mouse between this cell ansd the next cell.  A "plus" sign should appear as follows between the two cells:
# MAGIC
# MAGIC ![Insert_Notebook_Cell](http://www.sjsu.edu/people/scott.jensen/courses/add_notebook_cell.png)
# MAGIC
# MAGIC Click on that plus sign to add a new cell.  Since we did not add `%md` at the start of this cell, it's a code cell and not a markdown cell.  If you are using other Jupyter notebook environments (such as in the Anaconda desktop environment), you specify the cell type from a drop-down list.  In that environment you also need to explicitely run a markdown cell for it to compile into HTML.  In Databricks you just leave the markdown cell and it automatically compiles.
# MAGIC
# MAGIC #### Step 1: Creating some variables
# MAGIC In your new cell, add the following code:
# MAGIC
# MAGIC `mySchool = "SJSU"`
# MAGIC
# MAGIC That will define a new variable named `mySchool` and it will contain the string variable SJSU.  We surrounded SJSU in double-quotes because all strings are surrounded in qoutes.  We could also have surrounded it in single quotes, Python does not care, just that the starting and ending quote must (if we start with a double-quote, we must end with a double-quote).  This can be handy if your string includes an apostophe (which is also a single quote on your keyboard).
# MAGIC
# MAGIC To assign the string SJSU to the variable `mySchool`, run the cell below by clicking the play button that appears on the right-hand side of the cell when you hover your mouse over that code cell.  After you run that cell, ithere will be a message below the cell saying when it was run, but there is no output - all you did was assign a value to a variable.  Before we move on, let's define one more variable.  in the same cell, add a new line with the following code and re-run the cell:
# MAGIC
# MAGIC `schoolRank = 1`
# MAGIC
# MAGIC Here we are defining a new variable named `schoolRank` and we are assigning the numeric value 1.  Since we assigned the value `1`, and not the value `1.0`, Python determined that our variables type is an integer (a number without a decimal point).  If instead we had assigned the value `1.0`, Python would have determined our variable type is a float.  If you worked in other computing languages,
# MAGIC this might strike you as wierd. In some languages you must explicitly say the data type for each new variable you define.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using the format function
# MAGIC
# MAGIC When printing the string above, the school name and rank are part of the comma-separated list, but alternately, if you are familiar with the Python `format` method for strings, you could
# MAGIC use the following instead:
# MAGIC
# MAGIC `print ("I think {0} is #{1}".format(mySchool, schoolRank))`
# MAGIC
# MAGIC Here the sentance is a single string, and placeholders are added for the variables we are going to pass in the `format` method.  Since indexing in programming generally starts at zero, 
# MAGIC the first placeholder is `{0}` and will be replaced by the value of the first variable specified in the parameters listed for the `format` method.  In this case, the first variable listed is 
# MAGIC `mySchool`, so the value (which is "SJSU") replaces the {0} in the sentence that is printed.
# MAGIC
# MAGIC If you are familiar with the `format` method, feel free to use it. However, for your project, printing just a comma-separated list works fine. 

# COMMAND ----------

print("I think", my_school, "is #", school_rank)

# COMMAND ----------

my_school = "SJSU"
school_rank = 1
my_school

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Using Our Variables and looking at "State" of the Notebook
# MAGIC
# MAGIC In the above cell you defined two variables, `mySchool` and `schoolRank`, but you have not done anything with them.  In the next bit of code you write, you will be 
# MAGIC using the `print` function to print out a message about your school and it's ranking.  However, we are also going to learn a bit about "state", which is the current situation in your notebook.  While you can always clear the state while you are in a session, the longest that the state will last is until your session ends and your cluster shuts down.  When the cluster shuts down, the notebook's state disappears.  When you come back into the notebook, there is no state until you start calculating cells again - the code will be there (and any output previously displayed will also be visible).
# MAGIC
# MAGIC To continue, insert a new cell ***above*** the cell where you defined the `mySchool` and `schoolRank` variables.
# MAGIC
# MAGIC In that cell, we are going to use the Python `print` function to print a message in the output.  Type the following in that cell:
# MAGIC
# MAGIC `print("I think", mySchool, "is #", schoolRank)`
# MAGIC
# MAGIC Run that cell. No errors should occur (if typed correctly), and you should get a message printed as the output.
# MAGIC
# MAGIC If you have programed before (not in a notebook), this may seem odd.  Once you ran the cell in which you defined your two variables, they were part of the notebook's "state" (it's current situation).  Although you added your new cell ***above*** where you defined the variables you used, the calculation is based on the state.  For this reason, avoid reusing variable names in your notebook.
# MAGIC
# MAGIC #### Clearing the State:
# MAGIC
# MAGIC In the menu at the top, click on the dropdown list for `Clear` and select `Clear State & Run All`
# MAGIC
# MAGIC What Happened?
# MAGIC
# MAGIC You can change the order of your cells by dragging them (along the left edge).

# COMMAND ----------

# MAGIC %md ## We will continue with this notebook in class